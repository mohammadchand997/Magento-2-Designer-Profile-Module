<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Eviaglobal\Brand\Api;

use Magento\Framework\Api\SearchCriteriaInterface;

interface VideoRepositoryInterface
{

    /**
     * Save Video
     * @param \Eviaglobal\Brand\Api\Data\VideoInterface $video
     * @return \Eviaglobal\Brand\Api\Data\VideoInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(
        \Eviaglobal\Brand\Api\Data\VideoInterface $video
    );

    /**
     * Retrieve Video
     * @param string $videoId
     * @return \Eviaglobal\Brand\Api\Data\VideoInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function get($videoId);

    /**
     * Retrieve Video matching the specified criteria.
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \Eviaglobal\Brand\Api\Data\VideoSearchResultsInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
    );

    /**
     * Delete Video
     * @param \Eviaglobal\Brand\Api\Data\VideoInterface $video
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function delete(
        \Eviaglobal\Brand\Api\Data\VideoInterface $video
    );

    /**
     * Delete Video by ID
     * @param string $videoId
     * @return bool true on success
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function deleteById($videoId);
}
