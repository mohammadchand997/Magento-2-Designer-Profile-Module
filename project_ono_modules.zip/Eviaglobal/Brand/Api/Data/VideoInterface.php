<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Eviaglobal\Brand\Api\Data;

interface VideoInterface
{

    const BRAND_ID = 'brand_id';
    const URL = 'url';
    const TITLE = 'title';
    const VIDEO_ID = 'video_id';

    /**
     * Get video_id
     * @return string|null
     */
    public function getVideoId();

    /**
     * Set video_id
     * @param string $videoId
     * @return \Eviaglobal\Brand\Video\Api\Data\VideoInterface
     */
    public function setVideoId($videoId);

    /**
     * Get brand_id
     * @return string|null
     */
    public function getBrandId();

    /**
     * Set brand_id
     * @param string $brandId
     * @return \Eviaglobal\Brand\Video\Api\Data\VideoInterface
     */
    public function setBrandId($brandId);

    /**
     * Get url
     * @return string|null
     */
    public function getUrl();

    /**
     * Set url
     * @param string $url
     * @return \Eviaglobal\Brand\Video\Api\Data\VideoInterface
     */
    public function setUrl($url);

    /**
     * Get title
     * @return string|null
     */
    public function getTitle();

    /**
     * Set title
     * @param string $title
     * @return \Eviaglobal\Brand\Video\Api\Data\VideoInterface
     */
    public function setTitle($title);
}
