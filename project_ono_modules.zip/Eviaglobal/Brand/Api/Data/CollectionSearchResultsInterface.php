<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Eviaglobal\Brand\Api\Data;

interface CollectionSearchResultsInterface extends \Magento\Framework\Api\SearchResultsInterface
{

    /**
     * Get Collection list.
     * @return \Eviaglobal\Brand\Api\Data\CollectionInterface[]
     */
    public function getItems();

    /**
     * Set parent_id list.
     * @param \Eviaglobal\Brand\Api\Data\CollectionInterface[] $items
     * @return $this
     */
    public function setItems(array $items);
}
