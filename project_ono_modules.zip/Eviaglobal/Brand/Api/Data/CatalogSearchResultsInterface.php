<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Eviaglobal\Brand\Api\Data;

interface CatalogSearchResultsInterface extends \Magento\Framework\Api\SearchResultsInterface
{

    /**
     * Get catalog list.
     * @return \Eviaglobal\Brand\Api\Data\CatalogInterface[]
     */
    public function getItems();

    /**
     * Set brand_id list.
     * @param \Eviaglobal\Brand\Api\Data\CatalogInterface[] $items
     * @return $this
     */
    public function setItems(array $items);
}

