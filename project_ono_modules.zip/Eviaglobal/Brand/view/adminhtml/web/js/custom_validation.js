require([
    'jquery',
    "jquery/ui"
], function($){
    'use strict';

    $('#save_and_continue').on('click', function() {
        // Your custom click event logic here
        if(!$('#city').val() || !$('#country_id').val() || !$('#style').val() || !$('#spaces').val() || jQuery('#attributes').find('.mage-error').length > 0){
            $('#tab_attributes').trigger('click');
        }
    });
    $('#save').on('click', function() {
        // Your custom click event logic here
        if(!$('#city').val() || !$('#country_id').val() || !$('#style').val() || !$('#spaces').val() || jQuery('#attributes').find('.mage-error').length > 0){
            $('#tab_attributes').trigger('click');
        }
    });

    // jQuery(document).on('click', '.eviaglobal_brand_brand_form_areas_collection_collection_brand_collection_update_modal._show .page-actions #save', function() {
    // setTimeout(function(){
    //     if(!jQuery('.eviaglobal_brand_brand_form_areas_collection_collection_brand_collection_update_modal').hasClass('_show')){
    //         location.reload(true);
    //     }
    //     },2000);  
    // });
});