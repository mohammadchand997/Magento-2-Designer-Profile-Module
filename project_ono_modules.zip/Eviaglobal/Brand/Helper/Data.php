<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Eviaglobal\Brand\Helper;

use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Eviaglobal\Product\Model\Product\Attribute\Source\Country;

class Data extends AbstractHelper
{

    const XML_PATH_IS_ACTIVE = "brand/general/is_active";

    const XML_PATH_ASSOCIATED_ATTRIBUTE = "brand/general/attribute";

   /**
   * @var \Magento\Framework\App\Config\ScopeConfigInterface
   */
   protected $scopeConfig;

    /**
     * \Magento\Eav\Model\Entity\Attribute
     */
    protected $attribute;

    protected $eavConfig;

    /**
     * @var \Magento\Framework\Mail\Template\TransportBuilder
     */
    protected $_transportBuilder;

    protected $_logger;

    /**
     * @param \Magento\Framework\App\Helper\Context $context
     */
    public function __construct(
        \Magento\Framework\App\Helper\Context $context,
        ScopeConfigInterface $scopeConfig,
        \Magento\Eav\Model\Entity\Attribute $attribute,
        \Magento\Eav\Model\Config $eavConfig,
        \Magento\Framework\Filesystem\Driver\File $fileDriver,
        \Magento\Store\Model\StoreManagerInterface $storeManager, 
        \Magento\Framework\App\ResourceConnection $resource,
        \Magento\Framework\Mail\Template\TransportBuilder $transportBuilder,
        \Psr\Log\LoggerInterface $logger,
        Country $country
    ){
        $this->scopeConfig = $scopeConfig;
        $this->attribute   = $attribute;
        $this->eavConfig   = $eavConfig;
        $this->fileDriver = $fileDriver;
        $this->_storeManager = $storeManager;
        $this->_resource = $resource;
        $this->_transportBuilder = $transportBuilder;
        $this->_logger = $logger;
        $this->country = $country;
        parent::__construct($context);
    }

    public function getAttribute(){
        return $this->scopeConfig->getValue(
            self::XML_PATH_ASSOCIATED_ATTRIBUTE, 
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

    public function getAttributeOptions(){
        $attributeId = $this->getAttribute();
        if($attributeId){
            $attributeCode = $this->attribute->load($attributeId)->getAttributeCode();
            if($attributeCode){
                $attribute = $this->eavConfig->getAttribute('catalog_product', $attributeCode);
                $options = $attribute->getSource()->getAllOptions();
                $options[0]['label'] = "-- Please Select --";
                return $options;
            }
        }
        return [];
    }

    /**
     * @return bool
     */
    public function isEnabled()
    {
        return $this->scopeConfig->getValue(
            self::XML_PATH_IS_ACTIVE, 
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

    public function createCustomProduct($value='')
    {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $product = $objectManager->create('\Magento\Catalog\Model\Product');
        $directory = $objectManager->get('\Magento\Framework\Filesystem\DirectoryList');
        $_categoryFactory = $objectManager->get('Magento\Catalog\Model\CategoryFactory');
        $categoryTitle = 'Brands';
        $collection = $_categoryFactory->create()->getCollection()->addFieldToFilter('name', ['in' => $categoryTitle]);
        $categoryId = '489';
        if ($collection->getSize()) {
            $categoryId = $collection->getFirstItem()->getId();
        }
        $attributes = isset($value['attributes']) ? (array) json_decode($value['attributes']) : '';
        $spaces = isset($attributes['spaces']) ? $attributes['spaces'] : '';
        $styles = isset($attributes['styles']) ? $attributes['styles'] : '';
        $acrylic_stone = isset($attributes['acrylic_stone']) ? $attributes['acrylic_stone'] : '';

        $url = '';

        try {
            $setSKU = str_replace(' ', '_', $value['name']);
            $urlKey = $this->createUrlKey($value['name'], $setSKU);
            $sku = $this->createUrlKey($value['name'], $setSKU);
            $product->setName($value['name']);
            $product->setTypeId('simple');
            $product->setAttributeSetId(35);
            $product->setSku($sku);
            $product->setStatus(1);
            $product->setWebsiteIds([1,2,3]);
            $product->setVisibility(2);
            $product->setPrice($value['price']);
            $product->setUrlKey($urlKey);
            $product->setCategoryIds([$categoryId]);
            $product->setCustomSupplier($value['custom_suuplier']);
            if ($this->fileDriver->isExists($url)){
                $product->addImageToMediaGallery($url, array('image', 'small_image', 'thumbnail'), false, false);
            }
            // $product->setImage($value['image']);
            // $product->setSmallImage($value['image']);
            // $product->setThumbnail($value['image']);
            $product->setData('spaces', $spaces);
            $product->setData('styles', $styles);
            $product->setData('acrylic_stone', $acrylic_stone);
            $product->setStockData(
                [
                    'use_config_manage_stock' => 0,
                    'manage_stock' => 1,
                    'min_sale_qty' => 1,
                    'max_sale_qty' => 2,
                    'is_in_stock' => 1,
                    'qty' => 1
                ]
            );
            $product->save();
            return $product->getId();
        } catch (Exception $ex) {
            echo $e->getMessage();
        }
    }

    public function addProductImageById($productId, $image)
    {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $directory = $objectManager->get('\Magento\Framework\Filesystem\DirectoryList');
        $url = $directory->getPath('pub').$image;
        $product = $objectManager->create('Magento\Catalog\Model\Product')->load($productId);
        if ($this->fileDriver->isExists($url)){
            $product->addImageToMediaGallery($url, array('image', 'small_image', 'thumbnail'), false, false);
        }
        $product->save();
    }

    public function addProductAttributeValueById($productId, $attributeCode, $attributeValue)
    {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $product = $objectManager->create('Magento\Catalog\Model\Product')->load($productId);
        if($attributeValue!="") {            
            $product->setData($attributeCode, $attributeValue);   
        }
        $product->save();
    }

    public function increment_string($str, $separator = '-', $first = 1)
    {
        preg_match('/(.+)'.$separator.'([0-9]+)$/', $str, $match);
        return isset($match[2]) ? $match[1].$separator.($match[2] + 1) : $str.$separator.$first;
    }

    public function createUrlKey($title, $sku) 
    {
        $url = preg_replace('#[^0-9a-z]+#i', '-', $title);
        $urlKey = strtolower($url);
        $storeId = (int) $this->_storeManager->getStore()->getStoreId();
        
        $isUnique = $this->checkUrlKeyDuplicates($sku, $urlKey, $storeId);
        if ($isUnique) {
            return $urlKey . '-' . time();
        } else {
            return $urlKey . '-' . time();
        }
    }

    /*
     * Function to check URL Key Duplicates in Database
     */

    private function checkUrlKeyDuplicates($sku, $urlKey, $storeId) 
    {
        $urlKey .= '.html';

        $connection = $this->_resource->getConnection(\Magento\Framework\App\ResourceConnection::DEFAULT_CONNECTION);

        $tablename = $connection->getTableName('url_rewrite');
        $sql = $connection->select()->from(
                        ['url_rewrite' => $connection->getTableName('url_rewrite')], ['request_path', 'store_id']
                )->joinLeft(
                        ['cpe' => $connection->getTableName('catalog_product_entity')], "cpe.entity_id = url_rewrite.entity_id"
                )->where('request_path IN (?)', $urlKey)
                ->where('store_id IN (?)', $storeId)
                ->where('cpe.sku not in (?)', $sku);

        $urlKeyDuplicates = $connection->fetchAssoc($sql);

        if (!empty($urlKeyDuplicates)) {
            return false;
        } else {
            return true;
        }
    }

    public function getBusinessCategoryFieldOptions(){

        $attribute = $this->eavConfig->getAttribute('catalog_product', 'business_category');
        $options = $attribute->getSource()->getAllOptions();
        $optionsExists = array();
        return $options;
    }

    public function getAreYouFieldOptions(){

        $attribute = $this->eavConfig->getAttribute('catalog_product', 'are_you');
        $options = $attribute->getSource()->getAllOptions();
        $optionsExists = array();
        return $options;
    }

    public function getStylesOptions(){

        $attribute = $this->eavConfig->getAttribute('catalog_product', 'styles');
        $options = $attribute->getSource()->getAllOptions();
        $optionsExists = array();
        return $options;
    }

    public function deleteProductById($id)
    {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance(); 
        $product = $objectManager->create('Magento\Catalog\Model\Product');
        $product->load($id)->delete();
    }

    public function sendEmail($post, $templateId, $to, $from='')
    {
        $setFrom = $from ?? 'general';
        $post['store'] = $this->_storeManager->getStore();
        try {
            $store = $this->_storeManager->getStore()->getId();
            $transport = $this->_transportBuilder->setTemplateIdentifier($templateId)
                    ->setTemplateOptions(['area' => 'frontend', 'store' => $store])
                    ->setTemplateVars($post)
                    ->setFrom('general')
                    ->addTo($to['email'], $to['name'])
                    ->addAttachment(null, null, null)
                    ->getTransport();
            $transport->sendMessage();
            return true;
        } catch (\Exception $e) {
            $this->_logger->critical($e->getMessage());
            return false;
        }
    }

    public function updateProductPriceById($id, $price)
    {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance(); 
        $product = $objectManager->create('Magento\Catalog\Model\Product');
        $product->load($id);
        $product->setPrice($price);
        $product->save();
    }

    public function getScopeConfigValue($path)
    {
        return $this->scopeConfig->getValue($path, 
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

    public function getCountryById($id)
    {
        $getAllOptions = $this->country->getAllOptions();

        $countryName = '';
        foreach ($getAllOptions as $key => $value) {
            if($value['value'] == $id){
                $countryName = $value['label'];
            }
        }
        return $countryName;
    }

    public function enableDisableProductById($productId, $status=true)
    {        
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance(); 
        $productRepository = $objectManager->create(\Magento\Catalog\Api\ProductRepositoryInterface::class);
        $product = $productRepository->getById($productId);
        $stores = $objectManager->get(\Magento\Store\Model\StoreManagerInterface::class)->getStores();
        foreach ($stores as $store) {
            $storeId = $store->getStoreId();
            $product->setStoreId($storeId);
            if($status){
                $product->setStatus(\Magento\Catalog\Model\Product\Attribute\Source\Status::STATUS_ENABLED);
            }else{
                $product->setStatus(\Magento\Catalog\Model\Product\Attribute\Source\Status::STATUS_DISABLED);
            }
            $product->save($product);
        }        
    }

    public function getPropductCustomOptions($product, $_options)
    {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $getData = [];
        foreach ($_options as $_option):
            $customOptions = $objectManager->get('Magento\Catalog\Model\Product\Option')->getProductOptionCollection($product);
            $setoptions = [];
            foreach($customOptions as $optionKey => $optionVal):
                $getSelectedOptions = [];
                foreach($optionVal->getValues() as $valuesVal) {
                    $id = $valuesVal->getId();
                    $sku = $valuesVal->getSku();
                    $selectedOptions = [];

                    $optionProduct = $this->getProductBySku($sku);
                    if($optionProduct){
                        $customOptions = $optionProduct->getOptions();
                        
                        if (!empty($customOptions) && $id == $_option['option_value']) {
                            foreach ($customOptions as $customOption) {
                                if ($customOption->getValues()) {
                                    $optionTitle = $customOption->getTitle();
                                    $selectedValues = $customOption->getValues();
                                    $selectedOptionValue = '';
                                    foreach ($selectedValues as $selectedValue) {
                                        if ($selectedValue->getIsDefault()) {
                                            $selectedOptionValue = $selectedValue->getTitle();
                                        }
                                    }
                                    $optionData['value'] = $selectedOptionValue;
                                    $optionData['label'] = $optionTitle;
                                    array_push($selectedOptions, $optionData);
                                }
                            }
                        }
                    }
                    $getSelectedOptions[] = $selectedOptions;
                }
                $setoptions = array_filter($getSelectedOptions);
            endforeach;
            $data['getSelectedOptions'] = isset($setoptions) && !empty($setoptions) ? $setoptions[0] : '';
            array_push($getData, $data);
        endforeach;
     
        return $getData;
    }

    public function getProductBySku($sku)
    {
        if(!$sku){
            return null;
        }
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance(); 
        $productRepository = $objectManager->create(\Magento\Catalog\Api\ProductRepositoryInterface::class);
        try {
            $product = $productRepository->get($sku);
            return $product;
        } catch (\Magento\Framework\Exception\NoSuchEntityException $e) {
            // Handle the case when the product with the specified SKU does not exist
            return null;
        }
        
    }
}
