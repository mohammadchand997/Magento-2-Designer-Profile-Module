<?php
declare(strict_types=1);

namespace Eviaglobal\Brand\Ui\Component\Listing\Collection\Column;

use Magento\Framework\View\Element\UiComponent\ContextInterface;
use Magento\Framework\View\Element\UiComponentFactory;
use Magento\Ui\Component\Listing\Columns\Column;
use Magento\Framework\UrlInterface;

/**
 * Prepare actions column for customer addresses grid
 */
class Actions extends Column
{

    /**
     * @var UrlInterface
     */
    private $urlBuilder;

    /**
     * @param ContextInterface $context
     * @param UiComponentFactory $uiComponentFactory
     * @param UrlInterface $urlBuilder
     * @param array $components
     * @param array $data
     */
    public function __construct(
        ContextInterface $context,
        UiComponentFactory $uiComponentFactory,
        UrlInterface $urlBuilder,
        array $components = [],
        array $data = []
    ) {
        $this->urlBuilder = $urlBuilder;
        parent::__construct($context, $uiComponentFactory, $components, $data);
    }

    /**
     * Prepare Data Source
     *
     * @param array $dataSource
     * @return array
     */
    public function prepareDataSource(array $dataSource): array
    {
        if (isset($dataSource['data']['items'])) {
            foreach ($dataSource['data']['items'] as &$item) {
                $name = $this->getData('name');
                if (isset($item['collection_id'])) {
                    $item[$name]['edit'] = [
                        'callback' => [
                            [
                                'provider' => 'eviaglobal_brand_brand_form.areas.collection.collection'
                                    . '.brand_collection_update_modal.update_brand_collection_form_loader',
                                'target' => 'destroyInserted',
                            ],
                            [
                                'provider' => 'eviaglobal_brand_brand_form.areas.collection.collection'
                                    . '.brand_collection_update_modal',
                                'target' => 'openModal',
                            ],
                            [
                                'provider' => 'eviaglobal_brand_brand_form.areas.collection.collection'
                                    . '.brand_collection_update_modal.update_brand_collection_form_loader',
                                'target' => 'render',
                                'params' => [
                                    'collection_id' => $item['collection_id'],
                                ],
                            ]
                        ],
                        'href' => '#',
                        'label' => __('Edit'),
                        'hidden' => false,
                    ];

                    /*$item[$name]['delete'] = [
                        'href' => $this->urlBuilder->getUrl(
                            'eviaglobal_brand/collection/delete',
                            ['parent_id' => $item['parent_id'], 'collection_id' => $item['collection_id']]
                        ),
                        'label' => __('Delete'),
                        'isAjax' => true,
                        'confirm' => [
                            'title' => __('Delete collection'),
                            'message' => __('Are you sure you want to delete the collection?')
                        ]
                    ];*/
                }
            }
        }

        return $dataSource;
    }
}
