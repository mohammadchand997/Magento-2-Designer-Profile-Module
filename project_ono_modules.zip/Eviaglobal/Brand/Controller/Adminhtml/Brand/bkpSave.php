<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Eviaglobal\Brand\Controller\Adminhtml\Brand;

use Magento\Framework\Exception\LocalizedException;
use Eviaglobal\Brand\Helper\Data;
use Eviaglobal\Brand\Model\BrandFactory;
use Eviaglobal\Brand\Model\BrandDataFactory;
use Magento\Store\Model\StoreManagerInterface;

class Save extends \Magento\Backend\App\Action
{

    protected $dataPersistor;

    /**
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Framework\App\Request\DataPersistorInterface $dataPersistor
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\App\Request\DataPersistorInterface $dataPersistor,
        \Magento\Framework\Event\ManagerInterface $eventManager,
        Data $helperData,
        BrandFactory $brandFactory,
        StoreManagerInterface $storeManager,
        BrandDataFactory $brandDataFactory
    ) {
        $this->dataPersistor = $dataPersistor;
        $this->helperData = $helperData;
        $this->brandFactory = $brandFactory;
        $this->_eventManager = $eventManager;
        $this->_storeManager = $storeManager;
        $this->brandDataFactory = $brandDataFactory;
        parent::__construct($context);
    }

    /**
     * Save action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        $data = $this->getRequest()->getPostValue();   
        // echo "<pre>";
        // print_r($data)     ;
        // die("SDfsdf");
        if ($data) {            
            //$url_key = $title;
            $store=$data['general']['store']?$data['general']['store']:0;
            $option_id = isset($data['general']['option_id']) ? $data['general']['option_id'] : '';
            $discounts = isset($data['general']['discounts']) ? json_encode($data['general']['discounts']) : json_encode([]);
            $media_gallery = isset($data['media']['media_gallery']) ? json_encode($data['media']['media_gallery']) : '';
            $listing_banner = isset($data['media']['listing_banner'][0]['name']) ? $data['media']['listing_banner'][0]['name'] : '';
            $home_banner = isset($data['media']['home_banner'][0]['name']) ? $data['media']['home_banner'][0]['name'] : '';
            $attributes = (array)$data['attributes'];
            $isProfileReady = $data['general']['is_profile_ready'];
            $display_on_frontend = $data['general']['display_on_frontend'];
            // $store_id=$request->getParam('store');
            $formData = [
                'store_id'=> $data['general']['store']?$data['general']['store']:0, 
                'title' => $data['general']['title'],
                'email' => $data['general']['email'],
                'website_url' => $data['general']['website_url'],
                'city'       => $attributes['city'],
                'option_id'  => $option_id,
                'country_id' => $attributes['country_id'],
                'about'      => $data['general']['about'],
                'logo'       => $data['media']['logo'][0]['name'],
                'banner'     => $data['media']['banner'][0]['name'],
                'discounts'  => $discounts,
                'price_from' => $data['attributes']['price_from'],
                'price_to'   => $data['attributes']['price_to'],
                'attributes' => json_encode($data['attributes'], JSON_UNESCAPED_SLASHES),
                'media_gallery' => $media_gallery,
                'meta_title' => $data['others_detail']['meta_title'],
                'meta_keywords' => $data['others_detail']['meta_keywords'],
                'meta_description' => $data['others_detail']['meta_description'],
                'display_on_frontend' => $display_on_frontend,
                'show_on_homepage' => $data['general']['show_on_homepage'],
                'is_profile_ready' => $isProfileReady,
                'listing_banner' => $listing_banner,
                'home_banner' => $home_banner,
                'contact_name' => $data['others_detail']['contact_name'],
                'designation' => $data['others_detail']['designation'],
                'business_category' => $data['others_detail']['business_category'],
                'are_you' => $data['others_detail']['are_you'],
                'postcode' => $data['others_detail']['postcode'],
                'address_1' => $data['others_detail']['address_1'],
                'address_2' => $data['others_detail']['address_2'],
                'phone' => $data['others_detail']['phone'],
                'email_c' => $data['others_detail']['email_c']

            ];

            $productData = [
                'name' => $data['general']['title'],
                'image' => $data['media']['logo'][0]['url'],
                'attributes' => json_encode($data['attributes']),
            ];

            $id = $this->getRequest()->getParam('brand_id');
                 
            $model = $this->_objectManager->create(\Eviaglobal\Brand\Model\Brand::class)->load($id);
            if (!$model->getId() && $id) {
                $this->messageManager->addErrorMessage(__('This Brand no longer exists.'));
                return $resultRedirect->setPath('*/*/');
            }
            $brandDataFactory=$this->brandDataFactory->create();
            if($model->getId()){
                $title = str_replace(' ', '-', strtolower($data['general']['title'])); 
                $checkBrand = $this->isBrandExsist($model->getId(), $data['general']['url_key']);  
                $url_key = !empty($checkBrand) ? $title.'-'.count($checkBrand) : $title;
                $formData['url_key'] = $url_key;                
                $product = $this->_objectManager->create('Magento\Catalog\Model\Product')->load($model['product_id']);
                if($product->getId()){                    
                    $this->helperData->updateProductPriceById($product->getId(), $data['price_to']);
                    $this->helperData->addProductImageById($model['product_id'], $data['media']['logo'][0]['url']);
                    $attributes = (array)$data['attributes'];
                    $attributes['city'] = $model->getId();
                    $attributes['brand_country'] = $attributes['country_id'];
                    $attributes['custom_supplier'] = $model->getId();
                    foreach ($attributes as $key => $value) {
                        $this->helperData->addProductAttributeValueById($model['product_id'], $key, $value);
                    }
                    $productStatus = $display_on_frontend ? true : false;
                    $this->helperData->enableDisableProductById($product->getId(), $productStatus);   
                }else{
                    $this->setBrandProduct($productData, $model->getId());
                }
                $data['brand_id'] = $model->getId();
                $this->_eventManager->dispatch(
                    'controller_action_postdispatch_eviaglobal_brand_brand_save', 
                    ['data' => $data]
                );

                //send mail if profile is ready
                if(empty($model['is_profile_ready']) && $isProfileReady){
                    $this->sendProfileReadyMail($formData);
                }        

                $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
                $resource = $objectManager->get('Magento\Framework\App\ResourceConnection');
                $connection = $resource->getConnection();
                $tableName = $resource->getTableName('eviaglobal_brand_data');
                $sql = "Select value_id FROM " . $tableName.' where brand_id='.$model->getId().' and store_id='.$store;
                $result = $connection->fetchAll($sql);
                if ($result) {
                    $formData['value_id']=$result[0]['value_id'];					
                }      

				$model->setData($formData); 
				$model->save();   
				$brandDataFactory->setData($formData);
				$brandDataFactory->save();  
            } 
            else {
				try {
					$model->setData($formData);   
					$model->save();
					$formData['brand_id']=$model->getId();
					$brandDataFactory->setData($formData);
					$brandDataFactory->save();
					$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
					$storeManager = $objectManager->create('\Magento\Store\Model\StoreManagerInterface');
					$storeIds = array_keys($storeManager->getStores());
					foreach ($storeIds as $storeId) {
						if($storeId!=0) {
							$formData['brand_id']=$model->getId();
							$formData['store_id']=$storeId;
							$brandDataFactory->setData($formData);
							$model->save();
							$brandDataFactory->save();
						}
					}
				
					$lastId = $model->getId();
					if(!$id && $lastId){
						$this->setBrandProduct($productData, $lastId);
					}
					$this->messageManager->addSuccessMessage(__('Brand Details Saved Successfully.'));
					$this->dataPersistor->clear('eviaglobal_brand_brand');
					$this->dataPersistor->clear('eviaglobal_brand_data');
					if ($this->getRequest()->getParam('back')) {
						return $resultRedirect->setPath('*/*/edit', ['brand_id' => $lastId]);
					}
					return $resultRedirect->setPath('*/*/');
				} catch (LocalizedException $e) {
					$this->messageManager->addErrorMessage($e->getMessage());
				} catch (\Exception $e) {
					$this->messageManager->addExceptionMessage($e, __('Something went wrong while saving the Brand.'));
				}
        	}
        
            $this->dataPersistor->set('eviaglobal_brand_brand', $data);
            $this->dataPersistor->set('eviaglobal_brand_data', $data);
            return $resultRedirect->setPath('*/*/edit', ['brand_id' => $this->getRequest()->getParam('brand_id')]);
        } 
        return $resultRedirect->setPath('*/*/');
    }

    public function isBrandExsist($brand_id, $title){
        $brandDataFactory = $this->_objectManager->create("Eviaglobal\Brand\Model\BrandDataFactory");
        $barnd = $brandDataFactory->create()->getCollection()
        ->addFieldToFilter('brand_id', array('neq' => $brand_id))
        ->addFieldToFilter('url_key', $title);
        return $barnd->getData();
    }

    public function setBrandProduct($productData, $brandId){

        $productId = $this->helperData->createCustomProduct($productData);
        $resource = $this->_objectManager->get('Magento\Framework\App\ResourceConnection');
        $connection = $resource->getConnection();
        $tableName = $resource->getTableName('eviaglobal_brand_data');
        $sql = "Update ".$tableName." Set product_id =".$productId." where brand_id = ".$brandId."";
        $connection->query($sql);
    }

    public function sendProfileReadyMail($formData='')
    {
        $storeName = $this->_storeManager->getStore()->getCode();
        $templateId = $storeName == 'fr' ? '84' : '84';
        $to = [
            'name' => $formData['contact_name'],
            'email' => $formData['email'],
        ];
        $this->helperData->sendEmail($formData, $templateId, $to);
    }

    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Eviaglobal_Brand::Brand_save');
    }
}

