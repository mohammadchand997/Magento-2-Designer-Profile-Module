<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Eviaglobal\Brand\Controller\Adminhtml\Collection;

use Psr\Log\LoggerInterface;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Controller\Result\Json;


class Save extends \Magento\Backend\App\Action
{

    /**
     * @var LoggerInterface
     */
    private $logger;

    /**
     * @var JsonFactory
     */
    private $resultJsonFactory;

    /**
     * @var \Eviaglobal\Brand\Api\VideoRepositoryInterface
     */
    private $videoRepository;

    /**
     * @var \Magento\Framework\Api\DataObjectHelper
     */
    private $dataObjectHelper;

    /**
     * @var \Eviaglobal\Brand\Api\Data\VideoInterface
     */
    private $videoDataFactory;


    /**
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Framework\App\Request\DataPersistorInterface $dataPersistor
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Eviaglobal\Brand\Api\VideoRepositoryInterface $videoRepository,
        LoggerInterface $logger,
        JsonFactory $resultJsonFactory,
        \Magento\Framework\Api\DataObjectHelper $dataObjectHelper,
        \Eviaglobal\Brand\Api\Data\VideoInterface $videoDataFactory
    ) {
        parent::__construct($context);
        $this->videoRepository   = $videoRepository;
        $this->logger            = $logger;
        $this->resultJsonFactory = $resultJsonFactory;
        $this->dataObjectHelper  = $dataObjectHelper;
        $this->videoDataFactory  = $videoDataFactory;
    }

    /**
     * Save action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute(): Json
    {
        $brandId    = $this->getRequest()->getParam('parent_id', false);
        $collectionId    = $this->getRequest()->getParam('collection_id', false);
        $postedData = $this->getRequest()->getParams();
         //$jashd = (array)json_decode($postedData);
         //echo "<pre>"; print_r($this->getRequest()->getParams()); die;
        $error   = false;
        try{
            $model = $this->_objectManager->create(\Eviaglobal\Brand\Model\Collection::class)->load($collectionId);
            //echo $model->getId();die();
            if (!$model->getId() && $collectionId) {
                $error = true;
                $message = __('This collection no longer exists.');
            }
            $gallery_collection = isset($postedData['gallery_collection']) ? json_encode($postedData['gallery_collection']) : json_encode([]);
            $collection_videos = isset($postedData['collection_videos']) ? json_encode($postedData['collection_videos']) : json_encode([]);
            $data = [
                'parent_id'  => $postedData['parent_id'],
                'title'      => $postedData['title'],
                'sort_order' => $postedData['sort_order'],
                'downloadable_file' => $postedData['downloadable_file'][0]['name'],
                'gallery_collection' => $gallery_collection,
                'videos'     => $collection_videos
            ];
            //echo "<pre>"; print_r($postedData); die;
            if(isset($postedData['brand_products']) && $postedData['brand_products']){
                $jsonString = json_encode(array_values(json_decode($postedData['brand_products'], true)));
                // Decode the JSON string into an array
                $array = json_decode($jsonString);

                // Find and remove the specified value
                $removeValue = "on";
                $array = array_diff($array, [$removeValue]);

                // Encode the modified array back to JSON
                $updatedJson = array_filter(array_values($array));

                $products = array_filter($updatedJson);
                $associativeArray = array();

                foreach ($products as $value) {
                    $associativeArray[$value] = $value;
                }

                $data['products'] = json_encode($associativeArray);
            }
            //echo "<pre>"; print_r($data); die;

            if(isset($postedData['selected_brand_products']) && $postedData['selected_brand_products']){
                $jsonString = json_encode(array_values(json_decode($postedData['selected_brand_products'], true)));
                // Decode the JSON string into an array
                $array = json_decode($jsonString);

                // Find and remove the specified value
                $removeValue = "on";
                $array = array_diff($array, [$removeValue]);
                $array = array_filter($array);

                if(!empty($array)){
                    // Encode the modified array back to JSON
                    $updatedJson = json_encode(array_values($array));
                    $selected_brand_products = $updatedJson;
                }else{
                    $selected_brand_products = '';
                }
                
            }
           
            if($model->getId()){

                $geProducts = $model->getProducts() ? (array)json_decode($model->getProducts()) : [];

                if(isset($selected_brand_products) && !empty($selected_brand_products)){

                    $postProducts = (array)json_decode($selected_brand_products);

                    $products = array_diff($geProducts, $postProducts);
                    //echo "<pre>";print_r($postProducts);die();

                }else{
                    $postProducts = isset($data['products']) ? (array)json_decode($data['products']) : [];
                    $products = array_unique(array_merge($geProducts, $postProducts));
                }



                $products = array_filter($products);

                $associativeArray = array();

                foreach ($products as $value) {
                    $associativeArray[$value] = $value;
                }

                //echo "<pre>"; print_r(json_encode($associativeArray)); die;
                
                $data['products'] = json_encode($associativeArray);

            }

            //echo "<pre>"; print_r($data); die;
            
            if($collectionId){
                $data['collection_id'] = $collectionId;
            }
            $model->setData($data);
            if ($collectionId) {
                $message = __('Brand collection has been updated.');
            } else {
                $message = __('New collection has been added.');
            }
            $savedCollection =$model->save();
            $collectionId = $savedCollection->getCollectionId();
            if($collectionId){
                $productIds = (array)json_decode($savedCollection['products']);
                foreach ($productIds as $key => $productId) {
                    $this->setBrandCollectionInProduct($productId, $savedCollection['parent_id'], $collectionId);
                }
            }
        } catch (NoSuchEntityException $e) {
            $this->logger->critical($e);
            $error = true;
            $message = __('There is no collection with such id.');
        } catch (LocalizedException $e) {
            $error = true;
            $message = __($e->getMessage());
            $this->logger->critical($e);
        } catch (\Exception $e) {
            $error = true;
            $message = __('We can\'t change brand collection right now :- '.$e->getMessage());
            $this->logger->critical($e);
        }
        $collectionId    = empty($collectionId) ? null : $collectionId;
        $resultJson = $this->resultJsonFactory->create();
        $resultJson->setData(
            [
                'messages' => $message,
                'error' => $error,
                'data' => [
                    'collection_id' => $collectionId
                ]
            ]
        );

        return $resultJson;
    }

    public function setBrandCollectionInProduct($productId, $brandId, $collectionId)
    {
        $product = $this->_objectManager->create('Magento\Catalog\Model\Product')->load($productId);
        if ($product->getId()) {
            
            $product->setData('custom_supplier', $brandId);
            $product->setData('custom_supplier_collection', $collectionId);
            $product->save();
        }
    }
}

