<?php
declare(strict_types=1);

namespace Eviaglobal\Brand\Controller\Adminhtml\Video;

use Magento\Backend\App\Action;
use Magento\Framework\App\Action\HttpPostActionInterface;
use Magento\Framework\Controller\Result\Json;
use Magento\Framework\Controller\Result\JsonFactory;
use Eviaglobal\Brand\Api\VideoRepositoryInterface;
use Psr\Log\LoggerInterface;

/**
 * Button for deletion of brand video in admin
 */
class Delete extends Action implements HttpPostActionInterface
{

    /**
     * @var VideoRepositoryInterface
     */
    private $videoRepository;

    /**
     * @var JsonFactory
     */
    private $resultJsonFactory;

    /**
     * @var LoggerInterface
     */
    private $logger;

    /**
     * @param Action\Context $context
     * @param VideoRepositoryInterface $videoRepository
     * @param JsonFactory $resultJsonFactory
     * @param LoggerInterface $logger
     */
    public function __construct(
        Action\Context $context,
        VideoRepositoryInterface $videoRepository,
        JsonFactory $resultJsonFactory,
        LoggerInterface $logger
    ) {
        parent::__construct($context);
        $this->videoRepository   = $videoRepository;
        $this->resultJsonFactory = $resultJsonFactory;
        $this->logger = $logger;
    }

    /**
     * Delete brand video action
     *
     * @return Json
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function execute(): Json
    {
        $brandId = $this->getRequest()->getParam('parent_id', false);
        $videoId = $this->getRequest()->getParam('video_id', false);
        $error = false;
        $message = '';
        
        if ($videoId && $this->videoRepository->get($videoId)->getParentId() === $brandId) {
            try {
                $this->videoRepository->deleteById($videoId);
                $message = __('You deleted the address.');
            } catch (\Exception $e) {
                $error = true;
                $message = __('We can\'t delete the address right now.');
                $this->logger->critical($e);
            }
        }

        $resultJson = $this->resultJsonFactory->create();
        $resultJson->setData(
            [
                'message' => $message,
                'error' => $error,
            ]
        );

        return $resultJson;
    }
}
