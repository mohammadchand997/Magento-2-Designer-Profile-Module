<?php
namespace Eviaglobal\Brand\Controller\Catalog;

use Magento\Framework\View\Result\PageFactory;  
use Magento\Framework\Controller\Result\JsonFactory;
use Eviaglobal\Catalog\Model\CatalogFactory;
use Eviaglobal\Brand\Helper\Data;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Store\Model\ScopeInterface;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\Mail\Template\TransportBuilder;


class Save extends \Magento\Framework\App\Action\Action
{
    private $logger;

    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Psr\Log\LoggerInterface $logger,
        JsonFactory $resultJsonFactory,
        CatalogFactory $catalogFactory,
        Data $helperData,
        ScopeConfigInterface $scopeConfig,
        StoreManagerInterface $storeManager,
        TransportBuilder $transportBuilder
        
    ) {
        $this->resultJsonFactory = $resultJsonFactory;
        $this->catalogFactory = $catalogFactory;
        $this->helperData = $helperData;
        $this->scopeConfig = $scopeConfig;
        $this->_storeManager = $storeManager;
        $this->_transportBuilder = $transportBuilder;
        $this->_logger = $logger;
        parent::__construct($context);
    }
    public function execute()
    {
        $result = $this->resultJsonFactory->create();
        if ($this->getRequest()->isAjax()) 
        {
            $params = $this->getRequest()->getParams();
                try{
                    $catalogFactory = $this->catalogFactory->create();
                    $catalogFactory->setData($params);
                    $catalogFactory->save();
                    $lastId = $catalogFactory->getId();
                    if($lastId){
                        $this->sendDownloadCatalogMail($params);
                    }
                    $response =[
                        'status' => true,
                        'message' => '',
                    ];
                }catch(Exception $ex){
                    $response =[
                        'status' => false,
                        'message' => __('Something went wrong'),
                    ];
                }
            return $result->setData($response);
        }
    }

    public function sendDownloadCatalogMail($formData='')
    {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $countryName = $objectManager->create('\Magento\Directory\Model\Country')->load($formData['country_id'])->getName();
        $region_id = isset($formData['region_id']) ? $formData['region_id'] : '';
        $region = $objectManager->create('Magento\Directory\Model\Region')
                        ->load($region_id);
        $formData['country'] = $countryName;
        $formData['state'] = $region ? $region->getName() : $formData['region'];

        //$name = $this->helperData->getScopeConfigValue('trans_email/ident_support/name');
        $email = $this->helperData->getScopeConfigValue('brand/general/supplier_confirmation');

        $storeName = $this->_storeManager->getStore()->getCode();
        $templateId = $storeName == 'fr' ? '85' : '85';
        $to = [
            'name' => '',
            'email' => $email,
        ];
        $this->helperData->sendEmail($formData, $templateId, $to);
    }
}