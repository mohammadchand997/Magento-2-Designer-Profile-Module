<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Eviaglobal\Brand\Controller\Profile;

use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;

class AjaxCollection extends \Magento\Framework\App\Action\Action
{
    /**
 * @var \RB\Vendor\Model\Design
 */
private $design;

/**
 * @var PageFactory
 */
protected $resultPageFactory;

/**
 * @var \Magento\Framework\UrlInterface 
 */
protected $urlModel;

/**
 * @param Context $context
 * @param \RB\Vendor\Model\Design $design
 * @param PageFactory $resultPageFactory
 */
public function __construct(
    Context $context, 
    PageFactory $resultPageFactory,
    \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
    \Magento\Framework\View\Result\LayoutFactory $resultLayoutFactory

) {        
    $this->resultPageFactory = $resultPageFactory;
    $this->resultJsonFactory = $resultJsonFactory;
    $this->_resultLayoutFactory = $resultLayoutFactory;
    parent::__construct($context);
}


    public function execute()
    {
       $result =  $this->_resultLayoutFactory->create();
       $response =  $this->resultJsonFactory->create();
       $resultPage = $this->resultPageFactory->create();
        if ($this->getRequest()->isAjax()) 
        {

            $block = $resultPage->getLayout()
                ->createBlock('Eviaglobal\Brand\Block\CollectionInfo')
                ->setTemplate('Eviaglobal_Brand::profile/ajaxcollectioninfo.phtml')
                ->toHtml();

            $response->setData($block);
            return $response;
        }
    }
}


