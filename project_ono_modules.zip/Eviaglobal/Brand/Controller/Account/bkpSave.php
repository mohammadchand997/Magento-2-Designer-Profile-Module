<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Eviaglobal\Brand\Controller\Account;

use Magento\Contact\Model\ConfigInterface;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\Request\DataPersistorInterface;
use Magento\Framework\Controller\Result\Redirect;
use Magento\Framework\Exception\LocalizedException;
use Psr\Log\LoggerInterface;
use Magento\Framework\App\ObjectManager;
use Magento\Framework\DataObject;
use Magento\Framework\View\Result\PageFactory;
use Eviaglobal\Brand\Helper\Data;
use Eviaglobal\Brand\Model\BrandFactory;
use Magento\Store\Model\StoreManagerInterface;


class Save extends \Magento\Framework\App\Action\Action
{
    /**
     * @var DataPersistorInterface
     */
    private $dataPersistor;

    /**
     * @var Context
     */
    private $context;

    /**
     * @var LoggerInterface
     */
    private $logger;

    /**
     * @param Context $context
     * @param ConfigInterface $contactsConfig
     * @param DataPersistorInterface $dataPersistor
     * @param LoggerInterface $logger
     */
    public function __construct(
        Context $context,
        ConfigInterface $contactsConfig,
        DataPersistorInterface $dataPersistor,
        LoggerInterface $logger = null,
        Data $helperData,
        BrandFactory $brandFactory,
        StoreManagerInterface $storeManager,
    ) {
        parent::__construct($context);
        $this->context = $context;
        $this->dataPersistor = $dataPersistor;
        $this->helperData = $helperData;
        $this->brandFactory = $brandFactory;
        $this->_storeManager = $storeManager;
        $this->logger = $logger ?: ObjectManager::getInstance()->get(LoggerInterface::class);
    }

    /**
     * Customer register form page
     *
     * @return \Magento\Framework\Controller\Result\Redirect|\Magento\Framework\View\Result\Page
     */
    public function execute()
    {
        if (!$this->getRequest()->isPost()) {
            return $this->resultRedirectFactory->create()->setPath('*/*/');
        }
        $params = $this->getRequest()->getParams();
        //echo "<pre>";print_r($params);die();
        
        try {
            if(!$params['g-recaptcha-response']){
                $this->messageManager->addErrorMessage(__('CAPTCHA validation failed.'));
            }else{
                $model = $this->_objectManager->create(\Eviaglobal\Brand\Model\Brand::class);
                $title = str_replace(' ', '-', strtolower($params['company_name'])); 
                $brands = $this->isBrandExsist($title);
                $url_key = $brands ? $this->helperData->increment_string($title) : $title;

                $getRegionID = isset($params['region_id']) ? $params['region_id'] : $params['region'];

                $formData = [
                    'contact_name' => $params['contact_name'],
                    'title' => $params['company_name'],
                    'designation' => $params['designation'],
                    'website_url' => $params['website'],
                    'business_category' => $params['business_category'],
                    'are_you' => $params['are_you'],
                    'country_id' => $params['brand_country'],
                    'region_id' => $getRegionID,
                    'city' => $params['city'],
                    'postcode' => $params['postcode'],
                    'address_1' => $params['address_1'],
                    'address_2' => $params['address_2'],
                    'phone' => $params['phone'],
                    'email' => $params['email'],
                    'email_c'       => $params['email_c'],
                    'url_key' => $url_key
                ];
                $productData = [
                    'name' => $params['company_name'],
                    'image' => ''
                ];
                $model->setData($formData);
                $model->save();
                $lastId = $model->getId();
                if($lastId){
                    $this->sendSupplierEmailConfirmation($formData);
                    $productId = $this->helperData->createCustomProduct($productData);
                    $resource = $this->_objectManager->get('Magento\Framework\App\ResourceConnection');
                    $connection = $resource->getConnection();
                    $tableName = $resource->getTableName('eviaglobal_brand_brand');
                    $sql = "Update ".$tableName." Set product_id =".$productId." where brand_id = ".$lastId."";
                    $connection->query($sql);
                }
                $this->messageManager->addSuccessMessage(
                    __('Thank you for your details. One of our agents will contact you shortly for further details.')
                );
                $this->dataPersistor->clear('contact_us');
            }
        } catch (LocalizedException $e) {
            $this->messageManager->addErrorMessage($e->getMessage());
            $this->dataPersistor->set('contact_us', $this->getRequest()->getParams());
        } catch (\Exception $e) {
            $this->logger->critical($e);
            $this->messageManager->addErrorMessage(
                __('An error occurred while processing your form. Please try again later.')
            );
            $this->dataPersistor->set('contact_us', $this->getRequest()->getParams());
        }
        return $this->resultRedirectFactory->create()->setPath('brand/account/create');
    }

    public function isBrandExsist($title){
        $barnd = $this->brandFactory->create()->getCollection()->addFieldToFilter('url_key', $title);
        return $barnd->getData();
    }

    public function sendSupplierEmailConfirmation($formData='')
    {
        $fromName = $this->helperData->getScopeConfigValue('trans_email/ident_support/name');
        $fromEmail = $this->helperData->getScopeConfigValue('brand/general/supplier_confirmation');

        $storeName = $this->_storeManager->getStore()->getCode();
        $templateId = $storeName == 'fr' ? '83' : '83';
        $to = [
            'name' => $formData['contact_name'],
            'email' => $formData['email'],
        ];

        $from = [
            'name' => $fromName,
            'email' => $fromEmail,
        ];
        $this->helperData->sendEmail($formData, $templateId, $to, $from);
    }

}

