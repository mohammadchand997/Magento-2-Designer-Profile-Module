<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Eviaglobal\Brand\Model;

use Eviaglobal\Brand\Api\Data\BrandInterface;
use Magento\Framework\Model\AbstractModel;

class Brand extends AbstractModel implements BrandInterface
{

    /**
     * @inheritDoc
     */
    public function _construct()
    {
        $this->_init(\Eviaglobal\Brand\Model\ResourceModel\Brand::class);
    }

    /**
     * @inheritDoc
     */
    public function getBrandId()
    {
        return $this->getData(self::BRAND_ID);
    }

    /**
     * @inheritDoc
     */
    public function setBrandId($brandId)
    {
        return $this->setData(self::BRAND_ID, $brandId);
    }

    /**
     * @inheritDoc
     */
    public function getTitle()
    {
        return $this->getData(self::TITLE);
    }

    /**
     * @inheritDoc
     */
    public function setTitle($title)
    {
        return $this->setData(self::TITLE, $title);
    }

    /**
     * @inheritDoc
     */
    public function getLogo()
    {
        return $this->getData(self::LOGO);
    }

    /**
     * @inheritDoc
     */
    public function setLogo($logo)
    {
        return $this->setData(self::LOGO, $logo);
    }

    /**
     * @inheritDoc
     */
    public function getBanner()
    {
        return $this->getData(self::BANNER);
    }

    /**
     * @inheritDoc
     */
    public function setBanner($banner)
    {
        return $this->setData(self::BANNER, $banner);
    }

    /**
     * @inheritDoc
     */
    public function getAbout()
    {
        return $this->getData(self::ABOUT);
    }

    /**
     * @inheritDoc
     */
    public function setAbout($about)
    {
        return $this->setData(self::ABOUT, $about);
    }

    /**
     * @inheritDoc
     */
    public function getWebsiteUrl()
    {
        return $this->getData(self::WEBSITE_URL);
    }

    /**
     * @inheritDoc
     */
    public function setWebsiteUrl($websiteUrl)
    {
        return $this->setData(self::WEBSITE_URL, $websiteUrl);
    }

    /**
     * @inheritDoc
     */
    public function getOptionId()
    {
        return $this->getData(self::OPTION_ID);
    }

    /**
     * @inheritDoc
     */
    public function setOptionId($optionId)
    {
        return $this->setData(self::OPTION_ID, $optionId);
    }

    /**
     * @inheritDoc
     */
    public function getVideos()
    {
        return $this->getData(self::VIDEOS);
    }

    /**
     * @inheritDoc
     */
    public function setVideos($videos)
    {
        return $this->setData(self::VIDEOS, $videos);
    }

    /**
     * @inheritDoc
     */
    public function getCity()
    {
        return $this->getData(self::CITY);
    }

    /**
     * @inheritDoc
     */
    public function setCity($city)
    {
        return $this->setData(self::CITY, $city);
    }

    /**
     * @inheritDoc
     */
    public function getCountry()
    {
        return $this->getData(self::COUNTRY);
    }

    /**
     * @inheritDoc
     */
    public function setCountry($country)
    {
        return $this->setData(self::COUNTRY, $country);
    }
}

