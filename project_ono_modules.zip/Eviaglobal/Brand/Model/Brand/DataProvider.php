<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Eviaglobal\Brand\Model\Brand;

use Eviaglobal\Brand\Model\ResourceModel\Brand\CollectionFactory;
use Magento\Framework\App\Request\DataPersistorInterface;
use Magento\Ui\DataProvider\AbstractDataProvider;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\Filesystem\Driver\File;
use Magento\Framework\Filesystem\DirectoryList;

class DataProvider extends AbstractDataProvider
{

    /**
     * @var DataPersistorInterface
     */
    protected $dataPersistor;

    /**
     * @var array
     */
    protected $loadedData;
    /**
     * @inheritDoc
     */
    protected $collection;

    protected $storeManager;


    /**
     * @param string $name
     * @param string $primaryFieldName
     * @param string $requestFieldName
     * @param CollectionFactory $collectionFactory
     * @param DataPersistorInterface $dataPersistor
     * @param array $meta
     * @param array $data
     */
    public function __construct(
        $name,
        $primaryFieldName,
        $requestFieldName,
        CollectionFactory $collectionFactory,
        DataPersistorInterface $dataPersistor,
        StoreManagerInterface $storeManager,
        File $fileDriver,
        DirectoryList $directory,
        array $meta = [],
        array $data = []
    ) {
        $this->collection    = $collectionFactory->create();
        $this->dataPersistor = $dataPersistor;
        $this->storeManager  = $storeManager;
        $this->fileDriver = $fileDriver;
        $this->directory = $directory;
        parent::__construct($name, $primaryFieldName, $requestFieldName, $meta, $data);
    }

    /**
     * @inheritDoc
     */
    public function getData()
    {
        if (isset($this->loadedData)) {
            return $this->loadedData;
        }
        
        $items = $this->collection->getItems();
        foreach ($items as $model) {
            $this->loadedData[$model->getId()] = $model->getData();
        }
        $data = $this->dataPersistor->get('eviaglobal_brand_brand');
        $data = $this->dataPersistor->get('eviaglobal_brand_data');
        if (!empty($data)) {
            $model = $this->collection->getNewEmptyItem();
            $model->setData($data);
            $this->loadedData[$model->getId()] = $model->getData();
            $this->dataPersistor->clear('eviaglobal_brand_data');            
        }
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $request = $objectManager->get('Magento\Framework\App\Request\Http');  
        $params=$request->getParams();
        $store=0;
        if(array_key_exists("store",$params)) {
            $store = $params['store'];
        }
        // echo '<pre>'; print_r($this->loadedData[$model->getId()]);  die("Ssss");;
        if(isset($model) && isset($this->loadedData[$model->getId()])){            
            $brandData = $objectManager->create("Eviaglobal\Brand\Model\BrandData");
            $resource = $objectManager->get('Magento\Framework\App\ResourceConnection');
            $connection = $resource->getConnection();
            $tableName = $resource->getTableName('eviaglobal_brand_data');
            $sql = "Select * FROM " . $tableName.' where brand_id='.$model->getId().' and store_id='.$store;
            $result = $connection->fetchAll($sql);
            if($result) {
                $this->loadedData[$model->getId()]['general']['display_on_frontend'] = $result[0]['display_on_frontend'];
                $this->loadedData[$model->getId()]['general']['show_on_homepage'] = $result[0]['show_on_homepage'];
                $this->loadedData[$model->getId()]['general']['is_profile_ready'] = $result[0]['is_profile_ready'];
                $this->loadedData[$model->getId()]['general']['title'] = $result[0]['title'];
                $this->loadedData[$model->getId()]['general']['email'] = $result[0]['email'];
                $this->loadedData[$model->getId()]['general']['url_key'] = $result[0]['url_key'];
                $this->loadedData[$model->getId()]['general']['about'] = $result[0]['about'];
                $this->loadedData[$model->getId()]['general']['website_url'] = $result[0]['website_url'];
                $this->loadedData[$model->getId()]['general']['store'] = $store;    
                // $this->loadedData[$model->getId()]['general']['option_id'] = $this->loadedData[$model->getId()]['option_id'];
                if($result[0]['attributes']){
                    $attributes = (array)json_decode($result[0]['attributes']);
                    $attributes['city'] = $result[0]['city'];
                    $attributes['country_id'] = $result[0]['country_id'];
                    $this->loadedData[$model->getId()]['attributes'] = $attributes;
                }
                $get = 'not null';                
                $this->loadedData[$model->getId()]['general']['discounts'] = json_decode($result[0]['discounts']);
                if($result[0]['discounts'] == 'null'){
                    $this->loadedData[$model->getId()]['general']['discounts'] = [];
                }
                // $logo = $this->directory->getPath('pub').'/media/tmp/imageUploader/images/'.$this->loadedData[$model->getId()]['logo'];
                if($result[0]['logo']){
                    $this->loadedData[$model->getId()]['media']['logo'][0]['url'] = $this->getMediaUrl().$result[0]['logo'];
                    $this->loadedData[$model->getId()]['media']['logo'][0]['name'] = $result[0]['logo'];
                    $this->loadedData[$model->getId()]['media']['logo'][0]['type'] = 'image/png';
                    $this->loadedData[$model->getId()]['media']['logo'][0]['size'] = 1234;
                    $this->loadedData[$model->getId()]['media']['logo'][0]['exists'] = 1;  
                }
    
                if($result[0]['banner']){
                    $this->loadedData[$model->getId()]['media']['banner'][0]['url'] = $this->getMediaUrl().$result[0]['banner'];
                    $this->loadedData[$model->getId()]['media']['banner'][0]['name'] = $result[0]['banner'];
                    $this->loadedData[$model->getId()]['media']['banner'][0]['type'] = 'image/png';
                    $this->loadedData[$model->getId()]['media']['banner'][0]['size'] = 1234;
                    $this->loadedData[$model->getId()]['media']['banner'][0]['exists'] = 1;
                }
                
                if($result[0]['listing_banner']){    
                    $this->loadedData[$model->getId()]['media']['listing_banner'][0]['url'] = $this->getMediaUrl().$result[0]['listing_banner'];
                    $this->loadedData[$model->getId()]['media']['listing_banner'][0]['name'] = $result[0]['listing_banner'];
                    $this->loadedData[$model->getId()]['media']['listing_banner'][0]['type'] = 'image/png';
                    $this->loadedData[$model->getId()]['media']['listing_banner'][0]['size'] = 1234;
                    $this->loadedData[$model->getId()]['media']['listing_banner'][0]['exists'] = 1;
                }
    
                if($result[0]['home_banner']){
                    $this->loadedData[$model->getId()]['media']['home_banner'][0]['url'] = $this->getMediaUrl().$result[0]['home_banner'];
                    $this->loadedData[$model->getId()]['media']['home_banner'][0]['name'] = $result[0]['home_banner'];
                    $this->loadedData[$model->getId()]['media']['home_banner'][0]['type'] = 'image/png';
                    $this->loadedData[$model->getId()]['media']['home_banner'][0]['size'] = 1234;
                    $this->loadedData[$model->getId()]['media']['home_banner'][0]['exists'] = 1;
                }
                
                $this->loadedData[$model->getId()]['attributes']['price_from'] = $result[0]['price_from'];
                $this->loadedData[$model->getId()]['attributes']['price_to'] = $result[0]['price_to'];
                $this->loadedData[$model->getId()]['others_detail']['contact_name'] = $result[0]['contact_name'];
                $this->loadedData[$model->getId()]['others_detail']['designation'] = $result[0]['designation'];
                $this->loadedData[$model->getId()]['others_detail']['business_category'] = $result[0]['business_category'];
                $this->loadedData[$model->getId()]['others_detail']['are_you'] = $result[0]['are_you'];
                $this->loadedData[$model->getId()]['others_detail']['postcode'] = $result[0]['postcode'];
                $this->loadedData[$model->getId()]['others_detail']['address_1'] = $result[0]['address_1'];
                $this->loadedData[$model->getId()]['others_detail']['address_2'] = $result[0]['address_2'];
                $this->loadedData[$model->getId()]['others_detail']['phone'] = $result[0]['phone'];
                $this->loadedData[$model->getId()]['others_detail']['email_c'] = $result[0]['email_c'];
                $this->loadedData[$model->getId()]['others_detail']['meta_title'] = $result[0]['meta_title'];
                $this->loadedData[$model->getId()]['others_detail']['meta_keywords'] = $result[0]['meta_keywords'];
                $this->loadedData[$model->getId()]['others_detail']['meta_description'] = $result[0]['meta_description'];    
                $getMediaGallery = $result[0]['media_gallery'];
                $decodeMediaGallery = $getMediaGallery ? json_decode($getMediaGallery) : '';    
                $this->loadedData[$model->getId()]['media']['media_gallery'] = $decodeMediaGallery;
            }    
        }
        return $this->loadedData;
    }

    public function getMediaUrl()
    {
        $mediaUrl = $this->storeManager->getStore()
            ->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA).'tmp/imageUploader/images/';
        return $mediaUrl;
    }
}

