<?php

namespace Eviaglobal\Brand\Block;

use Magento\Framework\View\Element\Template;
use Eviaglobal\Brand\Api\BrandRepositoryInterface;
use Eviaglobal\Brand\Model\ResourceModel\Collection\CollectionFactory;
use Magento\Framework\Serialize\SerializerInterface;
use Magento\Catalog\Model\ResourceModel\Product\CollectionFactory as ProductCollectionFactory;
use Magento\Catalog\Block\Product\ImageBuilder;
use Magento\Eav\Model\Config;
use Magento\Catalog\Model\ResourceModel\Eav\Attribute;
use Magento\Catalog\Model\Product;
use Magento\Catalog\Pricing\Price\FinalPrice;
use Magento\Framework\Pricing\Render;
use Eviaglobal\Brand\Model\BrandFactory;

class CollectionInfo extends \Magento\Contact\Block\ContactForm
{
    protected $brandRepository;

    protected $storeManager;

    protected $currentBrand;

    protected $mediaUrl;

    protected $countryFactory;

    protected $collectionFactory;

    protected $serializer;

    protected $productCollectionFactory;

    protected $imageBuilder;

    protected $priceHelper;

    protected $eavConfig;

    protected $attributeResource;

    protected $brandFactory;

    public function __construct(
        Template\Context $context,
        \Magento\Directory\Block\Data $directoryBlock,
        BrandRepositoryInterface $brandRepository,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Directory\Model\CountryFactory $countryFactory,
        CollectionFactory $collectionFactory,
        SerializerInterface $serializer,
        ProductCollectionFactory $productCollectionFactory,
        ImageBuilder $imageBuilder,
        \Magento\Framework\Pricing\Helper\Data $priceHelper,
        Config $eavConfig,
        Attribute $attributeResource,
        BrandFactory $brandFactory,
        array $data = []
    ){
        parent::__construct($context, $data);
        $this->_isScopePrivate = true;
        $this->directoryBlock  = $directoryBlock;
        $this->brandRepository = $brandRepository;
        $this->storeManager    = $storeManager;
        $this->countryFactory  = $countryFactory;
        $this->collectionFactory = $collectionFactory;
        $this->serializer = $serializer;
        $this->productCollectionFactory = $productCollectionFactory;
        $this->imageBuilder = $imageBuilder;
        $this->priceHelper  = $priceHelper;
        $this->eavConfig = $eavConfig;
        $this->attributeResource = $attributeResource;
        $this->brandFactory = $brandFactory;
        $this->_initBrand();
    }

    protected function _initBrand(){
        $id = $this->getRequest()->getParam('id');
        $this->mediaUrl = $this->storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA );
        if($id && empty($this->currentBrand)){
            $this->currentBrand = $this->brandRepository->get($id);
        }
    }

    public function getCollections(){
        $id = $this->getRequest()->getParam('last_producer_id');
        $parent_id = $this->getRequest()->getParam('parnet_id');
        if($id){
            $collection = $this->collectionFactory->create();
            if($parent_id){
                $collection->addFieldToFilter('parent_id', $parent_id);
            }
            $collection->addFieldToFilter('sort_order', array('gt' => $id));
            $collection->setOrder('sort_order','ASC')->load();
            $collection->getSelect()->limit(1);
            /*$collection->getSelect()->assemble();
    $collection->getSelect()->__toString();
    echo $collection->getSelect(); 
    die();*/
            // echo "<pre>";
            // print_r($collection->getData());
            // die;
            return $collection->getData();
        }
        
        return [];
    }

    public function getDownloadFileCompleteUrl($filename){
        return $this->getDownloadFilePrefixUrl().$filename;
    }

    public function getCollectionProducts($field){
        $productIds = $this->serializer->unserialize($field);
       
        if($productIds){
            $collection = $this->productCollectionFactory->create();
            $collection->addAttributeToSelect('*');
            $collection->getSelect()->reset(\Magento\Framework\DB\Select::WHERE);
            $collection->addFieldToFilter('entity_id', array('in' => $productIds));
            $collection->load();
            
            return $collection; 
        }
        return [];
    }

    public function getProductPrice(Product $product)
    {
        $priceRender = $this->getPriceRender();

        $price = '';
        if ($priceRender) {
            $price = $priceRender->render(
                FinalPrice::PRICE_CODE,
                $product,
                [
                    'include_container' => true,
                    'display_minimal_price' => true,
                    'zone' => Render::ZONE_ITEM_LIST,
                    'list_category_page' => true
                ]
            );
        }

        return $price;
    }

    protected function getDownloadFilePrefixUrl(){
        return $this->mediaUrl.'collection/files/';
    }

    public function getImage($product, $imageId, $attributes = [])
    {
        return $this->imageBuilder->create($product, $imageId, $attributes);
    }

    protected function getPriceRender()
    {
        return $this->getLayout()->getBlock('product.price.render.default')
            ->setData('is_product_list', true);
    }

    public function getBrandId(){

        $urlKey = $this->getRequest()->getParam('key');
        $barnd = $this->brandFactory->create()->getCollection()->addFieldToFilter('url_key', $urlKey)->getFirstItem();
        return $barnd->getId();
    }

}
