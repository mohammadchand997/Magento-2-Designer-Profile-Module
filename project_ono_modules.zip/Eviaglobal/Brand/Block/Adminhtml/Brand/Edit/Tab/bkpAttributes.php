<?php

declare(strict_types=1);

namespace Eviaglobal\Brand\Block\Adminhtml\Brand\Edit\Tab;

use \Magento\Catalog\Model\ResourceModel\Product\Attribute\CollectionFactory;
use Magento\Catalog\Model\Product\Attribute\Repository;

class Attributes extends \Magento\Backend\Block\Widget\Form\Generic implements
    \Magento\Ui\Component\Layout\Tabs\TabInterface
{

	protected $attributeCollectionFactory;

	protected $attributeRepository;

	public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Data\FormFactory $formFactory,
        CollectionFactory $attributecollectionFactory,
        Repository $attributeRepository,
        array $data = [],
    ){
    	$this->attributeCollectionFactory = $attributecollectionFactory;
    	$this->attributeRepository = $attributeRepository;
        parent::__construct($context, $registry, $formFactory, $data);
    }

    /**
     * Prepare form before rendering HTML
     *
     * @return $this
     */
    protected function _prepareForm()
    {
    	$model = $this->_coreRegistry->registry('eviaglobal_brand_brand');
        $form = $this->addAttributes($model);
        $this->setForm($form);
    	return parent::_prepareForm();
    }

    protected function addAttributes($model){

    	$attributeCollection = $this->attributeCollectionFactory->create();
    	$attributeCollection->addFieldToFilter(
             'additional_table.used_in_brand_form',
             ['eq' => 1]
        );
    	
    	/** @var \Magento\Framework\Data\Form $form */
        $form = $this->_formFactory->create();

        $fieldset = $form->addFieldset('attributes',[]);

        $fieldset->addField(
            'price_from',
            'text',
            [
                'name'           => 'price_from',
                'label'          => __('Price From'),
                'title'          => __('Price From'),
                'required'       => true,
                'data-form-part' => 'eviaglobal_brand_brand_form',
                'value'          => isset($model) ? $model->getPriceFrom() : ''
            ]
        );

        $fieldset->addField(
            'price_to',
            'text',
            [
                'name'           => 'price_to',
                'label'          => __('Price To'),
                'title'          => __('Price To'),
                'required'       => true,
                'data-form-part' => 'eviaglobal_brand_brand_form',
                'value'          => isset($model) ? $model->getPriceTo() : ''
            ]
        );

        foreach($attributeCollection->getItems() as $item){
        	$attributeCode = $item->getAttributeCode();
        	$attributeName = $item->getFrontendLabel();
        	
        	if($item->getFrontendInput() == 'select' || $item->getFrontendInput() == 'multiselect'){
        		$this->_addAttributeByCode($fieldset, $attributeCode, $attributeName, $model);
        	}	
        }
        return $form;
    }

    protected function _addAttributeByCode($fieldSet, $attributeCode, $attributeLabel, $model){
    	$options = [];
    	foreach($this->attributeRepository->get($attributeCode)->getOptions() as $option){
    		if($option->getData()['value'] == '') 
    			continue;
            $options[] = $option->getData();
        }
       	$selectedAttributes = $model->getId() ? json_decode($model->getAttributes(), true) : '';
        
        $fieldSet->addField(
            "$attributeCode",
            'multiselect',
            [
                'name'           => "attributes[{$attributeCode}]",
                'label'          => __($attributeLabel),
                'title'          => __($attributeLabel),
                'values'         => $options,
                'required'       => true,
                'data-form-part' => 'eviaglobal_brand_brand_form',
                'value'          => isset($selectedAttributes[$attributeCode]) ? $selectedAttributes[$attributeCode] : ''
            ]
        );
        return $this;
    }	

	/**
     * @inheritdoc
     *
     * @codeCoverageIgnore
     */
    public function getTabClass()
    {
        return null;
    }

    /**
     * @inheritdoc
     */
    public function getTabUrl()
    {
        return null;
    }

    /**
     * @inheritdoc
     */
    public function isAjaxLoaded()
    {
        return false;
    }

    /**
     * @inheritdoc
     */
    public function getTabLabel()
    {
        return __('Attributes');
    }

    /**
     * @inheritdoc
     */
    public function getTabTitle()
    {
        return __('Attributes');
    }

    /**
     * @inheritdoc
     */
    public function canShowTab()
    {
        return true;
    }

    /**
     * @inheritdoc
     */
    public function isHidden()
    {
        return false;
    }
}