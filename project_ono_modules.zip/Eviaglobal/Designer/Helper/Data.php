<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Eviaglobal\Designer\Helper;

use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Customer\Api\GroupRepositoryInterface;
use Magento\Customer\Model\Session as CustomerSession;

class Data extends AbstractHelper
{

    const XML_PATH_IS_ACTIVE = "designer/general/is_active";


   /**
   * @var \Magento\Framework\App\Config\ScopeConfigInterface
   */
   protected $scopeConfig;

    /**
     * \Magento\Eav\Model\Entity\Attribute
     */
    protected $attribute;

    protected $eavConfig;

    /**
     * @param \Magento\Framework\App\Helper\Context $context
     */
    public function __construct(
        \Magento\Framework\App\Helper\Context $context,
        ScopeConfigInterface $scopeConfig,
        \Magento\Eav\Model\Entity\Attribute $attribute,
        \Magento\Eav\Model\Config $eavConfig,
        GroupRepositoryInterface $groupRepository,
        CustomerSession $customerSession,
        \Magento\Store\Model\StoreManagerInterface $storeManager, 
        \Magento\Framework\App\ResourceConnection $resource
    ){
        $this->scopeConfig = $scopeConfig;
        $this->attribute   = $attribute;
        $this->eavConfig   = $eavConfig;
        $this->groupRepository = $groupRepository;
        $this->customerSession = $customerSession;
        $this->_storeManager = $storeManager;
        $this->_resource = $resource;
        parent::__construct($context);
    }

    /**
     * @return bool
     */
    public function isEnabled()
    {
        return $this->scopeConfig->getValue(
            self::XML_PATH_IS_ACTIVE, 
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

    public function getGroupName(){

        $groupname = '';
        if($this->customerSession->isLoggedIn()){
            $getGroupId = $this->customerSession->getCustomer()->getGroupId();
            $group = $this->groupRepository->getById($getGroupId);
            $groupname = $group->getCode();
        }
        return $groupname;

    }

    public function createDesignerProduct($value='')
    {        
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $productRepository = $objectManager->get('\Magento\Catalog\Model\ProductRepository');
        $product = $objectManager->create('\Magento\Catalog\Model\Product');
        $_categoryFactory = $objectManager->get('Magento\Catalog\Model\CategoryFactory');
        $categoryTitle = 'Designer';
        $collection = $_categoryFactory->create()->getCollection()->addFieldToFilter('name', ['in' => $categoryTitle]);
        $categoryId = '476';
        if ($collection->getSize()) {
            $categoryId = $collection->getFirstItem()->getId();
        }

        try {

            $setSKU = str_replace(' ', '_', $value['name']);
            $urlKey = $this->createUrlKey($value['name'], $setSKU);
            $sku = $this->createUrlKey($value['name'], $setSKU);
            // echo "<pre>";
            // print_r($value);
            // die("hgjhghgkhkhgb");
            $product->setName($value['name']);
            $product->setTypeId('simple');
            $product->setAttributeSetId(36);
            $product->setSku($sku);
            $product->setStatus(1);
            $product->setWebsiteIds([1,2,3]);
            $product->setVisibility(2);
            $product->setPrice('1');
            $product->setUrlKey($urlKey);
            $product->setCategoryIds([$categoryId]);
            // $product->setStockData(
            //     [
            //         'use_config_manage_stock' => 0,
            //         'manage_stock' => 1,
            //         'min_sale_qty' => 1,
            //         'max_sale_qty' => 2,
            //         'is_in_stock' => 1,
            //         'qty' => 100
            //     ]
            // );
            // if (isset($value['attributes']) && $value['attributes']) {
            //     foreach ($value['attributes'] as $key => $value) {
            //         $product->setData($key, $value);

            //     }
            // }
            // $product->setData('is_independent', '');
            $product = $productRepository->save($product);
            $stockItem = $objectManager->get('\Magento\CatalogInventory\Api\Data\StockItemInterfaceFactory')->create();
            $stockItem->setQty(100); // Set the initial quantity
            $stockItem->setIsInStock(true);
            $stockItem->setManageStock(true);
            $stockItem->setProductId($product->getId());
            $objectManager->get('\Magento\CatalogInventory\Api\StockRegistryInterface')->updateStockItemBySku($product->getSku(), $stockItem);
            return $product->getId();
        } catch (Exception $ex) {
            echo $e->getMessage();
        }
    }
    public function createUrlKey($title, $sku) 
    {
        $url = preg_replace('#[^0-9a-z]+#i', '-', $title);
        $urlKey = strtolower($url);
        $storeId = (int) $this->_storeManager->getStore()->getStoreId();
        $isUnique = $this->checkUrlKeyDuplicates($sku, $urlKey, $storeId);
        if ($isUnique) {
            return $urlKey . '-' . time();
        } else {
            return $urlKey . '-' . time();
        }
    }

    /*
     * Function to check URL Key Duplicates in Database
     */

    private function checkUrlKeyDuplicates($sku, $urlKey, $storeId) 
    {
        $urlKey .= '.html';
        $connection = $this->_resource->getConnection(\Magento\Framework\App\ResourceConnection::DEFAULT_CONNECTION);
        $tablename = $connection->getTableName('url_rewrite');
        $sql = $connection->select()->from(
                        ['url_rewrite' => $connection->getTableName('url_rewrite')], ['request_path', 'store_id']
                )->joinLeft(
                        ['cpe' => $connection->getTableName('catalog_product_entity')], "cpe.entity_id = url_rewrite.entity_id"
                )->where('request_path IN (?)', $urlKey)
                ->where('store_id IN (?)', $storeId)
                ->where('cpe.sku not in (?)', $sku);

        $urlKeyDuplicates = $connection->fetchAssoc($sql);

        if (!empty($urlKeyDuplicates)) {
            return false;
        } else {
            return true;
        }
    }
}