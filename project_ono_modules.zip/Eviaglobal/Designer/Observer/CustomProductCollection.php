<?php
namespace Eviaglobal\Designer\Observer;

use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Event\Observer;
use Magento\Framework\App\Request\Http;

class CustomProductCollection implements ObserverInterface
{

    public function __construct(
        Http $request,
    ) {
        $this->request = $request;
    }

    public function execute(Observer $observer)
    {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $storeManager=$objectManager->create('Magento\Store\Model\StoreManagerInterface');
        $storeId= $storeManager->getStore()->getId();
        $designerCategoryId = 476;
        $currentCategoryId = (int)$this->getRequest()->getParam('id');
        $productCollection = $observer->getEvent()->getCollection();
        $productCollection->addAttributeToSelect('*');
        $designer = $objectManager->create('\Eviaglobal\Designer\Model\DesignerData')
                        ->getCollection()
                        ->addFieldToFilter('store_id',$storeId)
                         ->addFieldToFilter('display_on_frontend', '1')
                        ->getData();
        $designerProductIds = array_column($designer, 'product_id');
        if ($currentCategoryId == $designerCategoryId) {
            $productCollection->addAttributeToFilter('entity_id', ['in' => $designerProductIds]);
        }
        return $this;
    }

    protected function getRequest()
    {
        return $this->request;
    }
}