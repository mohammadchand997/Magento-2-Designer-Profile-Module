<?php
declare(strict_types=1);

namespace Eviaglobal\Designer\Observer\Customer;

class RegisterSuccess implements \Magento\Framework\Event\ObserverInterface
{

    protected $request;
    protected $subscriberFactory;

    public function __construct(
        \Magento\Framework\App\Request\Http $request,
        \Magento\Newsletter\Model\SubscriberFactory $subscriberFactory
    )
    {
        $this->request = $request;
        $this->subscriberFactory = $subscriberFactory;
    }

    /**
     * Execute observer
     *
     * @param \Magento\Framework\Event\Observer $observer
     * @return void
     */
    public function execute(
        \Magento\Framework\Event\Observer $observer
    ) {
        $postData = $this->request->getPost();
        $customer=$observer->getEvent()->getCustomer();
        // echo "<pre>";
        // print_r($postData);
        // die;
        if(!empty($postData['ca_is_subscribed'])){
            //$this->subscriberFactory->create()->subscribe($postData['email']);
            $subscriber = $this->subscriberFactory->create();
            $subscriber->subscribeCustomerById($customer->getId());
        }
    }
}