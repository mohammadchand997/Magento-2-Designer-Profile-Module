<?php
declare(strict_types=1);

namespace Eviaglobal\Designer\Api\Data;

interface ProjectSearchResultsInterface extends \Magento\Framework\Api\SearchResultsInterface
{

    /**
     * Get Project list.
     * @return \Eviaglobal\Designer\Api\Data\ProjectInterface[]
     */
    public function getItems();

    /**
     * Set Title list.
     * @param \Eviaglobal\Designer\Api\Data\ProjectInterface[] $items
     * @return $this
     */
    public function setItems(array $items);
}

