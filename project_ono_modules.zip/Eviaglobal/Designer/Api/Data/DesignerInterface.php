<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Eviaglobal\Designer\Api\Data;

interface DesignerInterface
{

    const DESIGNER_ID = 'designer_id';
    const ABOUT = 'about';
    const COUNTRY = 'country';
    const WEBSITE_URL = 'website_url';
    const CUSTOMER_ID = 'customer_id';
    const TITLE = 'title';
    const BANNER = 'banner';
    const CITY = 'city';
    const LOGO = 'logo';

    /**
     * Get designer_id
     * @return string|null
     */
    public function getDesignerId();

    /**
     * Set designer_id
     * @param string $designerId
     * @return \Eviaglobal\Designer\Designer\Api\Data\DesignerInterface
     */
    public function setDesignerId($designerId);

    /**
     * Get title
     * @return string|null
     */
    public function getTitle();

    /**
     * Set title
     * @param string $title
     * @return \Eviaglobal\Designer\Designer\Api\Data\DesignerInterface
     */
    public function setTitle($title);

    /**
     * Get logo
     * @return string|null
     */
    public function getLogo();

    /**
     * Set logo
     * @param string $logo
     * @return \Eviaglobal\Designer\Designer\Api\Data\DesignerInterface
     */
    public function setLogo($logo);

    /**
     * Get banner
     * @return string|null
     */
    public function getBanner();

    /**
     * Set banner
     * @param string $banner
     * @return \Eviaglobal\Designer\Designer\Api\Data\DesignerInterface
     */
    public function setBanner($banner);

    /**
     * Get about
     * @return string|null
     */
    public function getAbout();

    /**
     * Set about
     * @param string $about
     * @return \Eviaglobal\Designer\Designer\Api\Data\DesignerInterface
     */
    public function setAbout($about);

    /**
     * Get website_url
     * @return string|null
     */
    public function getWebsiteUrl();

    /**
     * Set website_url
     * @param string $websiteUrl
     * @return \Eviaglobal\Designer\Designer\Api\Data\DesignerInterface
     */
    public function setWebsiteUrl($websiteUrl);

    /**
     * Get customer_id
     * @return string|null
     */
    public function getCustomerId();

    /**
     * Set customer_id
     * @param string $customerId
     * @return \Eviaglobal\Designer\Designer\Api\Data\DesignerInterface
     */
    public function setCustomerId($customerId);


    /**
     * Get city
     * @return string|null
     */
    public function getCity();

    /**
     * Set city
     * @param string $city
     * @return \Eviaglobal\Designer\Designer\Api\Data\DesignerInterface
     */
    public function setCity($city);

    /**
     * Get country
     * @return string|null
     */
    public function getCountry();

    /**
     * Set country
     * @param string $country
     * @return \Eviaglobal\Designer\Designer\Api\Data\DesignerInterface
     */
    public function setCountry($country);
}

