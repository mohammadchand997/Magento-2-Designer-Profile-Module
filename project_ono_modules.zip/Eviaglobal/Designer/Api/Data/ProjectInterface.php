<?php
declare(strict_types=1);

namespace Eviaglobal\Designer\Api\Data;

interface ProjectInterface
{

    const TITLE = 'Title';
    const PROJECT_ID = 'project_id';
    const DESCRIPTION = 'description';

    /**
     * Get project_id
     * @return string|null
     */
    public function getProjectId();

    /**
     * Set project_id
     * @param string $projectId
     * @return \Eviaglobal\Designer\Project\Api\Data\ProjectInterface
     */
    public function setProjectId($projectId);

    /**
     * Get Title
     * @return string|null
     */
    public function getTitle();

    /**
     * Set Title
     * @param string $title
     * @return \Eviaglobal\Designer\Project\Api\Data\ProjectInterface
     */
    public function setTitle($title);

    /**
     * Get description
     * @return string|null
     */
    public function getDescription();

    /**
     * Set description
     * @param string $description
     * @return \Eviaglobal\Designer\Project\Api\Data\ProjectInterface
     */
    public function setDescription($description);
}

