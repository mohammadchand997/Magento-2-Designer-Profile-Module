<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Eviaglobal\Designer\Api;

use Magento\Framework\Api\SearchCriteriaInterface;

interface DesignerRepositoryInterface
{

    /**
     * Save Designer
     * @param \Eviaglobal\Designer\Api\Data\DesignerInterface $designer
     * @return \Eviaglobal\Designer\Api\Data\DesignerInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(
        \Eviaglobal\Designer\Api\Data\DesignerInterface $designer
    );

    /**
     * Retrieve Designer
     * @param string $designerId
     * @return \Eviaglobal\Designer\Api\Data\DesignerInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function get($designerId);

    /**
     * Retrieve Designer matching the specified criteria.
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \Eviaglobal\Designer\Api\Data\DesignerSearchResultsInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
    );

    /**
     * Delete Designer
     * @param \Eviaglobal\Designer\Api\Data\DesignerInterface $designer
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function delete(
        \Eviaglobal\Designer\Api\Data\DesignerInterface $designer
    );

    /**
     * Delete Designer by ID
     * @param string $designerId
     * @return bool true on success
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function deleteById($designerId);
}

