<?php
declare(strict_types=1);

namespace Eviaglobal\Designer\Api;

use Magento\Framework\Api\SearchCriteriaInterface;

interface ProjectRepositoryInterface
{

    /**
     * Save Project
     * @param \Eviaglobal\Designer\Api\Data\ProjectInterface $project
     * @return \Eviaglobal\Designer\Api\Data\ProjectInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(
        \Eviaglobal\Designer\Api\Data\ProjectInterface $project
    );

    /**
     * Retrieve Project
     * @param string $projectId
     * @return \Eviaglobal\Designer\Api\Data\ProjectInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function get($projectId);

    /**
     * Retrieve Project matching the specified criteria.
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \Eviaglobal\Designer\Api\Data\ProjectSearchResultsInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
    );

    /**
     * Delete Project
     * @param \Eviaglobal\Designer\Api\Data\ProjectInterface $project
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function delete(
        \Eviaglobal\Designer\Api\Data\ProjectInterface $project
    );

    /**
     * Delete Project by ID
     * @param string $projectId
     * @return bool true on success
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function deleteById($projectId);
}

