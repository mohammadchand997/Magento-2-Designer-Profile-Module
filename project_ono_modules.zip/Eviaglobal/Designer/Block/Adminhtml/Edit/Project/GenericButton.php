<?php
declare(strict_types=1);

namespace Eviaglobal\Designer\Block\Adminhtml\Edit\Project;

use Eviaglobal\Designer\Model\ProjectFactory;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\UrlInterface;
use Eviaglobal\Designer\Model\ResourceModel\Project;
use Eviaglobal\Designer\Model\ProjectRepository;

/**
 * Class for common code for buttons on the create/edit address form
 */
class GenericButton
{
    /**
     * @var projectFactory
     */
    private $projectFactory;

    /**
     * @var UrlInterface
     */
    private $urlBuilder;

    /**
     * @var project
     */
    private $projectResourceModel;

    /**
     * @var RequestInterface
     */
    private $request;

    /**
     * @var projectRepository
     */
    private $projectRepository;

    /**
     * @param AddressFactory $addressFactory
     * @param UrlInterface $urlBuilder
     * @param Address $addressResourceModel
     * @param RequestInterface $request
     * @param AddressRepository $addressRepository
     */
    public function __construct(
        ProjectFactory $projectFactory,
        UrlInterface $urlBuilder,
        Project $projectResourceModel,
        RequestInterface $request,
        ProjectRepository $projectRepository
    ) {
        $this->projectFactory = $projectFactory;
        $this->urlBuilder = $urlBuilder;
        $this->projectResourceModel = $projectResourceModel;
        $this->request = $request;
        $this->projectRepository = $projectRepository;
    }

    /**
     * Return project Id.
     *
     * @return int|null
     */
    public function getprojectId()
    {
        $project = $this->projectFactory->create();

        $projectId = $this->request->getParam('project_id');
        $this->projectResourceModel->load(
            $project,
            $projectId
        );

        return $project->getprojectId() ?: null;
    }

    /**
     * Get customer id.
     *
     * @return int|null
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getDesignerId()
    {
        $projectId = $this->request->getParam('project_id');

        $project = $this->projectRepository->get($projectId);

        return $project->getParentId() ?: null;
    }

    /**
     * Generate url by route and parameters
     *
     * @param   string $route
     * @param   array $params
     * @return  string
     */
    public function getUrl($route = '', array $params = []): string
    {
        return $this->urlBuilder->getUrl($route, $params);
    }
}
