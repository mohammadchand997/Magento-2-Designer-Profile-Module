<?php
declare(strict_types=1);

namespace Eviaglobal\Designer\Block;

use Magento\Framework\View\Element\Template;
use Eviaglobal\Designer\Api\DesignerRepositoryInterface;
use Eviaglobal\Designer\Model\ResourceModel\Project\CollectionFactory;
use Magento\Framework\Serialize\SerializerInterface;
use Magento\Eav\Model\Config;
use Magento\Catalog\Model\Product;
use Magento\Catalog\Pricing\Price\FinalPrice;
use Magento\Framework\Pricing\Render;
use Eviaglobal\Designer\Model\DesignerDataFactory;
use Eviaglobal\Product\Model\Product\Attribute\Source\Country;

class Info extends \Magento\Framework\View\Element\Template
{

    protected $brandRepository;

    protected $storeManager;

    protected $currentDesigner;

    protected $mediaUrl;

    protected $countryFactory;

    protected $collectionFactory;

    protected $serializer;

    protected $priceHelper;

    protected $eavConfig;

    protected $designerFactory;

    public function __construct(
        Template\Context $context,
        \Magento\Directory\Block\Data $directoryBlock,
        DesignerRepositoryInterface $designerRepository,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Directory\Model\CountryFactory $countryFactory,
        CollectionFactory $projectFactory,
        SerializerInterface $serializer,
        \Magento\Framework\Pricing\Helper\Data $priceHelper,
        Config $eavConfig,
        DesignerDataFactory $designerFactory,
        Country $country,
        array $data = []
    ){
        parent::__construct($context, $data);
        $this->_isScopePrivate = true;
        $this->directoryBlock  = $directoryBlock;
        $this->designerRepository = $designerRepository;
        $this->storeManager    = $storeManager;
        $this->countryFactory  = $countryFactory;
        $this->projectFactory = $projectFactory;
        $this->serializer = $serializer;
        $this->priceHelper  = $priceHelper;
        $this->eavConfig = $eavConfig;
        $this->designerFactory = $designerFactory;
        $this->country = $country;
        $this->_initBrand();
    }

    public function getDesignerId()
    {
        $storeId= $this->storeManager->getStore()->getId();
        $urlKey = $this->getRequest()->getParam('key');
        $designer = $this->designerFactory->create()->getCollection()
        ->addFieldToFilter('url_key', $urlKey)
        ->addFieldToFilter('store_id', $storeId)
        ->getFirstItem();
        return $designer->getDesignerId();
    }

    protected function _initBrand()
    {
        $id = $this->getDesignerId();
        $this->mediaUrl = $this->storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA );
        if($id && empty($this->currentDesigner)){
            $this->currentDesigner = $this->designerRepository->get($id);
        }
    }

    public function getBannerImageUrl($designerId)
    {
        $store_id=$this->storeManager->getStore()->getId();
        $designer = $this->designerFactory->create()
        ->getCollection()
        ->addFieldToFilter('designer_id', $designerId)
        ->addFieldToFilter('store_id', $store_id);
        if($designer) {
            foreach ($designer as $key => $currentDesigner) {
                return $this->mediaUrl.'tmp/imageUploader/images/'.$currentDesigner->getData('banner');
            }
        }

        return '';
    }

    public function getLogoImageUrl($designerId)
    {
        $store_id=$this->storeManager->getStore()->getId();
        $designer = $this->designerFactory->create()
        ->getCollection()
        ->addFieldToFilter('designer_id', $designerId)
        ->addFieldToFilter('store_id', $store_id);
        if($designer) {
            foreach ($designer as $key => $currentDesigner) {
                return $this->mediaUrl.'tmp/imageUploader/images/'.$currentDesigner->getData('logo');
            }
        }

        return "";
    }

    public function getName($designerId)
    {
        $store_id=$this->storeManager->getStore()->getId();
        $designer = $this->designerFactory->create()
        ->getCollection()
        ->addFieldToFilter('designer_id', $designerId)
        ->addFieldToFilter('store_id', $store_id);
        if($designer) {
            foreach ($designer as $key => $currentDesigner) {
                return $currentDesigner->getData('first_name').' '.$currentDesigner->getData('last_name');
            }
        }
  
        return '';
    }

    public function getDesignerCountryAndCity($designer_id)
    {
        $country_id="";
        $country_Name="";
        $cityName="";
        $store_id=$this->storeManager->getStore()->getId();
        $designer = $this->designerFactory->create()
        ->getCollection()
        ->addFieldToFilter('designer_id', $designer_id)
        ->addFieldToFilter('store_id', $store_id);
        if($designer) {
            foreach ($designer as $key => $value) {
                $country_id= $value->getData('country_id');
                $cityName=$value->getData('city');
            }
        }
        if($country_id!="") {
            $country = $this->countryFactory->create()->loadByCode($country_id);
           $country_Name = $country->getName();
        }

        $info    = $country_Name.', '.$cityName;
        return $info;
    }
    public function getCountryAndCity()
    {
        if(!empty($this->currentDesigner)){
            $country_id = $this->currentDesigner->getData('country_id');
            $countries = $this->country->getAllOptions();
            $countryName = '';
            foreach ($countries as $key => $country) {
                if($country['value'] == $country_id){
                    $countryName = $country['label'];
                }
            }
            $city = $this->currentDesigner->getData('city');
            $info    = $city.', '.$countryName;
            return $info;
        }  
        return '';
    }

    public function getWebsiteUrl($designerId)
    {
        $store_id=$this->storeManager->getStore()->getId();
        $designer = $this->designerFactory->create()
        ->getCollection()
        ->addFieldToFilter('designer_id', $designerId)
        ->addFieldToFilter('store_id', $store_id);  
        if($designer) {
            foreach ($designer as $key => $currentDesigner) {
                return $currentDesigner->getData('website_url');
            }   
        }

        return "javascript:void(0);";
    }

    public function getEmail($designerId)
    {
        $store_id=$this->storeManager->getStore()->getId();
        $designer = $this->designerFactory->create()
        ->getCollection()
        ->addFieldToFilter('designer_id', $designerId)
        ->addFieldToFilter('store_id', $store_id);  
        if($designer) {
            foreach ($designer as $key => $currentDesigner) {
                return $currentDesigner->getData('email');
            }
        }

        return '';
    }

    public function getDescription($designerId)
    {
        $store_id=$this->storeManager->getStore()->getId();
        $designer = $this->designerFactory->create()
        ->getCollection()
        ->addFieldToFilter('designer_id', $designerId)
        ->addFieldToFilter('store_id', $store_id);  
        if($designer) {
            foreach ($designer as $key => $currentDesigner) {
                return $currentDesigner->getData('about');
            }
        }

        return '';
    }

    public function getAttributeByCode ($designerId,$attribute_code) 
    {
        $store_id=$this->storeManager->getStore()->getId();
        $designer = $this->designerFactory->create()
        ->getCollection()
        ->addFieldToFilter('designer_id', $designerId)
        ->addFieldToFilter('store_id', $store_id);  
        foreach ($designer as $key => $currentDesigner) {
            $attirbutes = (array)$this->serializer->unserialize($currentDesigner->getAttributes());
            $optionIds = isset($attirbutes[$attribute_code]) ? $attirbutes[$attribute_code] : '';
            $optionIds = (array)$optionIds;
            if(isset($optionIds) && $optionIds){
                $options = [];
                foreach($optionIds as $values){
                    $attribute = $this->eavConfig->getAttribute('catalog_product', $attribute_code);
                    $options[] = $attribute->getSource()->getOptionText($values);
                }
                return implode(', ',$options);  
            }        
        }

        return "";        
    }
    public function getRatings($designerId)
    {
        $rating="0";
        $store_id=$this->storeManager->getStore()->getId();
        $designer = $this->designerFactory->create()
        ->getCollection()
        ->addFieldToFilter('designer_id', $designerId)
        ->addFieldToFilter('store_id', $store_id);
        if($designer) {
            foreach ($designer as $key => $value) {
                $rating= $value->getData('rating');
            }
        }

        return $rating;
    }

    public function getMediaGallery($designerId)
    {
        $store_id=$this->storeManager->getStore()->getId();
        $designer = $this->designerFactory->create()
        ->getCollection()
        ->addFieldToFilter('designer_id', $designerId)
        ->addFieldToFilter('store_id', $store_id);
        if($designer) {
            foreach ($designer as $key => $currentDesigner) {
                if($currentDesigner->getData('media_gallery')){
                    $getMediaGallery = (array)json_decode($currentDesigner->getData('media_gallery'));
                    $mediaGallery = $getMediaGallery['media_gallery'];
                    array_multisort(array_column($mediaGallery, 'sort_order'), SORT_ASC, $mediaGallery);
    
                    $getMediaData = [];
                    foreach ($mediaGallery as $key => $value) {
                        $url = '';
                        if(isset($value->gallery_image) && !empty($value->gallery_image)){
                            $url = array_column($value->gallery_image, 'url');
                        }
                        $video_url = '';
                        if(isset($value->url) && !empty($value->url)){
                            $video_url = $value->url;
                        }
                        $data['img_url'] = $url ? $url[0] : '';
                        $data['video_url'] = $video_url;
                        array_push($getMediaData, $data);                     
                    }
                    return $getMediaData;
                }
            }
        }
        return [];
    }

    // public function getAttributeByCode($attribute_code)
    // {
    //     if(!empty($this->currentDesigner)){

    //         $attirbutes = (array)$this->serializer->unserialize($this->currentDesigner->getAttributes());
    //         $optionIds = isset($attirbutes[$attribute_code]) ? $attirbutes[$attribute_code] : '';
    //         $optionIds = (array)$optionIds;
    //         if(isset($optionIds) && $optionIds){
    //             $options = [];
    //             foreach($optionIds as $values){
    //                 $attribute = $this->eavConfig->getAttribute('catalog_product', $attribute_code);
    //                 $options[] = $attribute->getSource()->getOptionText($values);
    //             }
    //             return implode(', ',$options);  
    //         }
    //     }
    //     return '';
    // }

    public function getPriceRange($designerId)
    {
        $store_id=$this->storeManager->getStore()->getId();
        $designer = $this->designerFactory->create()
        ->getCollection()
        ->addFieldToFilter('designer_id', $designerId)
        ->addFieldToFilter('store_id', $store_id);
        if($designer) {
            foreach ($designer as $key => $currentDesigner) {
                $formattedPriceFrom = $this->priceHelper->currency($currentDesigner->getData('price_from'), true, false);
                $formattedPriceTo   = $this->priceHelper->currency($currentDesigner->getData('price_to'), true, false);
                return $formattedPriceFrom.' - '.$formattedPriceTo;
            }
        }
    
        return '';
    }

    public function getProjects()
    {
        $id = $this->getDesignerId();
        if($id){
            $project = $this->projectFactory->create();
            $project->addFieldToFilter('parent_id', $id);
            $project->setOrder('sort_order','ASC')->load();
            $project->getSelect()->limit(3);
            return $project->getData();
        }
        return [];
    }

    public function getReting(){
        if(!empty($this->currentDesigner)){
            return $this->currentDesigner->getData('rating');
        }
        return '';
    }
}
