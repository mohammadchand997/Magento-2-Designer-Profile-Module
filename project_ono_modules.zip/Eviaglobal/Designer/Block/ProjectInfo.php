<?php
declare(strict_types=1);

namespace Eviaglobal\Designer\Block;

use Eviaglobal\Designer\Model\ResourceModel\Project\CollectionFactory;
use Eviaglobal\Designer\Model\DesignerDataFactory;

class ProjectInfo extends \Magento\Framework\View\Element\Template
{

    /**
     * Constructor
     *
     * @param \Magento\Framework\View\Element\Template\Context  $context
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        CollectionFactory $collectionFactory,
        DesignerDataFactory $designerFactory,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->collectionFactory = $collectionFactory;
        $this->designerFactory = $designerFactory;
         $this->storeManager = $storeManager;
    }

    public function getProjects()
    {
        $id = $this->getRequest()->getParam('last_producer_id');
        $parent_id = $this->getRequest()->getParam('parnet_id');
        if($id){
            $collection = $this->collectionFactory->create();
            if($parent_id){
                $collection->addFieldToFilter('parent_id', $parent_id);
            }
            $collection->addFieldToFilter('sort_order', array('gt' => $id));
            $collection->setOrder('sort_order','ASC')->load();
            $collection->getSelect()->limit(1);
            return $collection->getData();
        }
        return [];
    }

    public function getDesignerId()
    {        
        $storeId= $this->storeManager->getStore()->getId();
        $urlKey = $this->getRequest()->getParam('key');
        $barnd = $this->designerFactory->create()->getCollection()
        ->addFieldToFilter('url_key', $urlKey)
        ->addFieldToFilter('store_id', $storeId)->getFirstItem();
        return $barnd->getId();
    }
}