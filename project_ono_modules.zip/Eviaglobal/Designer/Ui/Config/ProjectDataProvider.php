<?php

declare(strict_types=1);

namespace Eviaglobal\Designer\Ui\Config;

use Magento\Ui\DataProvider\AbstractDataProvider;
use Eviaglobal\Designer\Model\ResourceModel\Project\CollectionFactory;
use Magento\Store\Model\StoreManagerInterface;

/**
 * Class CustomDataProvider
 */
class ProjectDataProvider extends AbstractDataProvider
{
    /**
     * @var array
     */
    private $loadedData;

    protected $storeManager;

    /**
     * CustomDataProvider constructor.
     *
     * @param string $name
     * @param string $primaryFieldName
     * @param string $requestFieldName
     * @param CollectionFactory $collectionFactory
     * @param array $meta
     * @param array $data
     */
    public function __construct(
        $name,
        $primaryFieldName,
        $requestFieldName,
        CollectionFactory $collectionFactory,
        StoreManagerInterface $storeManager,
        array $meta = [],
        array $data = []
    ) {
        $this->collection = $collectionFactory->create();
        $this->storeManager  = $storeManager;
        parent::__construct(
            $name,
            $primaryFieldName,
            $requestFieldName,
            $meta,
            $data
        );
    }

    /**
     * Get data
     *
     * @return array
     */
    public function getData()
    {
        if (null !== $this->loadedData) {
            return $this->loadedData;
        }
        $items = $this->collection->getItems();
        foreach ($items as $project) {
            // echo '<pre>';
            // print_r($project->getData());
            // die;
            $this->loadedData[$project->getId()] = $project->getData();

            if(isset($project) && isset($this->loadedData[$project->getId()])){
                $this->loadedData[$project->getId()]['title'] = $this->loadedData[$project->getId()]['Title'];

                $getGalleryCollection = $this->loadedData[$project->getId()]['media_gallery'];
                $decodeGalleryCollection = json_decode($getGalleryCollection);
                $image = $this->loadedData[$project->getId()]['image'];

                unset($this->loadedData[$project->getId()]['media_gallery']);
                
                if($this->loadedData[$project->getId()]['image']){
                    $this->loadedData[$project->getId()]['image'] = [];
                    $this->loadedData[$project->getId()]['image'][0]['url'] = $this->getMediaUrl().$image;
                    $this->loadedData[$project->getId()]['image'][0]['name'] = $image;
                    $this->loadedData[$project->getId()]['image'][0]['type'] = 'image/png';
                    $this->loadedData[$project->getId()]['image'][0]['size'] = 1234;
                    $this->loadedData[$project->getId()]['image'][0]['exists'] = 1;  
                }
            
                $this->loadedData[$project->getId()]['media_gallery'] = $decodeGalleryCollection;
                
            }   
        }
        return $this->loadedData;
    }

    public function getMediaUrl()
    {
        $mediaUrl = $this->storeManager->getStore()
            ->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA).'tmp/imageUploader/images/';
        return $mediaUrl;
    }
}
