<?php 
namespace Eviaglobal\Designer\Controller\Wishlist;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Wishlist\Model\WishlistFactory;
use Magento\Customer\Model\Session;

class RemoveAllWishList extends Action
{
    protected $wishlistFactory;

    protected $customerSession;

    public function __construct(
        Context $context,
        WishlistFactory $wishlistFactory,
        Session $customerSession,
        \Magento\Framework\Message\ManagerInterface $messageManager,
    ) {
        parent::__construct($context);
        $this->wishlistFactory = $wishlistFactory;
        $this->customerSession = $customerSession;
        $this->messageManager = $messageManager;
    }

    public function execute()
    {
        $customerId = $this->customerSession->getCustomer()->getId();
        $wishlist = $this->wishlistFactory->create()->loadByCustomerId($customerId);
        
        // Remove all items from the wishlist
        $items = $wishlist->getItemCollection();
        foreach ($items as $item) {
            $item->delete();
        }

        $this->messageManager->addSuccessMessage(__('All items have been removed from your wishlist.'));
        $this->_redirect('wishlist/index/index');
    }
}
