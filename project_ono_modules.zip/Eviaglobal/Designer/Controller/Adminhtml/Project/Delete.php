<?php
declare(strict_types=1);

namespace Eviaglobal\Designer\Controller\Adminhtml\Project;

use Magento\Backend\App\Action;
use Magento\Framework\App\Action\HttpPostActionInterface;
use Magento\Framework\Controller\Result\Json;
use Magento\Framework\Controller\Result\JsonFactory;
use Eviaglobal\Designer\Api\ProjectRepositoryInterface;
use Psr\Log\LoggerInterface;

/**
 * Button for deletion of Designer Project in admin
 */
class Delete extends Action implements HttpPostActionInterface
{

    /**
     * @var ProjectRepositoryInterface
     */
    private $projectRepository;

    /**
     * @var JsonFactory
     */
    private $resultJsonFactory;

    /**
     * @var LoggerInterface
     */
    private $logger;

    /**
     * @param Action\Context $context
     * @param ProjectRepositoryInterface $projectRepository
     * @param JsonFactory $resultJsonFactory
     * @param LoggerInterface $logger
     */
    public function __construct(
        Action\Context $context,
        ProjectRepositoryInterface $projectRepository,
        JsonFactory $resultJsonFactory,
        LoggerInterface $logger
    ) {
        parent::__construct($context);
        $this->projectRepository   = $projectRepository;
        $this->resultJsonFactory = $resultJsonFactory;
        $this->logger = $logger;
    }

    /**
     * Delete Designer project action
     *
     * @return Json
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function execute(): Json
    {
        $designerId = $this->getRequest()->getParam('parent_id', false);
        $projectId = $this->getRequest()->getParam('project_id', false);
        $error = false;
        $message = '';
        
        if ($projectId && $this->projectRepository->get($projectId)->getParentId() === $designerId) {
            try {
                $this->projectRepository->deleteById($projectId);
                $message = __('You deleted the address.');
            } catch (\Exception $e) {
                $error = true;
                $message = __('We can\'t delete the address right now.');
                $this->logger->critical($e);
            }
        }

        $resultJson = $this->resultJsonFactory->create();
        $resultJson->setData(
            [
                'message' => $message,
                'error' => $error,
            ]
        );

        return $resultJson;
    }
}
