<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Eviaglobal\Designer\Controller\Adminhtml\Project;

use Psr\Log\LoggerInterface;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Controller\Result\Json;


class Save extends \Magento\Backend\App\Action
{

    /**
     * @var LoggerInterface
     */
    private $logger;

    /**
     * @var JsonFactory
     */
    private $resultJsonFactory;

    /**
     * @var \Eviaglobal\Designer\Api\ProjectRepositoryInterface
     */
    private $projectRepository;

    /**
     * @var \Magento\Framework\Api\DataObjectHelper
     */
    private $dataObjectHelper;

    /**
     * @var \Eviaglobal\Designer\Api\Data\ProjectInterface
     */
    private $projectDataFactory;


    /**
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Framework\App\Request\DataPersistorInterface $dataPersistor
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Eviaglobal\Designer\Api\ProjectRepositoryInterface $projectRepository,
        LoggerInterface $logger,
        JsonFactory $resultJsonFactory,
        \Magento\Framework\Api\DataObjectHelper $dataObjectHelper,
        \Eviaglobal\Designer\Api\Data\ProjectInterface $projectDataFactory
    ) {
        parent::__construct($context);
        $this->projectRepository   = $projectRepository;
        $this->logger            = $logger;
        $this->resultJsonFactory = $resultJsonFactory;
        $this->dataObjectHelper  = $dataObjectHelper;
        $this->projectDataFactory  = $projectDataFactory;
    }

    /**
     * Save action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute(): Json
    {
        $designerId = $this->getRequest()->getParam('parent_id', false);
        $projectId = $this->getRequest()->getParam('project_id', false);
        $postedData    = $this->getRequest()->getParams();

        $error   = false;
        try{
            $model = $this->_objectManager->create(\Eviaglobal\Designer\Model\Project::class)->load($projectId);
            
            if (!$model->getId() && $projectId) {
                $error = true;
                $message = __('This project no longer exists.');
            }
            $media_gallery = isset($postedData['media_gallery']) ? json_encode($postedData['media_gallery']) : json_encode([]);
            $image = isset($postedData['image']) ? $postedData['image'][0]['name'] : '';
            $data = [
                'parent_id'  => $postedData['parent_id'],
                'Title'      => $postedData['title'],
                'sort_order' => $postedData['sort_order'],
                'image' => $image,
                'media_gallery' => $media_gallery,
                'description'     => $postedData['description']
            ];
            if($model->getId()){
                $model->setId($model->getId());
                $model->addData($data);
            }else{
                $model->setData($data);
            }
            if ($projectId) {
                $message = __('Designer project has been updated.');
            } else {
                $message = __('New designer address has been added.');
            }
            $savedProject =$model->save();;
            $projectId = $savedProject->getProjectId();
        } catch (NoSuchEntityException $e) {
            $this->logger->critical($e);
            $error = true;
            $message = __('There is no designer with such id.');
        } catch (LocalizedException $e) {
            $error = true;
            $message = __($e->getMessage());
            $this->logger->critical($e);
        } catch (\Exception $e) {
            $error = true;
            $message = __('We can\'t change designer project right now.');
            $this->logger->critical($e);
        }
        $projectId    = empty($projectId) ? null : $projectId;
        $resultJson = $this->resultJsonFactory->create();
        $resultJson->setData(
            [
                'messages' => $message,
                'error' => $error,
                'data' => [
                    'project_id' => $projectId
                ]
            ]
        );

        return $resultJson;
    }
}

