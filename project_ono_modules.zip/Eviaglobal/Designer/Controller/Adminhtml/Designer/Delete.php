<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Eviaglobal\Designer\Controller\Adminhtml\Designer;

class Delete extends \Eviaglobal\Designer\Controller\Adminhtml\Designer
{

    /**
     * Delete action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        // check if we know what should be deleted
        $id = $this->getRequest()->getParam('designer_id');
        if ($id) {
            try {
                // init model and delete
                $model = $this->_objectManager->create(\Eviaglobal\Designer\Model\Designer::class);
                $model->load($id);
                $sql = "Select product_id FROM " . $tableName.' where brand_id='.$id;
                $result = $connection->fetchAll($sql);
                if($result) {
                    $product_id = $result[0]['product_id'];
                    if($product_id){
                        $this->deleteProductById($product_id);
                    }

                    $model->delete();          
                    $connection->delete(
                        $tableName,
                        ['brand_id = ?' => $id]
                    );
                }
                // display success message
                $this->messageManager->addSuccessMessage(__('You deleted the Designer.'));
                // go to grid
                return $resultRedirect->setPath('*/*/');
            } catch (\Exception $e) {
                // display error message
                $this->messageManager->addErrorMessage($e->getMessage());
                // go back to edit form
                return $resultRedirect->setPath('*/*/edit', ['designer_id' => $id]);
            }
        }
        // display error message
        $this->messageManager->addErrorMessage(__('We can\'t find a Designer to delete.'));
        // go to grid
        return $resultRedirect->setPath('*/*/');
    }

    public function deleteProductById($id)
    {
        $product = $this->_objectManager->create('Magento\Catalog\Model\Product');
        $product->load($id)->delete();
    }
}

