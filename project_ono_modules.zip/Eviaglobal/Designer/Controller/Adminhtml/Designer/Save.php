<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Eviaglobal\Designer\Controller\Adminhtml\Designer;

use Magento\Framework\Exception\LocalizedException;
use Magento\Store\Model\StoreManagerInterface;
use Eviaglobal\Brand\Helper\Data as brandHelper;
use Eviaglobal\Designer\Helper\Data as designerHelper;
use Eviaglobal\Designer\Model\DesignerDataFactory;

class Save extends \Magento\Backend\App\Action
{
    const ADMIN_RESOURCE = 'Eviaglobal_Brand::designer';
    
    protected $dataPersistor;

    /**
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Framework\App\Request\DataPersistorInterface $dataPersistor
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\App\Request\DataPersistorInterface $dataPersistor,
        StoreManagerInterface $storeManager,
        brandHelper $brandHelper,
        designerHelper $designerHelper,
        DesignerDataFactory $designerDataFactory
    ) {
        $this->dataPersistor = $dataPersistor;
        $this->brandHelper = $brandHelper;
        $this->designerHelper =  $designerHelper;
        $this->_storeManager = $storeManager;
        $this->designerDataFactory = $designerDataFactory;
        parent::__construct($context);
    }

    /**
     * Save action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $resource = $objectManager->get('Magento\Framework\App\ResourceConnection');
        
        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        $data = $this->getRequest()->getPostValue();
        // echo '<pre>';print_r($data);die();
        if ($data) {
            $media_gallery = isset($data['media']['media_gallery']) ? json_encode($data['media']['media_gallery']) : '';
            $home_banner = isset($data['media']['home_banner'][0]['name']) ? $data['media']['home_banner'][0]['name'] : '';
            $home_banner_mobile = isset($data['media']['home_banner_mobile'][0]['name']) ? $data['media']['home_banner_mobile'][0]['name'] : '';
            $attributes = (array)$data['attributes'];
            $isProfileReady = $data['general']['is_profile_ready'];
            $display_on_frontend = $data['general']['display_on_frontend'];
            $store=$data['general']['store']?$data['general']['store']:0;
            $formData = [
                'store_id'=> $store,
                'title' => $data['general']['title'],
                'email' => $data['general']['email'],
                'website_url' => $data['general']['website_url'],
                'city'       => $attributes['city'],
                'customer_id'  => $data['general']['customer_id'],
                'country_id' => $attributes['country_id'],
                'about'      => $data['general']['about'],
                'logo'       => $data['media']['logo'][0]['name'],
                'banner'     => $data['media']['banner'][0]['name'],
                'listing_banner' => $data['media']['listing_banner'][0]['name'],
                'home_banner' => $home_banner,
                'home_banner_mobile' => $home_banner_mobile,
                'media_gallery' => $media_gallery,
                'display_on_frontend' => $display_on_frontend,
                'show_on_homepage' => $data['general']['show_on_homepage'],
                'first_name' => $data['others_detail']['first_name'],
                'last_name' => $data['others_detail']['last_name'],
                'phone' => $data['others_detail']['phone'],
                'company_registartion_no' => $data['others_detail']['company_registartion_no'],
                'taxvat' => $data['others_detail']['taxvat'],
                'styles' => '',
                'postcode' => $data['others_detail']['postcode'],
                'address_1' => $data['others_detail']['address_1'],
                'address_2' => $data['others_detail']['address_2'],
                'meta_title' => $data['others_detail']['meta_title'],
                'meta_keywords' => $data['others_detail']['meta_keywords'],
                'meta_description' => $data['others_detail']['meta_description'],
                'price_from' => $data['attributes']['price_from'],
                'price_to'   => $data['attributes']['price_to'],
                'attributes' => json_encode($data['attributes'], JSON_UNESCAPED_SLASHES),
                'is_profile_ready' => $isProfileReady,
                'created_at' => date('Y-m-d H:i:s')
            ];
            
            $id = $this->getRequest()->getParam('designer_id');
            $model = $this->_objectManager->create(\Eviaglobal\Designer\Model\Designer::class)->load($id);
            if (!$model->getId() && $id) {
                $this->messageManager->addErrorMessage(__('This Designer no longer exists.'));
                return $resultRedirect->setPath('*/*/');
            }

      
            $formData['designer_id'] = $id;
             $designer_name = str_replace(' ', '-', $data['general']['title']); 
            $formData['url_key'] = $designer_name;  
            if($id){
                $connection = $resource->getConnection();
                $tableName = $resource->getTableName('eviaglobal_designer_data');
                $sql = "Select value_id,product_id FROM " . $tableName.' where designer_id='.$model->getId().' and store_id='.$store;
                $result = $connection->fetchAll($sql);
                $designer_name = str_replace(' ', '-', $data['general']['title']);
                $url_key = !empty($designer) ? $designer_name.'-'.count($designer) : $designer_name;
                $formData['url_key'] =$designer_name;   
                if ($result) {
                    $product_id=$result[0]['product_id'];	
                    $product = $this->_objectManager->create('Magento\Catalog\Model\Product')->load($product_id);
                    $attributes = (array)$data['attributes'];
                    $attributes['designer_city'] = $model->getId();
                    $attributes['brand_country'] = $attributes['country_id'];
                    $attributes['designer'] = $model->getId();
                    $productData = [
                            'name' => $data['general']['title'],
                            'attributes' => $attributes,
                        ];
                    if($product->getId()){
                        $this->brandHelper->updateProductPriceById($product->getId(), $data['attributes']['price_to']);
                        foreach ($attributes as $key => $value) {
                            if($value!="") {

                                $this->brandHelper->addProductAttributeValueById($product->getId(), $key, $value);
                            }
                        }
                        $productStatus = $display_on_frontend ? true : false;
                        $this->brandHelper->enableDisableProductById($product->getId(), $productStatus);      
                    }else{
                        $this->setDesignerProduct($productData, $model->getId());
                    }
                    $this->checkUrlKey($data['general']['title'], $model->getId(),$store); 
                    if(empty($model['is_profile_ready']) && $isProfileReady){
                        $this->sendProfileReadyMail($formData);
                    } 

                    if ($result) {
                        $formData['value_id']=$result[0]['value_id'];					
                    }   


                    $designerData=$this->designerDataFactory->create();
                    $designerData->setData($formData);
                    $designerData->save();  
                    $this->messageManager->addSuccessMessage(__('Designer Details Saved Successfully.'));
                    if ($this->getRequest()->getParam('back')) {
                        return $resultRedirect->setPath('*/*/edit', ['designer_id' => $model->getId()]);
                    }
                    return $resultRedirect->setPath('*/*/');
                } 
            } else {
                try {
                    $model->setData($formData);
                    $model->save();
                    $formData['designer_id']=$model->getId();
                    $designerData=$this->designerDataFactory->create();
                    $designerData->setData($formData);
                    $designerData->save();
                    $storeIds = array_keys($this->_storeManager->getStores());
                    foreach ($storeIds as $storeId) {
                        if($storeId!=0) {
                            $formData['designer_id']=$model->getId();
                            $formData['store_id']=$storeId;
                            $designerData->setData($formData);
                            $designerData->save();
                        }
                    }

                    $lastId = $model->getId();
                    if(!$id && $lastId){
                        $attributes = (array)$data['attributes'];
                        $attributes['designer_city'] = $model->getId();
                        $attributes['brand_country'] = $attributes['country_id'];
                        $attributes['designer'] = $model->getId();
                        $productData = [
                                'name' => $data['general']['title'],
                                'attributes' => $attributes,
                            ];
                        $this->setDesignerProduct($productData, $model->getId());
                        $this->checkUrlKey($data['general']['title'], $lastId,$store);
                    }
                    $this->messageManager->addSuccessMessage(__('You saved the Designer.'));
                    $this->dataPersistor->clear('eviaglobal_designer_designer');
                    
                    if ($this->getRequest()->getParam('back')) {
                        return $resultRedirect->setPath('*/*/edit', ['designer_id' => $model->getId()]);
                    }
                    return $resultRedirect->setPath('*/*/');
                } catch (LocalizedException $e) {
                    $this->messageManager->addErrorMessage($e->getMessage());
                } catch (\Exception $e) {
                    // $this->messageManager->addExceptionMessage($e, __('Something went wrong while saving the Designer.'));
                    $this->messageManager->addExceptionMessage($e, __($e->getMessage()));
                }
            }
         
            $this->dataPersistor->set('eviaglobal_designer_designer', $data);
            return $resultRedirect->setPath('*/*/edit', ['designer_id' => $this->getRequest()->getParam('designer_id')]);
        }
        return $resultRedirect->setPath('*/*/');
    }

    public function setDesignerProduct($productData, $designerId)
    {
        $productId = $this->designerHelper->createDesignerProduct($productData);
        $resource = $this->_objectManager->get('Magento\Framework\App\ResourceConnection');
        $connection = $resource->getConnection();
        $tableName = $resource->getTableName('eviaglobal_designer_data');
        $sql = "Update ".$tableName." Set product_id =".$productId." where designer_id = ".$designerId."";
        $connection->query($sql);
    }
    protected function checkUrlKey($title, $designerId,$storeId)
    {
        $store_id=$this->_storeManager->getStore()->getId();
        $designer_name = str_replace(' ', '-', strtolower($title));
        $designerData = $this->_objectManager->create(\Eviaglobal\Designer\Model\DesignerData::class)->getCollection()
        ->addFieldToFilter('designer_id', array('neq' => $designerId))->addFieldToFilter('url_key', $designer_name);
        $designer = $designerData->getData();
        $url_key = !empty($designer) ? $designer_name.'-'.count($designer) : $designer_name;

        if($url_key){
            $resource = $this->_objectManager->get('Magento\Framework\App\ResourceConnection');
            $connection = $resource->getConnection();
            $tableName = $resource->getTableName('eviaglobal_designer_data');
            $sql = "Update ".$tableName." Set url_key='".$url_key."' where designer_id = ".$designerId."  and store_id= ".$store_id;
            // $sql = "Update ".$tableName." Set url_key='".$url_key."' where designer_id = ".$designerId;
            $connection->query($sql);  
        }
    }
    public function sendProfileReadyMail($formData='')
    {
        $storeName = $this->_storeManager->getStore()->getCode();
        $templateId = $storeName == 'fr' ? '88' : '88';
        $to = [
            'name' => $formData['first_name'].' '.$formData['last_name'],
            'email' => $formData['email'],
        ];
        $this->brandHelper->sendEmail($formData, $templateId, $to);
    }
}