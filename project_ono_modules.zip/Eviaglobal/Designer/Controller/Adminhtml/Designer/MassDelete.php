<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Eviaglobal\Designer\Controller\Adminhtml\Designer;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\Controller\ResultFactory;
use Magento\Ui\Component\MassAction\Filter;
use Eviaglobal\Designer\Model\ResourceModel\Designer\CollectionFactory;

class MassDelete extends Action
{
    public $collectionFactory;
    public $filter;
    public $designerFactory;

    public function __construct(
        Context $context,
        Filter $filter,
        CollectionFactory $collectionFactory,
        \Eviaglobal\Designer\Model\DesignerFactory $designerFactory
    ) {
        $this->filter = $filter;
        $this->collectionFactory = $collectionFactory;
        $this->designerFactory = $designerFactory;
        parent::__construct($context);
    }

    public function execute()
    {
        try {
            $collection = $this->filter->getCollection($this->collectionFactory->create());
            $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
            $resource = $objectManager->get('Magento\Framework\App\ResourceConnection');
            $connection = $resource->getConnection();
            $tableName = $resource->getTableName('eviaglobal_designer_data');
            $count = 0;
            foreach ($collection as $model) 
            {
                $designer_id=$model->getDesignerId();
                $sql = "Select product_id FROM " . $tableName.' where designer_id='.$designer_id;
                $result = $connection->fetchAll($sql);
                if($result) {
                    $product_id = $result[0]['product_id'];
                    if($product_id){
                        $this->deleteProductById($product_id);
                    }
                    // $model->delete();       
                    $connection->delete(
                        'eviaglobal_designer_designer',
                        ['designer_id = ?' => $designer_id]
                    );   
                    $connection->delete(
                        $tableName,
                        ['designer_id = ?' => $designer_id]
                    );
                    $count++;
                }   
            }
            $this->messageManager->addSuccess(__('A total of %1 designer(s) have been deleted.', $count));
        } catch (\Exception $e) {
            $this->messageManager->addError(__($e->getMessage()));
        }
        return $this->resultFactory->create(ResultFactory::TYPE_REDIRECT)->setPath('*/*/');
    }

    public function deleteProductById($id)
    {
        $product = $this->_objectManager->create('Magento\Catalog\Model\Product');
        $product->load($id)->delete();
    }
}