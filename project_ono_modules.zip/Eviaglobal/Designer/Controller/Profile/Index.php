<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Eviaglobal\Designer\Controller\Profile;

use Eviaglobal\Designer\Model\DesignerDataFactory;
use Magento\Framework\View\Result\PageFactory;
use Magento\Framework\App\Action\Context;

class Index extends \Magento\Framework\App\Action\Action
{
    /**
     * @var PageFactory
     */
    protected $resultPageFactory;

    /**
     * @param Context $context
     * @param PageFactory $resultPageFactory
     */
    public function __construct(
        Context $context,
        PageFactory $resultPageFactory,
        DesignerDataFactory $designerFactory,
    ) {
        $this->resultPageFactory = $resultPageFactory;
        $this->designerFactory = $designerFactory;
        parent::__construct($context);
    }

    /**
     * Customer register form page
     *
     * @return \Magento\Framework\Controller\Result\Redirect|\Magento\Framework\View\Result\Page
     */
    public function execute()
    {
        //die('hjdksjd');
        $urlKey = $this->getRequest()->getParam('key');
        
        $id = $this->getDesignerIdByUrlKey($urlKey);
        if(!$id){
            $resultRedirect = $this->resultRedirectFactory->create();
            $resultRedirect->setPath('/');
            return $resultRedirect;
        }
        /** @var \Magento\Framework\View\Result\Page $resultPage */
        $resultPage = $this->resultPageFactory->create();
        $designerData = $this->getDesignerInfoById($id);

        $meta_title = array_key_exists('meta_title', $designerData) ? $designerData['meta_title'] : '';
        $meta_keywords = array_key_exists('meta_keywords', $designerData) ? $designerData['meta_keywords'] : '';
        $meta_description = array_key_exists('meta_description', $designerData) ? $designerData['meta_description'] : '';

        $resultPage->getConfig()->getTitle()->set($meta_title); // meta title
        $resultPage->getConfig()->setKeywords($meta_keywords); // meta keywords
        $resultPage->getConfig()->setDescription($meta_description); // meta description
        return $resultPage;
    }

    public function getDesignerInfoById($id)
    {
        $getDesignerData = $this->designerFactory->create()->getCollection()
        ->addFieldToFilter('designer_id', $id);
        $designer = $getDesignerData->getData();
        return $designer;
    }

    public function getDesignerIdByUrlKey($urlKey)
    {
        $designer = $this->designerFactory->create()->getCollection()
        ->addFieldToFilter('url_key', $urlKey)->getFirstItem();
        return $designer->getId();
    }
}


