require(
        [
            'Magento_Ui/js/lib/validation/validator',
            'jquery',
            'mage/translate'
    ], function(validator, $){
            $(document).ready(function() {
                /*$('#your-form-id').on('submit', function(event) {
                    if (!$('#city').val() || !$('#country_id').val() || !$('#style').val() || !$('#spaces').val() ) {
                        event.preventDefault(); // Prevent form submission
                        $('#tab_attributes').trigger('click');
                    }
                });*/
                $('#save_and_continue').on('click', function() {
                    // Your custom click event logic here
                    if(!$('#city').val() || !$('#country_id').val() || !$('#style').val() || !$('#expertise').val() || !$('#project_type').val() || !$('#designer_type').val() || jQuery('#rating').find('.mage-error').length > 0){
                        $('#tab_attributes').trigger('click');
                    }
                });
                $('#save').on('click', function() {
                    // Your custom click event logic here
                    if(!$('#city').val() || !$('#country_id').val() || !$('#style').val() || !$('#expertise').val() || !$('#project_type').val() || !$('#designer_type').val() || jQuery('#rating').find('.mage-error').length > 0){
                        $('#tab_attributes').trigger('click');
                    }
                });

                // $(document).on('click', 'button', function() {
                //     var rows = document.querySelectorAll('.admin__dynamic-rows tr.data-row');
                //     var isValid = true;

                //     for (var i = 0; i < rows.length; i++) {
                //         var inputs = rows[i].querySelectorAll('.admin__dynamic-rows .data-row .field-optional input');
                //         var hasValue = Array.from(inputs).some(function(input) {
                //             return input.value.trim() !== '';
                //         });

                //         if (!hasValue) {
                //             isValid = false;
                //             alert('Please enter input.');
                //             $(".admin__dynamic-rows tbody").append('<label class="admin__field-error">Please enter input.</label>');
                            
                //         }
                //     }
                // });

                
            });
});

