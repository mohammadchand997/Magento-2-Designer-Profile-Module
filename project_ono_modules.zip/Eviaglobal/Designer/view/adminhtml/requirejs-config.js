var config = {
    map: {
        // '*': {
        //     'Magento_Ui/js/dynamic-rows/dynamic-rows': 'Eviaglobal_Designer/js/custom-dynamic-rows'
        // }
    }
};
