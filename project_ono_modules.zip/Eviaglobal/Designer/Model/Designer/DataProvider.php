<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Eviaglobal\Designer\Model\Designer;

use Eviaglobal\Designer\Model\ResourceModel\Designer\CollectionFactory;
use Magento\Framework\App\Request\DataPersistorInterface;
use Magento\Ui\DataProvider\AbstractDataProvider;
use Magento\Store\Model\StoreManagerInterface;

class DataProvider extends AbstractDataProvider
{

    /**
     * @var DataPersistorInterface
     */
    protected $dataPersistor;

    /**
     * @var array
     */
    protected $loadedData;
    /**
     * @inheritDoc
     */
    protected $collection;

    protected $storeManager;


    /**
     * @param string $name
     * @param string $primaryFieldName
     * @param string $requestFieldName
     * @param CollectionFactory $collectionFactory
     * @param DataPersistorInterface $dataPersistor
     * @param array $meta
     * @param array $data
     */
    public function __construct(
        $name,
        $primaryFieldName,
        $requestFieldName,
        CollectionFactory $collectionFactory,
        DataPersistorInterface $dataPersistor,
        StoreManagerInterface $storeManager,
        array $meta = [],
        array $data = []
    ) {
        $this->collection    = $collectionFactory->create();
        $this->dataPersistor = $dataPersistor;
        $this->storeManager  = $storeManager;
        parent::__construct($name, $primaryFieldName, $requestFieldName, $meta, $data);
    }

    /**
     * @inheritDoc
     */
    public function getData()
    {
        if (isset($this->loadedData)) {
            return $this->loadedData;
        }
        $items = $this->collection->getItems();
        foreach ($items as $model) {
            $this->loadedData[$model->getId()] = $model->getData();
        }
        $data = $this->dataPersistor->get('eviaglobal_designer_designer');
        
        if (!empty($data)) {
            $model = $this->collection->getNewEmptyItem();
            $model->setData($data);
            $this->loadedData[$model->getId()] = $model->getData();
            $this->dataPersistor->clear('eviaglobal_designer_designer');            
        }

        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $request = $objectManager->get('Magento\Framework\App\Request\Http');  
        $params=$request->getParams();
        $store=0;
        if(array_key_exists("store",$params)) {
            $store = $params['store'];
        }
        if(!empty($items) && isset($model) && isset($this->loadedData[$model->getId()])){
            $brandData = $objectManager->create("Eviaglobal\Brand\Model\BrandData");
            $resource = $objectManager->get('Magento\Framework\App\ResourceConnection');
            $connection = $resource->getConnection();
            $tableName = $resource->getTableName('eviaglobal_designer_data');
            $sql = "Select * FROM " . $tableName.' where designer_id='.$model->getId().' and store_id='.$store;
            $result = $connection->fetchAll($sql);
            if($result) {
                $this->loadedData[$model->getId()]['general']['title'] = $result[0]['title'];
                $this->loadedData[$model->getId()]['general']['email'] = $result[0]['email'];
                $this->loadedData[$model->getId()]['general']['about'] = $result[0]['about'];
                $this->loadedData[$model->getId()]['general']['website_url'] = $result[0]['website_url'];
                $this->loadedData[$model->getId()]['general']['customer_id'] = $result[0]['customer_id'];
                //$this->loadedData[$model->getId()]['general']['city'] = $this->loadedData[$model->getId()]['city'];
                //$this->loadedData[$model->getId()]['general']['country_id'] = $this->loadedData[$model->getId()]['country_id'];
                $this->loadedData[$model->getId()]['general']['store'] = $store;  
                $this->loadedData[$model->getId()]['general']['display_on_frontend'] = $result[0]['display_on_frontend'];
                $this->loadedData[$model->getId()]['general']['show_on_homepage'] = $result[0]['show_on_homepage'];
                $this->loadedData[$model->getId()]['general']['is_profile_ready'] = $result[0]['is_profile_ready'];

                if($result[0]['logo']){
                    $this->loadedData[$model->getId()]['media']['logo'][0]['url'] = $this->getMediaUrl().$result[0]['logo'];
                    $this->loadedData[$model->getId()]['media']['logo'][0]['name'] =$result[0]['logo'];
                    $this->loadedData[$model->getId()]['media']['logo'][0]['type'] = 'image/png';
                    $this->loadedData[$model->getId()]['media']['logo'][0]['size'] = 1234;
                    $this->loadedData[$model->getId()]['media']['logo'][0]['exists'] = 1;  
                }

                if($result[0]['banner']){
                    $this->loadedData[$model->getId()]['media']['banner'][0]['url'] = $this->getMediaUrl().$result[0]['banner'];
                    $this->loadedData[$model->getId()]['media']['banner'][0]['name'] = $result[0]['banner'];
                    $this->loadedData[$model->getId()]['media']['banner'][0]['type'] = 'image/png';
                    $this->loadedData[$model->getId()]['media']['banner'][0]['size'] = 1234;
                    $this->loadedData[$model->getId()]['media']['banner'][0]['exists'] = 1;
                }
                
                if($result[0]['listing_banner']){
                    $this->loadedData[$model->getId()]['media']['listing_banner'][0]['url'] = $this->getMediaUrl().$result[0]['listing_banner'];
                    $this->loadedData[$model->getId()]['media']['listing_banner'][0]['name'] = $result[0]['listing_banner'];
                    $this->loadedData[$model->getId()]['media']['listing_banner'][0]['type'] = 'image/png';
                    $this->loadedData[$model->getId()]['media']['listing_banner'][0]['size'] = 1234;
                    $this->loadedData[$model->getId()]['media']['listing_banner'][0]['exists'] = 1;
                }

                if($result[0]['home_banner']){
                    $this->loadedData[$model->getId()]['media']['home_banner'][0]['url'] = $this->getMediaUrl().$result[0]['home_banner'];
                    $this->loadedData[$model->getId()]['media']['home_banner'][0]['name'] = $result[0]['home_banner'];
                    $this->loadedData[$model->getId()]['media']['home_banner'][0]['type'] = 'image/png';
                    $this->loadedData[$model->getId()]['media']['home_banner'][0]['size'] = 1234;
                    $this->loadedData[$model->getId()]['media']['home_banner'][0]['exists'] = 1;
                }

                if($result[0]['home_banner_mobile']){
                    $this->loadedData[$model->getId()]['media']['home_banner_mobile'][0]['url'] = $this->getMediaUrl().$result[0]['home_banner_mobile'];
                    $this->loadedData[$model->getId()]['media']['home_banner_mobile'][0]['name'] = $result[0]['home_banner_mobile'];
                    $this->loadedData[$model->getId()]['media']['home_banner_mobile'][0]['type'] = 'image/png';
                    $this->loadedData[$model->getId()]['media']['home_banner_mobile'][0]['size'] = 1234;
                    $this->loadedData[$model->getId()]['media']['home_banner_mobile'][0]['exists'] = 1;
                }

                if($result[0]['attributes']){
                    $attributes = (array)json_decode($result[0]['attributes']);
                    $attributes['city'] = $result[0]['city'];
                    $attributes['country_id'] = $result[0]['country_id'];
                    $this->loadedData[$model->getId()]['attributes'] = $attributes;
                }

                $this->loadedData[$model->getId()]['general']['url_key'] = $result[0]['url_key'];
                $this->loadedData[$model->getId()]['others_detail']['first_name'] = $result[0]['first_name'];
                $this->loadedData[$model->getId()]['others_detail']['last_name'] = $result[0]['last_name'];
                $this->loadedData[$model->getId()]['others_detail']['phone'] = $result[0]['phone'];
                $this->loadedData[$model->getId()]['others_detail']['company_registartion_no'] = $result[0]['company_registartion_no'];
                $this->loadedData[$model->getId()]['others_detail']['taxvat'] = $result[0]['taxvat'];
                $this->loadedData[$model->getId()]['others_detail']['styles'] = $result[0]['styles'];
                $this->loadedData[$model->getId()]['others_detail']['postcode'] = $result[0]['postcode'];
                $this->loadedData[$model->getId()]['others_detail']['address_1'] = $result[0]['address_1'];
                $this->loadedData[$model->getId()]['others_detail']['address_2'] = $result[0]['address_2'];
                $this->loadedData[$model->getId()]['others_detail']['meta_title'] = $result[0]['meta_title'];
                $this->loadedData[$model->getId()]['others_detail']['meta_keywords'] = $result[0]['meta_keywords'];
                $this->loadedData[$model->getId()]['others_detail']['meta_description'] = $result[0]['meta_description'];
                $this->loadedData[$model->getId()]['attributes']['price_from'] = $result[0]['price_from'];
                $this->loadedData[$model->getId()]['attributes']['price_to'] = $result[0]['price_to'];
                $getMediaGallery = $result[0]['media_gallery'];
                $decodeMediaGallery = $getMediaGallery ? json_decode($getMediaGallery) : '';
                $this->loadedData[$model->getId()]['media']['media_gallery'] = $decodeMediaGallery;
            }   
        }
        return $this->loadedData;
    }

    public function getMediaUrl()
    {
        $mediaUrl = $this->storeManager->getStore()
            ->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA).'tmp/imageUploader/images/';
        return $mediaUrl;
    }
}

