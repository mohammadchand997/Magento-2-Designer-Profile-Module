<?php
declare(strict_types=1);

namespace Eviaglobal\Designer\Model\ResourceModel\Project;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

class Collection extends AbstractCollection
{

    /**
     * @inheritDoc
     */
    protected $_idFieldName = 'project_id';

    /**
     * @inheritDoc
     */
    protected function _construct()
    {
        $this->_init(
            \Eviaglobal\Designer\Model\Project::class,
            \Eviaglobal\Designer\Model\ResourceModel\Project::class
        );
    }
}

