<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Eviaglobal\Designer\Model\ResourceModel\DesignerData;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

class Collection extends AbstractCollection
{

    /**
     * @inheritDoc
     */
    protected $_idFieldName = 'value_id';

    /**
     * @inheritDoc
     */
    protected function _construct()
    {
        $this->_init(
            \Eviaglobal\Designer\Model\DesignerData::class,
            \Eviaglobal\Designer\Model\ResourceModel\DesignerData::class
        );
    }
}

