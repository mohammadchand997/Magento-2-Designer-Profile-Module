<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Eviaglobal\Designer\Model;

use Eviaglobal\Designer\Api\Data\DesignerInterface;
use Magento\Framework\Model\AbstractModel;

class Designer extends AbstractModel implements DesignerInterface
{

    /**
     * @inheritDoc
     */
    public function _construct()
    {
        $this->_init(\Eviaglobal\Designer\Model\ResourceModel\Designer::class);
    }

    /**
     * @inheritDoc
     */
    public function getDesignerId()
    {
        return $this->getData(self::DESIGNER_ID);
    }

    /**
     * @inheritDoc
     */
    public function setDesignerId($designerId)
    {
        return $this->setData(self::DESIGNER_ID, $designerId);
    }

    /**
     * @inheritDoc
     */
    public function getTitle()
    {
        return $this->getData(self::TITLE);
    }

    /**
     * @inheritDoc
     */
    public function setTitle($title)
    {
        return $this->setData(self::TITLE, $title);
    }

    /**
     * @inheritDoc
     */
    public function getLogo()
    {
        return $this->getData(self::LOGO);
    }

    /**
     * @inheritDoc
     */
    public function setLogo($logo)
    {
        return $this->setData(self::LOGO, $logo);
    }

    /**
     * @inheritDoc
     */
    public function getBanner()
    {
        return $this->getData(self::BANNER);
    }

    /**
     * @inheritDoc
     */
    public function setBanner($banner)
    {
        return $this->setData(self::BANNER, $banner);
    }

    /**
     * @inheritDoc
     */
    public function getAbout()
    {
        return $this->getData(self::ABOUT);
    }

    /**
     * @inheritDoc
     */
    public function setAbout($about)
    {
        return $this->setData(self::ABOUT, $about);
    }

    /**
     * @inheritDoc
     */
    public function getWebsiteUrl()
    {
        return $this->getData(self::WEBSITE_URL);
    }

    /**
     * @inheritDoc
     */
    public function setWebsiteUrl($websiteUrl)
    {
        return $this->setData(self::WEBSITE_URL, $websiteUrl);
    }

    /**
     * @inheritDoc
     */
    public function getCustomerId()
    {
        return $this->getData(self::CUSTOMER_ID);
    }

    /**
     * @inheritDoc
     */
    public function setCustomerId($customerId)
    {
        return $this->setData(self::CUSTOMER_ID, $customerId);
    }

    /**
     * @inheritDoc
     */
    public function getCity()
    {
        return $this->getData(self::CITY);
    }

    /**
     * @inheritDoc
     */
    public function setCity($city)
    {
        return $this->setData(self::CITY, $city);
    }

    /**
     * @inheritDoc
     */
    public function getCountry()
    {
        return $this->getData(self::COUNTRY);
    }

    /**
     * @inheritDoc
     */
    public function setCountry($country)
    {
        return $this->setData(self::COUNTRY, $country);
    }
}

