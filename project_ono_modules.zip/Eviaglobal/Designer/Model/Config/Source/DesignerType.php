<?php

namespace Eviaglobal\Designer\Model\Config\Source;

use \Magento\Catalog\Model\ResourceModel\Product\Attribute\CollectionFactory;
use Magento\Catalog\Model\Product\Attribute\Repository;
use Magento\Framework\App\Request\Http;

class DesignerType implements \Magento\Framework\Option\ArrayInterface
{

    protected $attributeCollectionFactory;

	protected $attributeRepository;

    protected $request;

	public function __construct(
        CollectionFactory $attributecollectionFactory,
        Repository $attributeRepository,
        Http $request
    ){
    	$this->attributeCollectionFactory = $attributecollectionFactory;
    	$this->attributeRepository = $attributeRepository;
        $this->request = $request;
    }

    public function toOptionArray()
    {
        $params=$this->request->getParams();
        $storeId=0;
        if(array_key_exists("store",$params)) {
            $storeId = $params['store'];
        }
        $optionArray=$this->attributeRepository->get('designer_type')->getOptions();   
        $options = [];
        if($storeId>0) {
            $optionArray=$this->attributeRepository->get('designer_type')->setStoreId($storeId)->getOptions();
        } 

    	foreach($optionArray as $option){
    		if($option->getData()['value'] == '') 
    			continue;
            $options[] = $option->getData();
        }
       
        return $options;
    }
}