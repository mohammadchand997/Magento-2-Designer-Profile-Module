<?php
declare(strict_types=1);

namespace Eviaglobal\Designer\Model;

use Eviaglobal\Designer\Api\Data\ProjectInterface;
use Eviaglobal\Designer\Api\Data\ProjectInterfaceFactory;
use Eviaglobal\Designer\Api\Data\ProjectSearchResultsInterfaceFactory;
use Eviaglobal\Designer\Api\ProjectRepositoryInterface;
use Eviaglobal\Designer\Model\ResourceModel\Project as ResourceProject;
use Eviaglobal\Designer\Model\ResourceModel\Project\CollectionFactory as ProjectCollectionFactory;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;

class ProjectRepository implements ProjectRepositoryInterface
{

    /**
     * @var ResourceProject
     */
    protected $resource;

    /**
     * @var Project
     */
    protected $searchResultsFactory;

    /**
     * @var CollectionProcessorInterface
     */
    protected $collectionProcessor;

    /**
     * @var ProjectInterfaceFactory
     */
    protected $projectFactory;

    /**
     * @var ProjectCollectionFactory
     */
    protected $projectCollectionFactory;


    /**
     * @param ResourceProject $resource
     * @param ProjectInterfaceFactory $projectFactory
     * @param ProjectCollectionFactory $projectCollectionFactory
     * @param ProjectSearchResultsInterfaceFactory $searchResultsFactory
     * @param CollectionProcessorInterface $collectionProcessor
     */
    public function __construct(
        ResourceProject $resource,
        ProjectInterfaceFactory $projectFactory,
        ProjectCollectionFactory $projectCollectionFactory,
        ProjectSearchResultsInterfaceFactory $searchResultsFactory,
        CollectionProcessorInterface $collectionProcessor
    ) {
        $this->resource = $resource;
        $this->projectFactory = $projectFactory;
        $this->projectCollectionFactory = $projectCollectionFactory;
        $this->searchResultsFactory = $searchResultsFactory;
        $this->collectionProcessor = $collectionProcessor;
    }

    /**
     * @inheritDoc
     */
    public function save(ProjectInterface $project)
    {
        try {
            $this->resource->save($project);
        } catch (\Exception $exception) {
            throw new CouldNotSaveException(__(
                'Could not save the project: %1',
                $exception->getMessage()
            ));
        }
        return $project;
    }

    /**
     * @inheritDoc
     */
    public function get($projectId)
    {
        $project = $this->projectFactory->create();
        $this->resource->load($project, $projectId);
        if (!$project->getId()) {
            throw new NoSuchEntityException(__('Project with id "%1" does not exist.', $projectId));
        }
        return $project;
    }

    /**
     * @inheritDoc
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $criteria
    ) {
        $collection = $this->projectCollectionFactory->create();
        
        $this->collectionProcessor->process($criteria, $collection);
        
        $searchResults = $this->searchResultsFactory->create();
        $searchResults->setSearchCriteria($criteria);
        
        $items = [];
        foreach ($collection as $model) {
            $items[] = $model;
        }
        
        $searchResults->setItems($items);
        $searchResults->setTotalCount($collection->getSize());
        return $searchResults;
    }

    /**
     * @inheritDoc
     */
    public function delete(ProjectInterface $project)
    {
        try {
            $projectModel = $this->projectFactory->create();
            $this->resource->load($projectModel, $project->getProjectId());
            $this->resource->delete($projectModel);
        } catch (\Exception $exception) {
            throw new CouldNotDeleteException(__(
                'Could not delete the Project: %1',
                $exception->getMessage()
            ));
        }
        return true;
    }

    /**
     * @inheritDoc
     */
    public function deleteById($projectId)
    {
        return $this->delete($this->get($projectId));
    }
}

