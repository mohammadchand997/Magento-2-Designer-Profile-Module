<?php

namespace Eviaglobal\Category\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Catalog\Model\Product;
use Magento\Framework\Pricing\PriceCurrencyInterface;

class CustomOptionPriceModifier implements ObserverInterface
{
    /**
     * @var PriceCurrencyInterface
     */
    private $priceCurrency;

    public function __construct(PriceCurrencyInterface $priceCurrency)
    {
        $this->priceCurrency = $priceCurrency;
    }

    public function execute(Observer $observer)
    {
        /** @var Product $product */
        $product = $observer->getEvent()->getProduct();
        $quoteItem = $observer->getEvent()->getQuoteItem();
    //     echo "<pre>";
    //     print_r($product->getData());
    //     die("Ww");
    //     // Get the custom option price, if any
    //    $customOptionPrice = $quoteItem->getProductOptionByCode('custom_option_price');
    //    die("SDdss");
    //     if ($customOptionPrice !== null) {
    //         // Subtract the custom option price from the final price
    //         $finalPrice = $observer->getEvent()->getPrice();
    //         $finalPrice -= $this->priceCurrency->round($customOptionPrice);
    //         $observer->getEvent()->setPrice($finalPrice);
        // }
    }
}
