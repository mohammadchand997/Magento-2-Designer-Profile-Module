<?php
declare(strict_types=1);

namespace Eviaglobal\Category\Helper;

use Magento\Catalog\Model\ResourceModel\Category\CollectionFactory;
use Magento\Catalog\Model\CategoryFactory;
use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Catalog\Helper\Image;
use Magento\Catalog\Model\ProductRepository;
use Eviaglobal\Brand\Model\BrandDataFactory;
use Eviaglobal\ProductPricing\Helper\PricingData;
use Magento\Framework\Pricing\Helper\Data as PricingHelper;

class Data extends AbstractHelper
{
	protected $_categoryCollectionFactory;
	protected $_categoryFactory;
    protected $imageHelper; 
    protected $productRepository;   
    protected $brandFactory;
    protected $pricingData;
    protected $pricingHelper;
    /**
     * @param \Magento\Framework\App\Helper\Context $context
     */
    public function __construct(
        \Magento\Framework\App\Helper\Context $context,
        CollectionFactory $categoryCollectionFactory,
        CategoryFactory $categoryFactory,
        Image $imageHelper,
        ProductRepository $productRepository,
        BrandDataFactory $brandFactory,
        PricingData $pricingData,
        PricingHelper $pricingHelper
    ) {
    	$this->_categoryCollectionFactory = $categoryCollectionFactory;
    	$this->_categoryFactory = $categoryFactory;
        $this->imageHelper = $imageHelper;
        $this->productRepository = $productRepository;
        $this->brandFactory = $brandFactory;
        $this->pricingData = $pricingData;
        $this->pricingHelper = $pricingHelper;
        parent::__construct($context);
    }

    

    public function getattributeByCategory($categoryIds, $page = 0) {
        if($page > 0 ){
            $page -= 1;
        }
        $categories = $this->getCategoryCollection($categoryIds); 


        $attrData = '';
        foreach ($categories as $category) {
            $attrData = $this->getCategoryData($category->getId(), 'advertisement_block');
        }
        if(!$attrData){
          return '';  
        }

		$getSku = explode(",",$attrData);

        $getProduct = [];
        foreach ($getSku as $sku) {

            $product = $this->getProductBySku($sku);
            if($product) {
                $image =  $product->getPopular() ? $product->getPopular() : '';
                $data['id'] = $product->getId();
                $data['name'] = $product->getName();
                $data['url'] = $product->getProductUrl();
                $data['sku'] = $product->getSku();

                $priceArray = $this->pricingData->getProductCustomPricing($product);
                $getCustomPrice = round(floatval($priceArray['Price']));
                $customPrice = $this->pricingHelper->currency($getCustomPrice, true, false);

                $data['price'] = ($priceArray["Price"] >0) ? $customPrice : $product->getPrice();
                $data['image'] = $image;
                $data['product_thumbnail_image'] = $this->imageHelper->init($product, 'product_base_image')->getUrl();
                $data['description'] = $product->getShortDescription();
                $brandId = $product->getCustomSupplier();

                $brandInfo = '';
                if($brandId){
                    $brandInfo = $this->getBrandInfo($brandId);
                }
                $data['brand'] = $brandInfo;
                array_push($getProduct, $data);
            }
         
        }

        $productsPerPage = $this->getDefaultProductsPerPage();

        $blockPerPage = 1;
        if($productsPerPage >= 8){
            $blockPerPage = $productsPerPage / 8 - 1;
        }

        $chunk_data = array_chunk($getProduct, $blockPerPage);
        $passData = array_key_exists($page,$chunk_data) ? $chunk_data[$page] : '';
		return $passData;
        
    }

    public function getProductBySku($sku)
    {
        if($sku!="") {
            $product = null;
            try{
                 $product=$this->productRepository->get($sku);
               }catch (\Magento\Framework\Exception\NoSuchEntityException $e){
                   $product = null;
            } 
            
        }
        return $product;
    }

    public function getCategoryCollection($categoryIds) {
        $collection = $this->_categoryCollectionFactory->create();
        $collection->addAttributeToSelect('*');
        $collection->addIsActiveFilter(); 
        $collection->addAttributeToFilter('entity_id', $categoryIds);
        return $collection;
    }

    public function getCategoryData($categoryId, $attrCode)
    {
        $category = $this->_categoryFactory->create()->load($categoryId);
        $categoryAttributeName = $category->getData($attrCode);
        return $categoryAttributeName;
    }

    public function getBrandInfo($brandId){
        $brand = $this->brandFactory->create()->load($brandId);
        $brandData = $brand->getData();
        $brandInfo=[];
        if(array_key_exists("url_key",$brandData)) {
            $brandInfo = array(
                'brand_name' => $brandData['title'],
                'brand_url' => $brandData['url_key'] 
            );
        }
   
        return $brandInfo;

    }

    public function getDefaultProductsPerPage()
    {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $storeManager = $objectManager->get(\Magento\Store\Model\StoreManagerInterface::class);
        $scopeConfig = $objectManager->get(\Magento\Framework\App\Config\ScopeConfigInterface::class);

        $storeId = $storeManager->getStore()->getId();
        $defaultProductsPerPage = $scopeConfig->getValue(
            'catalog/frontend/grid_per_page',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE,
            $storeId
        );
        return $defaultProductsPerPage;
    }
}
