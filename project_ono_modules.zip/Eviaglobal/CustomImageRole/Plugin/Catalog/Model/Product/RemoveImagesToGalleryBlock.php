<?php

namespace Eviaglobal\CustomImageRole\Plugin\Catalog\Model\Product;

use Magento\Catalog\Model\Product;
use Magento\Framework\App\Filesystem\DirectoryList;

class RemoveImagesToGalleryBlock
{
    protected $_filesystem;
    protected $_collectionFactory;

    public function __construct(
        \Magento\Framework\Data\CollectionFactory $collectionFactory,
        \Magento\Framework\Filesystem $filesystem
    ) {
        $this->_filesystem = $filesystem;
        $this->_collectionFactory = $collectionFactory;
    }

    public function afterGetMediaGalleryImages(Product $subject, $result)
    {
        $directory = $this->_filesystem->getDirectoryRead(DirectoryList::MEDIA);
        if ($subject->hasData('media_gallery_images')) {
            $subject->setData('media_gallery_images', $this->_collectionFactory->create());
            if (!$subject->getData('media_gallery_images')->count() && is_array($subject->getMediaGallery('images'))) {
                $images = $subject->getData('media_gallery_images');
                foreach ($subject->getMediaGallery('images') as $image) {
                    if (!empty($image['disabled'])
                        || !empty($image['removed'])
                        || empty($image['value_id'])
                        || $images->getItemById($image['value_id']) != null
                    ) {
                        continue;
                    }
                    if ($image['file'] == $subject->getPopular()) {
                        continue;
                    }
                    $image['url'] = $subject->getMediaConfig()->getMediaUrl($image['file']);
                    $image['id'] = $image['value_id'];
                    $image['path'] = $directory->getAbsolutePath($subject->getMediaConfig()->getMediaPath($image['file']));
                    $images->addItem(new \Magento\Framework\DataObject($image));

                }
                $subject->setData('media_gallery_images', $images);
            }
        }
        return $subject->getData('media_gallery_images');
    }
}