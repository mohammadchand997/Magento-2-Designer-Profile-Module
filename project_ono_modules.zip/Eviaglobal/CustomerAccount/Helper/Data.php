<?php

namespace Eviaglobal\CustomerAccount\Helper;

use \Magento\Framework\App\Helper\AbstractHelper;
use \Magento\Store\Model\StoreManagerInterface;
use \Magento\Framework\App\Config\ScopeConfigInterface;
use \Magento\Framework\View\Element\Template\Context;

class Data extends AbstractHelper
{
    /**
     * @var StoreManagerInterface
     */
    protected $storeManager;
    /**
     * @var ScopeConfigInterface
     */
    protected $scopeConfig;

    public function __construct(
        Context $context,
        ScopeConfigInterface $scopeConfig,
        StoreManagerInterface $storeManager
     ) {
         $this->scopeConfig = $scopeConfig;
         $this->storeManager = $storeManager;
     }
    public function getConfigValue() {
        return $this->scopeConfig->getValue("eviaglobal_configuration/general/customer_groups",
        \Magento\Store\Model\ScopeInterface::SCOPE_STORE,$this->storeManager->getStore()->getStoreId());
    }

    public function isProjectEnabled() {
        return $this->scopeConfig->getValue("eviaglobal_configuration/general/in_project",
        \Magento\Store\Model\ScopeInterface::SCOPE_STORE,$this->storeManager->getStore()->getStoreId());
    }

    public function getCustomerGroupValue()
    {
        $groups=$this->getConfigValue();
        $groupArray=[];
        if( strpos($groups, ',') !== false ) {
            $groupArray=explode(",",$groups);
        } else {
            $groupArray[]=$groups;
        }

        return $groupArray;
    }

    public function showMenus($customerGroupId) 
    {
        $groupArray=$this->getCustomerGroupValue();
        $isProject_scene_enabled=$this->isProjectEnabled();
        $show_menu=false;
        if(in_array($customerGroupId,$groupArray) && $isProject_scene_enabled==1) {
            $show_menu=true;
        }

        return $show_menu;
    }
}