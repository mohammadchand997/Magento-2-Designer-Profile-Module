<?php

namespace Eviaglobal\CustomerAccount\Observer;

use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Event\Observer;
use Magento\Customer\Api\Data\AddressInterfaceFactory;
use Magento\Customer\Api\Data\AddressInterface;
use Magento\Customer\Api\AddressRepositoryInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\Checkout\Model\Session as CheckoutSession;
use Magento\Customer\Api\Data\RegionInterfaceFactory;
use Magento\Directory\Model\RegionFactory;

class SaveBillingAddressBeforeObserver implements ObserverInterface
{
    protected $addressFactory;
    protected $addressRepository;
    protected $checkoutSession;
    protected $regionInterfaceFactory;
    protected $regionFactory;

    public function __construct(
        AddressInterfaceFactory $addressFactory,
        AddressRepositoryInterface $addressRepository,
        CheckoutSession $checkoutSession,
        RegionInterfaceFactory $regionInterfaceFactory,
        RegionFactory $regionFactory
    ) {
        $this->addressFactory = $addressFactory;
        $this->addressRepository = $addressRepository;
        $this->checkoutSession = $checkoutSession;
        $this->regionInterfaceFactory = $regionInterfaceFactory;
        $this->regionFactory = $regionFactory;
    }

    public function execute(Observer $observer)
    {
        $quote = $observer->getEvent()->getQuote();
        $billingAddress = $quote->getBillingAddress();

        $billingAddressData = $this->checkoutSession->getCurrBillingAddress();

        if ($billingAddressData) {
            // Set basic billing address data
            $billingAddress->setFirstname($billingAddressData['firstname']);
            $billingAddress->setLastname($billingAddressData['lastname']);
            $billingAddress->setStreet([$billingAddressData['street[0]'], $billingAddressData['street[1]']]);
            $billingAddress->setCountryId($billingAddressData['country_id']);
            $billingAddress->setCity($billingAddressData['city']);
            $billingAddress->setPostcode($billingAddressData['postcode']);
            $billingAddress->setCompany($billingAddressData['company']);
            $billingAddress->setTelephone($billingAddressData['telephone']);
            $billingAddress->setVatId($billingAddressData['vat_id']);

            // Set region and region_id
            $regionId = $billingAddressData['region_id'] ?? null;
            $regionName = $billingAddressData['region'] ?? null;

            if ($regionId) {
                // Get region object by region ID
                $region = $this->regionFactory->create()->load($regionId);

                if ($region->getId()) {
                    $billingAddress->setRegionId($regionId);
                    $billingAddress->setRegion($region->getName());
                }
            } elseif ($regionName) {
                // Set region name directly
                $billingAddress->setRegion($regionName);
            }
            $billingAddress->save();
            // Save the billing address
            $this->_saveBillingAddress($quote->getCustomer()->getId(), $billingAddressData);

            $this->checkoutSession->unsCurrBillingAddress();

            \Magento\Framework\App\ObjectManager::getInstance()->get('Psr\Log\LoggerInterface')->debug('post data: '.print_r($billingAddressData, true));
        }

        return $this;
    }

    private function _saveBillingAddress($customerId, $billingAddressData)
    {
        try {
            /** @var AddressInterface $billingAddress */
            $billingAddress = $this->addressFactory->create();
            
            // Set the customer ID
            $billingAddress->setCustomerId($customerId);
            //print_r($this->checkoutSession->getCurrBillingAddress()); die;
            // Set other address data
            $billingAddress->setFirstname($billingAddressData['firstname']);
            $billingAddress->setLastname($billingAddressData['lastname']);
            $street = [$billingAddressData["street[0]"], $billingAddressData["street[1]"]];
            $billingAddress->setStreet($street);
            $billingAddress->setCountryId($billingAddressData['country_id']);
            $billingAddress->setCity($billingAddressData['city']);
            $billingAddress->setPostcode($billingAddressData['postcode']);
            $billingAddress->setCompany($billingAddressData['company']);
            $billingAddress->setTelephone($billingAddressData['telephone']);
            $billingAddress->setVatId($billingAddressData['vat_id']);
            
            // Set region and region_id
            $regionId = $billingAddressData['region_id'] ?? null;
            $regionName = $billingAddressData['region'] ?? null;

            if ($regionId) {
                // Get region object by region ID
                $region = $this->regionFactory->create()->load($regionId);

                if ($region->getId()) {
                    $billingAddress->setRegionId($regionId);
                }
            }
            
            // Set custom attribute for region name
            if ($regionName) {
                $region = $this->regionInterfaceFactory->create();
                $region->setRegion($regionName);
                $billingAddress->setRegion($region);
            }
            
            // Save the billing address
            $this->addressRepository->save($billingAddress);
        } catch (LocalizedException $e) {
            // Handle exception
            throw new LocalizedException(__('Unable to save billing address: %1', $e->getMessage()));
        }
    }
}
