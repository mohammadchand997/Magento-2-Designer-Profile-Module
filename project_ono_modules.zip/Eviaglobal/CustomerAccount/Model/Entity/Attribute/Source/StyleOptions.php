<?php

namespace Eviaglobal\CustomerAccount\Model\Entity\Attribute\Source;

use Magento\Eav\Model\Entity\Attribute\Source\AbstractSource;
use Eviaglobal\Brand\Helper\Data;

class StyleOptions extends AbstractSource
{
    /**
    * @var Data
    */
    private $data;

    public function __construct(
        Data $data
    ){
        $this->data=$data;
    }
    public function getAllOptions()
    {
        $optionArray=[];
        $getStyles = $this->data->getStylesOptions();
        unset($getStyles[0]);
        // print_r($getStyles);
        foreach ($getStyles as $key => $item) {
            $optionArray[]= ['label' => __($item['label'] ), 'value' => $item['value']];
            
        }
       
        // print_r($optionArray);
        // die("Sdsfsd");
        return $optionArray;
    }
}