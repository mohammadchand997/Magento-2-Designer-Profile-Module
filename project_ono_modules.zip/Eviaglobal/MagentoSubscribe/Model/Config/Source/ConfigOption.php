<?php

namespace Eviaglobal\MagentoSubscribe\Model\Config\Source;

use Magento\Framework\Data\OptionSourceInterface;
use Magento\Customer\Model\ResourceModel\Group\Collection as CustomerGroup;

class ConfigOption implements OptionSourceInterface
{
    protected $customerGroup;

    public function __construct(
        CustomerGroup $customerGroup
    )
    {
        $this->customerGroup = $customerGroup;
    }

    public function toOptionArray()
    {
        $customerGroups = $this->customerGroup->toOptionArray();
        return $customerGroups;
    }
}