<?php

namespace Eviaglobal\MagentoSubscribe\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;

class QuoteSubmitBefore implements ObserverInterface
{
    public function execute(Observer $observer)
    {
        $quote = $observer->getData('quote');

        if($quote->getId()){

            // $quoteItemData = $this->getQuoteItemData($quote);

            // $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
            // $session = $objectManager->get('Magento\Framework\Session\SessionManagerInterface');
            // $session->start();
            // $quote_scene_id = $session->getData('quote_scene_id');
            // echo '<pre>';
            // print_r($quote_scene_id);
            // die;

        }
        
    }

    public function getQuoteItemData($quote)
    {
        try {

            $quoteItemData = [];
            foreach ($quote->getAllItems() as $quoteItem) {
                $quoteItemData[] = [
                    'item_id' => $quoteItem->getItemId(),
                    'product_id' => $quoteItem->getProductId(),
                    'sku' => $quoteItem->getSku(),
                    'name' => $quoteItem->getName(),
                    'price' => $quoteItem->getPrice(),
                    'quantity' => $quoteItem->getQty(),
                ];
            }

            return $quoteItemData;
        } catch (\Exception $e) {
            // Handle exceptions, e.g., quote not found
            return [];
        }
    }
}
