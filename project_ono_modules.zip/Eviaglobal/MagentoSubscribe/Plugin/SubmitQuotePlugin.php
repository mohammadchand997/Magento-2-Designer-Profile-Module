<?php
namespace Eviaglobal\MagentoSubscribe\Plugin;

use Magento\Framework\GraphQl\Config\Element\Field;
use Magento\Framework\GraphQl\Schema\Type\ResolveInfo;
use Amasty\RequestAQuoteGraphql\Model\Resolver\SubmitQuote;
use Magento\Framework\Interception\PluginList\PluginList;
use Magento\Framework\Interception\Interceptor;

class SubmitQuotePlugin
{
    private const INPUT_CODE = 'input';
    private const UPDATE_QUOTE_ITEMS_CODE = 'updateQuoteItemsInput';
    private const CUSTOMER_INPUT_CODE = 'customerInput';

    public function afterResolve(
        SubmitQuote $subject,
        $result,
        Field $field, $context, ResolveInfo $info, array $value = null, array $args = null
    ) {
        $updateQuoteItemsData = $args[self::INPUT_CODE][self::UPDATE_QUOTE_ITEMS_CODE];

        $scene_id = $updateQuoteItemsData['scene_id'];
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();

        // $session = $objectManager->get('Magento\Framework\Session\SessionManagerInterface');
        // $session->start();
        // $session->setData('quote_scene_id', $scene_id);

        $cartItems = $updateQuoteItemsData['cart_items'];
        foreach ($cartItems as $key => $value) {
            $cartItemUid = $value['cartItemUpdateInput']['cart_item_uid'];
            $cartItemId = base64_decode($cartItemUid);
            //save scene 
            if($scene_id){
                $projectHelper = $objectManager->get('Eviaglobal\Project\Helper\Data');
                $projectHelper->addSceneInQuoteItem($cartItemId, $scene_id);
            }
        }
        
        return $result;
    }
}
