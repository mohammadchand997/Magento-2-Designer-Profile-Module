<?php
namespace Eviaglobal\MagentoSubscribe\Helper;

use Magento\Store\Model\ScopeInterface;
use Magento\Customer\Model\Session as CustomerSession;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\App\Helper\AbstractHelper;

class Data extends AbstractHelper
{
   const XML_CONFIG_PATH = 'eviaglobal_configuration/general/customer_groups';
   const XML_FIELD_PROJECT_CONFIG_PATH = 'eviaglobal_configuration/general/in_project';
   
   public function __construct(
        CustomerSession $customerSession,
        ScopeConfigInterface $scopeConfig
    ){
        $this->scopeConfig = $scopeConfig;
        $this->customerSession = $customerSession;
    }

   public function isValidCustomerGroup()
   {
        $configValue = $this->scopeConfig->getValue(self::XML_CONFIG_PATH,ScopeInterface::SCOPE_STORE);
        $selectedCustomerGroups = explode(",",$configValue);
        $getCustomer = in_array($this->getGroupId(), $selectedCustomerGroups) ? true : false;
        return $getCustomer;
   }

   public function getGroupId(){

        $getGroupId = '';
        if($this->customerSession->isLoggedIn()){
            $getGroupId = $this->customerSession->getCustomer()->getGroupId();
        }
        return $getGroupId;
   }

   public function inProject(){
         $getProjectValue = $this->scopeConfig->getValue(self::XML_FIELD_PROJECT_CONFIG_PATH,ScopeInterface::SCOPE_STORE);
         return $getProjectValue;
   }  
}