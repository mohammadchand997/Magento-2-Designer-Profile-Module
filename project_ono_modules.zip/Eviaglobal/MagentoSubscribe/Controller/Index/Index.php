<?php
declare(strict_types=1);

namespace Eviaglobal\MagentoSubscribe\Controller\Index;

use Magento\Framework\App\Action\HttpPostActionInterface;
use Magento\Newsletter\Model\SubscriberFactory;
use Magento\Newsletter\Model\Subscriber;
use Magento\Framework\Controller\Result\JsonFactory;

class Index implements HttpPostActionInterface
{
    /**
     * Constructor
     *
     * @param SubscriberFactory $subscriberFactory
     */
    public function __construct(
        SubscriberFactory $subscriberFactory,
        Subscriber $subscriber,
        JsonFactory $resultJsonFactory

    )
    {
        $this->subscriberFactory= $subscriberFactory;
        $this->_subscriber= $subscriber;
        $this->resultJsonFactory = $resultJsonFactory;
    }

    /**
     * Execute view action
     */
    public function execute()
    {
        $response = array();
        if(isset($_POST['email']) && !empty($_POST['email'])){
            try {
                $email = $_POST['email'];
                $objectManager =  \Magento\Framework\App\ObjectManager::getInstance();        
                $storeManager = $objectManager->get('\Magento\Store\Model\StoreManagerInterface');

                $checkSubscriber = $this->_subscriber->loadByEmail($email);
                
                if ($checkSubscriber->isSubscribed()) {
                     $response = [
                        'status' => 'OK',
                        'msg' => __('This email address is already subscribed.'),
                    ];
                    return $this->resultJsonFactory->create()->setData($response);
                }

                $status = $this->subscriberFactory->create()->subscribe($email);
               
                if ($status == Subscriber::STATUS_NOT_ACTIVE) {
                    $response = [
                        'status' => 'OK',
                        'msg' => __('The confirmation request has been sent.'),
                    ];

                }else {
                    $response = [
                        'status' => 'OK',
                        'msg' => __('Thank you for your subscription.'),
                    ];
                }
            } catch (\Magento\Framework\Exception\LocalizedException $e) {
                $response = [
                    'status' => 'ERROR',
                    'msg' => __('There was a problem with the subscription: %1', $e->getMessage()),
                ];
            } catch (\Exception $e) {
                $response = [
                    'status' => 'ERROR',
                    'msg' => __('Something went wrong with the subscription.'),
                ];
            }
        }

        return $this->resultJsonFactory->create()->setData($response);
    }

    /*private function isAlreadySubscribe($email, $store_id){
        $status = $this->subscriberFactory->create()->loadByEmail($email);
        return $status ? true : false;
    }*/
}

