<?php

namespace Eviaglobal\MagentoSubscribe\Controller\Workwithus;

use Magento\Framework\App\Action\HttpPostActionInterface;
use Magento\Framework\Controller\ResultFactory;
use Magento\Store\Model\ScopeInterface;
use Magento\Framework\Filesystem;
use Magento\MediaStorage\Model\File\UploaderFactory;

class Index implements HttpPostActionInterface
{   
    /**
     * @var \Magento\Framework\App\Request\Http
     */
    protected $_request;

    /**
     * @var \Magento\Framework\Mail\Template\TransportBuilder
     */
    protected $_transportBuilder;

    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $_storeManager;

    /**
     * For logger, var/log
     */
    protected $_logger;

    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\App\Request\Http $request,
        ResultFactory $resultFactory,
        \Magento\Framework\Mail\Template\TransportBuilder $transportBuilder,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Psr\Log\LoggerInterface $logger,
        \Magento\Framework\Message\ManagerInterface $messageManager,
        Filesystem $filesystem,
        UploaderFactory $fileUploader
    ){
        $this->_request = $request;
        $this->resultFactory = $resultFactory;
        $this->_transportBuilder = $transportBuilder;
        $this->scopeConfig = $scopeConfig;
        $this->_storeManager = $storeManager;
        $this->_logger = $logger;
        $this->messageManager = $messageManager;
        $this->filesystem = $filesystem;
        $this->fileUploader = $fileUploader;
        $this->mediaDirectory = $filesystem->getDirectoryWrite(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA);
    }
    
    public function execute()
    {   
        $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
        $post = $this->_request->getPost();
        if (!empty($post)) {

            $storeName = $this->_storeManager->getStore()->getCode();
            $adminTemplateId = $storeName == 'fr' ? '30' : '7';
            $userTemplateId = $storeName == 'fr' ? '31' : '8';

            $maxsize = 5 * 102400;
            if (isset($_FILES['resume']) && $_FILES['resume']['size'] >= $maxsize) {
                $this->messageManager->addErrorMessage(__('The file size should not exceed 5MB'));
                $resultRedirect->setUrl('/work-with-us');
                return $resultRedirect;
            }
        
            $adminTo = [
                'name' => $this->scopeConfig->getValue('trans_email/ident_support/name', ScopeInterface::SCOPE_STORE),
                'email' => $this->scopeConfig->getValue('trans_email/ident_support/email', ScopeInterface::SCOPE_STORE)
            ];
            $userTo = [
                'name' => $post['name'],
                'email' => $post['email'],
            ];

            $this->sendAknowledgementEmail($post, $userTemplateId, $userTo);
            //sleep(3);
            $this->sendEmailToAdmin($post, $adminTemplateId, $adminTo);
            $this->messageManager->addSuccessMessage(
                __('Thanks for contacting us with your comments and questions. We\'ll respond to you very soon.')
            );

            $resultRedirect->setUrl('/work-with-us');

            return $resultRedirect;
        }
    }

    public function sendEmailToAdmin($post, $templateId, $to)
    {
        $var = array(
            'store' => $this->_storeManager->getStore(),
            'name' => $post['name'], 
            'lastname' => $post['lastname'], 
            'email' => $post['email'], 
            'telephone' => $post['telephone'], 
            'country_id' => $post['country_id'], 
            'city' => $post['city'],
            'policy' => implode(', ', $post['policy']),
            'comment' => $post['comment']
        );
        try {
                $attName = 'resume-'.$var['name'].'-'.$var['lastname'].'-'.time();
                $store = $this->_storeManager->getStore()->getId();
                $file = $this->_request->getFiles('resume');
                $resume = $this->uploadFile($file);
                $transport = $this->_transportBuilder->setTemplateIdentifier($templateId)
                    ->setTemplateOptions(['area' => 'frontend', 'store' => $store])
                    ->setTemplateVars($var)
                    ->setFrom('general')
                    ->addTo($to['email'], $to['name'])
                    ->addAttachment(file_get_contents($resume), $attName, $file['type'])
                    ->getTransport();
                //$this->_transportBuilder->addAttachment(file_get_contents($resume), 'resume', 'application/pdf');
                $transport->sendMessage();
                return true;
            } catch (\Exception $e) {
                $this->_logger->critical($e->getMessage());
                return false;
            }
    }

    public function sendAknowledgementEmail($post, $templateId, $to)
    {
        $var = array(
            'store' => $this->_storeManager->getStore(),
            'name' => $post['name'], 
            'lastname' => $post['lastname'], 
            'email' => $post['email'], 
            'telephone' => $post['telephone'], 
            'country_id' => $post['country_id'], 
            'city' => $post['city'],
            'policy' => implode(', ', $post['policy']),
            'comment' => $post['comment']
        );
        try {
                $store = $this->_storeManager->getStore()->getId();
                $transport = $this->_transportBuilder->setTemplateIdentifier($templateId)
                    ->setTemplateOptions(['area' => 'frontend', 'store' => $store])
                    ->setTemplateVars($var)
                    ->setFrom('general')
                    ->addTo($to['email'], $to['name'])
                    ->addAttachment(null, null, null)
                    ->getTransport();
                $transport->sendMessage();
                return true;
            } catch (\Exception $e) {
                $this->_logger->critical($e->getMessage());
                return false;
            }
    }

     public function uploadFile($file)
     {  
        $targetFolder = 'resume/';
        if ($file) {
            $target = $this->mediaDirectory->getAbsolutePath($targetFolder);        
            
            /** @var $uploader \Magento\MediaStorage\Model\File\Uploader */
            $uploader = $this->fileUploader->create(['fileId' => 'resume']);
            
            // set allowed file extensions
            $uploader->setAllowedExtensions(['pdf', 'doc', 'docx']);
            
            // allow folder creation
            $uploader->setAllowCreateFolders(true);

            // rename file name if already exists 
            $uploader->setAllowRenameFiles(true);

            // upload file in the specified folder
            $result = $uploader->save($target);
            if ($result['file']) {
                return $target .'/'. $uploader->getUploadedFileName();
            }
            return null;
        }
     }
}