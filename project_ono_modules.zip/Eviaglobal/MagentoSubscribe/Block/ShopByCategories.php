<?php

namespace Eviaglobal\MagentoSubscribe\Block;

use Magento\Catalog\Model\ResourceModel\Category\CollectionFactory;
use Magento\Catalog\Model\CategoryFactory;

class ShopByCategories extends \Magento\Framework\View\Element\Template
{
    protected $_categoryCollectionFactory;
    protected $_categoryFactory;    

    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        CollectionFactory $categoryCollectionFactory,
        CategoryFactory $categoryFactory
    )
    {
        $this->_categoryCollectionFactory = $categoryCollectionFactory;
        $this->_categoryFactory = $categoryFactory;
        parent::__construct($context);
    }

    public function getattributeByCategory() {

        $categories = $this->getCategoryCollection(); 


        $getData = [];
        foreach ($categories as $category) {

            $attrData = $this->getCategoryData($category->getId(), 'thumbnail_image');
            if($attrData){
                $data['category_id'] = $category->getId();
                $data['thumbnail_image_path'] = $this->getCategoryData($category->getId(), 'thumbnail_image');
                $data['category_name'] = $category->getName();
                $data['url_key'] = $category['url_key'];
                $data['url_path'] = $category['url_path'];
                array_push($getData, $data);
            }
            
        }
        return $getData;
        
    }

    public function getCategoryCollection() {
        $collection = $this->_categoryCollectionFactory->create();
        $collection->addAttributeToSelect('*');
        $collection->addIsActiveFilter(); 
        $collection->addAttributeToFilter('show_in_homepage', 1);
        return $collection;
    }

    public function getCategoryData($categoryId, $attrCode)
    {
        $category = $this->_categoryFactory->create()->load($categoryId);
        $categoryAttributeName = $category->getData($attrCode);
        return $categoryAttributeName;
    }
}