<?php
declare(strict_types=1);

namespace Eviaglobal\Euvat\Plugin\Geissweb\Euvat\Helper;

class Configuration
{

    public function afterGetCatalogPriceDisplayTypeRules(
        \Geissweb\Euvat\Helper\Configuration $subject,
        $result
    ) {
        //Your plugin code
        return $result;
    }
}

