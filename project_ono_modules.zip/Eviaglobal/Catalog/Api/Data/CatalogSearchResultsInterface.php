<?php
declare(strict_types=1);

namespace Eviaglobal\Catalog\Api\Data;

interface CatalogSearchResultsInterface extends \Magento\Framework\Api\SearchResultsInterface
{

    /**
     * Get catalog list.
     * @return \Eviaglobal\Catalog\Api\Data\CatalogInterface[]
     */
    public function getItems();

    /**
     * Set brand_id list.
     * @param \Eviaglobal\Catalog\Api\Data\CatalogInterface[] $items
     * @return $this
     */
    public function setItems(array $items);
}

