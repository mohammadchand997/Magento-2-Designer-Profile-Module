<?php
/**
 * Copyright © zxccx All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Eviaglobal\Catalog\Plugin;

class SearchCriteriaBuilder
{

    public function afterBuild(
        \Magento\CatalogGraphQl\DataProvider\Product\SearchCriteriaBuilder $subject,
        $result
    ) {
        //$result->setVisibility([1,2,3,4]);
        /*foreach ($result->getFilterGroups() as $item) {
            print_r($item);
        }*/
        /*print_r($result->__toArray());

        die('plugin');*/
        $objectManager =  \Magento\Framework\App\ObjectManager::getInstance();        
 
$storeManager = $objectManager->get('\Magento\Store\Model\StoreManagerInterface');
 
//echo $storeManager->getStore()->getStoreId();
//die();
        //Your plugin code
        return $result;
    }
}

