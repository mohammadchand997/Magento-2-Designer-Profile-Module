<?php

namespace Eviaglobal\Catalog\Plugin;

use Magento\Catalog\Model\Product;
use Magento\CatalogInventory\Api\StockRegistryInterface;
use Magento\Framework\App\ResourceConnection;

class ProductSaveAfterPlugin
{
    private $stockRegistry;

    private const VISIBILITY_ATTR_ID = 99;

    public function __construct(
        StockRegistryInterface $stockRegistry,
        ResourceConnection $resourceConnection
    ) {
        $this->stockRegistry = $stockRegistry;
        $this->resourceConnection = $resourceConnection;
    }

    public function afterSave(
        Product $product,
        Product $resultProduct
    ) {
        if(isset($_POST['product']['current_product_id']) && !empty($_POST['product']['current_product_id'])){
            $productId = $_POST['product']['current_product_id'];
            $visibilityId = $_POST['product']['visibility'];
            if($visibilityId == 1){
                $stockSourceId = $this->getStockSourceId($productId);
                $this->saveVisibilityEnv($visibilityId, $productId, $stockSourceId);
            }
        }
        return $resultProduct;
    }

    private function getStockSourceId($productId) {
        try {
            $stockItem = $this->stockRegistry->getStockItem($productId);
            $stockSourceId = $stockItem->getItemId();
            return $stockSourceId;
        } catch (\Magento\Framework\Exception\NoSuchEntityException $e) {
            // Handle the exception, e.g., product not found or stock item not set
            return null;
        }
    }

    private function saveVisibilityEnv($visibilityId, $productId, $sourceId){
        $connection = $this->resourceConnection->getConnection();
        $tbl = $connection->getTableName('catalog_product_index_eav');
        $data = [
            'entity_id' => $productId,
            'attribute_id' => self::VISIBILITY_ATTR_ID,
            'store_id' => $this->getStoreId(),
            'value' => $visibilityId,
            'source_id' => $sourceId
        ];
        // delete before save
        $this->deleteExisting($visibilityId, $productId, $sourceId);

        return $connection->insert($tbl, $data);
    }

    private function deleteExisting($visibilityId, $productId, $sourceId){
        $connection = $this->resourceConnection->getConnection();
        $tbl = $connection->getTableName('catalog_product_index_eav');
        $data = [
            'entity_id = ?' => $productId,
            'attribute_id = ?' => self::VISIBILITY_ATTR_ID,
            'value = ?' => $visibilityId,
            'source_id = ?' => $sourceId,
            'store_id = ?' => $this->getStoreId()
        ];
        return $connection->delete($tbl, $data);
    }

    private function getStoreId(){
        $objectManager =  \Magento\Framework\App\ObjectManager::getInstance();
        $storeManager = $objectManager->get('\Magento\Store\Model\StoreManagerInterface');
        return $storeManager->getStore()->getStoreId();
    }
}
