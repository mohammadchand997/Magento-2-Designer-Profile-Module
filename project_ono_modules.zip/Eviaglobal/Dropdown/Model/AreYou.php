<?php
declare(strict_types=1);

namespace Eviaglobal\Dropdown\Model;

use Eviaglobal\Dropdown\Api\Data\AreYouInterface;
use Magento\Framework\Model\AbstractModel;

class AreYou extends AbstractModel implements AreYouInterface
{

    /**
     * @inheritDoc
     */
    public function _construct()
    {
        $this->_init(\Eviaglobal\Dropdown\Model\ResourceModel\AreYou::class);
    }

    /**
     * @inheritDoc
     */
    public function getAreYouId()
    {
        return $this->getData(self::ARE_YOU_ID);
    }

    /**
     * @inheritDoc
     */
    public function setAreYouId($areYouId)
    {
        return $this->setData(self::ARE_YOU_ID, $areYouId);
    }

    /**
     * @inheritDoc
     */
    public function getName()
    {
        return $this->getData(self::NAME);
    }

    /**
     * @inheritDoc
     */
    public function setName($name)
    {
        return $this->setData(self::NAME, $name);
    }
}

