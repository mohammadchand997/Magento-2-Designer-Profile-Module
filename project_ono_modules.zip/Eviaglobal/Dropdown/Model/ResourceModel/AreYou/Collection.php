<?php
declare(strict_types=1);

namespace Eviaglobal\Dropdown\Model\ResourceModel\AreYou;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

class Collection extends AbstractCollection
{

    /**
     * @inheritDoc
     */
    protected $_idFieldName = 'are_you_id';

    /**
     * @inheritDoc
     */
    protected function _construct()
    {
        $this->_init(
            \Eviaglobal\Dropdown\Model\AreYou::class,
            \Eviaglobal\Dropdown\Model\ResourceModel\AreYou::class
        );
    }
}

