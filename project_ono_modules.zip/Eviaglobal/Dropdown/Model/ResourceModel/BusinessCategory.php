<?php
declare(strict_types=1);

namespace Eviaglobal\Dropdown\Model\ResourceModel;

use Magento\Framework\Model\ResourceModel\Db\AbstractDb;

class BusinessCategory extends AbstractDb
{

    /**
     * @inheritDoc
     */
    protected function _construct()
    {
        $this->_init('eviaglobal_dropdown_business_category', 'business_category_id');
    }
}

