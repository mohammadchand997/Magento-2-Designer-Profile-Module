<?php
declare(strict_types=1);

namespace Eviaglobal\Dropdown\Model;

use Eviaglobal\Dropdown\Api\AreYouRepositoryInterface;
use Eviaglobal\Dropdown\Api\Data\AreYouInterface;
use Eviaglobal\Dropdown\Api\Data\AreYouInterfaceFactory;
use Eviaglobal\Dropdown\Api\Data\AreYouSearchResultsInterfaceFactory;
use Eviaglobal\Dropdown\Model\ResourceModel\AreYou as ResourceAreYou;
use Eviaglobal\Dropdown\Model\ResourceModel\AreYou\CollectionFactory as AreYouCollectionFactory;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;

class AreYouRepository implements AreYouRepositoryInterface
{

    /**
     * @var ResourceAreYou
     */
    protected $resource;

    /**
     * @var AreYouInterfaceFactory
     */
    protected $areYouFactory;

    /**
     * @var AreYouCollectionFactory
     */
    protected $areYouCollectionFactory;

    /**
     * @var AreYou
     */
    protected $searchResultsFactory;

    /**
     * @var CollectionProcessorInterface
     */
    protected $collectionProcessor;


    /**
     * @param ResourceAreYou $resource
     * @param AreYouInterfaceFactory $areYouFactory
     * @param AreYouCollectionFactory $areYouCollectionFactory
     * @param AreYouSearchResultsInterfaceFactory $searchResultsFactory
     * @param CollectionProcessorInterface $collectionProcessor
     */
    public function __construct(
        ResourceAreYou $resource,
        AreYouInterfaceFactory $areYouFactory,
        AreYouCollectionFactory $areYouCollectionFactory,
        AreYouSearchResultsInterfaceFactory $searchResultsFactory,
        CollectionProcessorInterface $collectionProcessor
    ) {
        $this->resource = $resource;
        $this->areYouFactory = $areYouFactory;
        $this->areYouCollectionFactory = $areYouCollectionFactory;
        $this->searchResultsFactory = $searchResultsFactory;
        $this->collectionProcessor = $collectionProcessor;
    }

    /**
     * @inheritDoc
     */
    public function save(AreYouInterface $areYou)
    {
        try {
            $this->resource->save($areYou);
        } catch (\Exception $exception) {
            throw new CouldNotSaveException(__(
                'Could not save the areYou: %1',
                $exception->getMessage()
            ));
        }
        return $areYou;
    }

    /**
     * @inheritDoc
     */
    public function get($areYouId)
    {
        $areYou = $this->areYouFactory->create();
        $this->resource->load($areYou, $areYouId);
        if (!$areYou->getId()) {
            throw new NoSuchEntityException(__('are_you with id "%1" does not exist.', $areYouId));
        }
        return $areYou;
    }

    /**
     * @inheritDoc
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $criteria
    ) {
        $collection = $this->areYouCollectionFactory->create();
        
        $this->collectionProcessor->process($criteria, $collection);
        
        $searchResults = $this->searchResultsFactory->create();
        $searchResults->setSearchCriteria($criteria);
        
        $items = [];
        foreach ($collection as $model) {
            $items[] = $model;
        }
        
        $searchResults->setItems($items);
        $searchResults->setTotalCount($collection->getSize());
        return $searchResults;
    }

    /**
     * @inheritDoc
     */
    public function delete(AreYouInterface $areYou)
    {
        try {
            $areYouModel = $this->areYouFactory->create();
            $this->resource->load($areYouModel, $areYou->getAreYouId());
            $this->resource->delete($areYouModel);
        } catch (\Exception $exception) {
            throw new CouldNotDeleteException(__(
                'Could not delete the are_you: %1',
                $exception->getMessage()
            ));
        }
        return true;
    }

    /**
     * @inheritDoc
     */
    public function deleteById($areYouId)
    {
        return $this->delete($this->get($areYouId));
    }
}

