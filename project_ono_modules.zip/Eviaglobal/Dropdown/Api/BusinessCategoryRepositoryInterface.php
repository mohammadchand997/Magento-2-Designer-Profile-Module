<?php
declare(strict_types=1);

namespace Eviaglobal\Dropdown\Api;

use Magento\Framework\Api\SearchCriteriaInterface;

interface BusinessCategoryRepositoryInterface
{

    /**
     * Save business_category
     * @param \Eviaglobal\Dropdown\Api\Data\BusinessCategoryInterface $businessCategory
     * @return \Eviaglobal\Dropdown\Api\Data\BusinessCategoryInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(
        \Eviaglobal\Dropdown\Api\Data\BusinessCategoryInterface $businessCategory
    );

    /**
     * Retrieve business_category
     * @param string $businessCategoryId
     * @return \Eviaglobal\Dropdown\Api\Data\BusinessCategoryInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function get($businessCategoryId);

    /**
     * Retrieve business_category matching the specified criteria.
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \Eviaglobal\Dropdown\Api\Data\BusinessCategorySearchResultsInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
    );

    /**
     * Delete business_category
     * @param \Eviaglobal\Dropdown\Api\Data\BusinessCategoryInterface $businessCategory
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function delete(
        \Eviaglobal\Dropdown\Api\Data\BusinessCategoryInterface $businessCategory
    );

    /**
     * Delete business_category by ID
     * @param string $businessCategoryId
     * @return bool true on success
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function deleteById($businessCategoryId);
}

