<?php
declare(strict_types=1);

namespace Eviaglobal\Dropdown\Api;

use Magento\Framework\Api\SearchCriteriaInterface;

interface AreYouRepositoryInterface
{

    /**
     * Save are_you
     * @param \Eviaglobal\Dropdown\Api\Data\AreYouInterface $areYou
     * @return \Eviaglobal\Dropdown\Api\Data\AreYouInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(
        \Eviaglobal\Dropdown\Api\Data\AreYouInterface $areYou
    );

    /**
     * Retrieve are_you
     * @param string $areYouId
     * @return \Eviaglobal\Dropdown\Api\Data\AreYouInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function get($areYouId);

    /**
     * Retrieve are_you matching the specified criteria.
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \Eviaglobal\Dropdown\Api\Data\AreYouSearchResultsInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
    );

    /**
     * Delete are_you
     * @param \Eviaglobal\Dropdown\Api\Data\AreYouInterface $areYou
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function delete(
        \Eviaglobal\Dropdown\Api\Data\AreYouInterface $areYou
    );

    /**
     * Delete are_you by ID
     * @param string $areYouId
     * @return bool true on success
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function deleteById($areYouId);
}

