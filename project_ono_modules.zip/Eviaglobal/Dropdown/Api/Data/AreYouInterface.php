<?php
declare(strict_types=1);

namespace Eviaglobal\Dropdown\Api\Data;

interface AreYouInterface
{

    const NAME = 'name';
    const ARE_YOU_ID = 'are_you_id';

    /**
     * Get are_you_id
     * @return string|null
     */
    public function getAreYouId();

    /**
     * Set are_you_id
     * @param string $areYouId
     * @return \Eviaglobal\Dropdown\AreYou\Api\Data\AreYouInterface
     */
    public function setAreYouId($areYouId);

    /**
     * Get name
     * @return string|null
     */
    public function getName();

    /**
     * Set name
     * @param string $name
     * @return \Eviaglobal\Dropdown\AreYou\Api\Data\AreYouInterface
     */
    public function setName($name);
}

