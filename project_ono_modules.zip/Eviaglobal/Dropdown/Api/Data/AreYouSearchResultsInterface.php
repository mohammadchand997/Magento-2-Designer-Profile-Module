<?php
declare(strict_types=1);

namespace Eviaglobal\Dropdown\Api\Data;

interface AreYouSearchResultsInterface extends \Magento\Framework\Api\SearchResultsInterface
{

    /**
     * Get are_you list.
     * @return \Eviaglobal\Dropdown\Api\Data\AreYouInterface[]
     */
    public function getItems();

    /**
     * Set name list.
     * @param \Eviaglobal\Dropdown\Api\Data\AreYouInterface[] $items
     * @return $this
     */
    public function setItems(array $items);
}

