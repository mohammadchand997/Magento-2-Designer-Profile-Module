<?php

namespace Eviaglobal\Guest\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Quote\Model\QuoteFactory;
use Magento\Quote\Model\QuoteRepository;
use Magento\Framework\Session\SessionManagerInterface;
use Magento\Customer\Model\Session as CustomerSession;
use Eviaglobal\Guest\Model\InfoFactory;
use Psr\Log\LoggerInterface;
use Magento\Quote\Api\CartRepositoryInterface;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\HTTP\Client\Curl;

class MergeCartObserver implements ObserverInterface
{
    protected $quoteFactory;
    protected $quoteRepository;
    protected $sessionManager;
    protected $customerSession;
    protected $infoFactory;
    protected $cartRepository;
    protected $storeManager;
    protected $curlClient;
    protected $logger;

    public function __construct(
        QuoteFactory $quoteFactory,
        QuoteRepository $quoteRepository,
        SessionManagerInterface $sessionManager,
        CustomerSession $customerSession,
        InfoFactory $infoFactory,
        CartRepositoryInterface $cartRepository,
        StoreManagerInterface $storeManager,
        Curl $curlClient,
        LoggerInterface $logger
    ) {
        $this->quoteFactory = $quoteFactory;
        $this->quoteRepository = $quoteRepository;
        $this->sessionManager = $sessionManager;
        $this->customerSession = $customerSession;
        $this->infoFactory = $infoFactory;
        $this->cartRepository = $cartRepository;
        $this->storeManager = $storeManager;
        $this->curlClient = $curlClient;
        $this->logger = $logger;
    }

    public function execute(Observer $observer)
    {
        try {
            $customer = $observer->getEvent()->getCustomer();
            $customerId = $customer->getId();

            $cart = $this->cartRepository->getActiveForCustomer($customerId);
            $cartId = $cart->getId();

            $this->logger->debug('mergecart cartid: ' . $cartId);

            $session = $this->sessionManager;

            if ($cartId && $session->getData('guestCartId')) {
                $guestCartId = $session->getData('guestCartId');
                $sourceCartId = $guestCartId;

                // $maskedQuoteId = $this->quoteRepository->get($cartId)->getMaskedId();
                // $destinationCartId = $maskedQuoteId;
                $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
                $maskedQuoteId = $objectManager->get('Magento\Quote\Model\QuoteIdToMaskedQuoteIdInterface');
                $destinationCartId = $maskedQuoteId->execute($cartId);

                $this->logger->debug('mergecart sourceCartId: ' . $sourceCartId);
                $this->logger->debug('mergecart destinationCartId: ' . $destinationCartId);

                if ($sourceCartId && $destinationCartId) {
                    $customerToken = $this->createCustomerToken($customerId);
                    $result = $this->mergeCarts($sourceCartId, $destinationCartId, $customerToken);

                    $this->logger->debug('mergecart customerToken: ' . $customerToken);
                    $this->logger->debug('mergecart result: ' . $result);

                    if (isset($result['status']) && $result['status'] === true) {
                        //$this->deleteDataByRemoteAddress($guestCartId);
                        $session->unsetData('guestCartId');
                    }
                }
            }
        } catch (\Exception $e) {
            $this->logger->error('Error in MergeCartObserver: ' . $e->getMessage());
        }
    }

    public function getGuestCartIdByRemoteAddress($remoteAddress)
    {
        $infoModel = $this->infoFactory->create();
        $infoModel->load($remoteAddress, 'remote_address');
        return $infoModel->getId() ? $infoModel->getData('guest_cart_id') : null;
    }

    public function deleteDataByRemoteAddress($remoteAddress)
    {
        $infoModel = $this->infoFactory->create();
        $infoModel->load($remoteAddress, 'remote_address');
        if ($infoModel->getId()) {
            $infoModel->delete();
            return true;
        }
        return false;
    }

    /**
     * Create a customer token
     *
     * @param int $customerId
     * @return string
     */
    private function createCustomerToken($customerId): string
    {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $tokenModelFactory = $objectManager->get(\Magento\Integration\Model\Oauth\TokenFactory::class);
        $customerToken = $tokenModelFactory->create();
        $tokenKey = $customerToken->createCustomerToken($customerId)->getToken();
        
        return $tokenKey;
    }

    private function mergeCarts($sourceCartId, $destinationCartId, $token)
    {
        try {
            $storeCode = $this->storeManager->getStore()->getCode();
            $baseUrl = $this->storeManager->getStore()->getBaseUrl();

            $query = '
                mutation {
                    mergeCarts(
                        source_cart_id: "' . $sourceCartId . '"
                        destination_cart_id: "' . $destinationCartId . '"
                    ) {
                        id
                    }
                }
            ';

            $this->curlClient->addHeader('Content-Type', 'application/json');
            $this->curlClient->addHeader('store', $storeCode);
            $this->curlClient->addHeader('Authorization', 'Bearer ' . $token);
            $this->curlClient->post($baseUrl . 'graphql', json_encode(['query' => $query]));

            $response = $this->curlClient->getBody();
            $responseData = json_decode($response, true);

            return isset($responseData['data']['mergeCarts'])
                ? ['status' => true, 'data' => $responseData['data']['mergeCarts']]
                : ['status' => false, 'data' => $responseData];
        } catch (\Exception $e) {
            $this->logger->critical('Error merging carts: ' . $e->getMessage());
            return [
                'status' => false,
                'data' => []
            ];
        }
    }
}
