<?php
/**
 * Copyright © Eviaglobal All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Eviaglobal\Guest\Model;

use Eviaglobal\Guest\Api\Data\InfoInterface;
use Magento\Framework\Model\AbstractModel;

class Info extends AbstractModel implements InfoInterface
{

    /**
     * @inheritDoc
     */
    public function _construct()
    {
        $this->_init(\Eviaglobal\Guest\Model\ResourceModel\Info::class);
    }

    /**
     * @inheritDoc
     */
    public function getInfoId()
    {
        return $this->getData(self::INFO_ID);
    }

    /**
     * @inheritDoc
     */
    public function setInfoId($infoId)
    {
        return $this->setData(self::INFO_ID, $infoId);
    }

    /**
     * @inheritDoc
     */
    public function getRemoteAddress()
    {
        return $this->getData(self::REMOTE_ADDRESS);
    }

    /**
     * @inheritDoc
     */
    public function setRemoteAddress($remoteAddress)
    {
        return $this->setData(self::REMOTE_ADDRESS, $remoteAddress);
    }

    /**
     * @inheritDoc
     */
    public function getUserAgent()
    {
        return $this->getData(self::USER_AGENT);
    }

    /**
     * @inheritDoc
     */
    public function setUserAgent($userAgent)
    {
        return $this->setData(self::USER_AGENT, $userAgent);
    }

    /**
     * @inheritDoc
     */
    public function getGuestCartId()
    {
        return $this->getData(self::GUEST_CART_ID);
    }

    /**
     * @inheritDoc
     */
    public function setGuestCartId($guestCartId)
    {
        return $this->setData(self::GUEST_CART_ID, $guestCartId);
    }
}

