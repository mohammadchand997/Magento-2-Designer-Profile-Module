<?php
/**
 * Copyright © Eviaglobal All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Eviaglobal\Guest\Model;

use Eviaglobal\Guest\Api\Data\InfoInterface;
use Eviaglobal\Guest\Api\Data\InfoInterfaceFactory;
use Eviaglobal\Guest\Api\Data\InfoSearchResultsInterfaceFactory;
use Eviaglobal\Guest\Api\InfoRepositoryInterface;
use Eviaglobal\Guest\Model\ResourceModel\Info as ResourceInfo;
use Eviaglobal\Guest\Model\ResourceModel\Info\CollectionFactory as InfoCollectionFactory;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;

class InfoRepository implements InfoRepositoryInterface
{

    /**
     * @var CollectionProcessorInterface
     */
    protected $collectionProcessor;

    /**
     * @var ResourceInfo
     */
    protected $resource;

    /**
     * @var InfoCollectionFactory
     */
    protected $infoCollectionFactory;

    /**
     * @var InfoInterfaceFactory
     */
    protected $infoFactory;

    /**
     * @var Info
     */
    protected $searchResultsFactory;


    /**
     * @param ResourceInfo $resource
     * @param InfoInterfaceFactory $infoFactory
     * @param InfoCollectionFactory $infoCollectionFactory
     * @param InfoSearchResultsInterfaceFactory $searchResultsFactory
     * @param CollectionProcessorInterface $collectionProcessor
     */
    public function __construct(
        ResourceInfo $resource,
        InfoInterfaceFactory $infoFactory,
        InfoCollectionFactory $infoCollectionFactory,
        InfoSearchResultsInterfaceFactory $searchResultsFactory,
        CollectionProcessorInterface $collectionProcessor
    ) {
        $this->resource = $resource;
        $this->infoFactory = $infoFactory;
        $this->infoCollectionFactory = $infoCollectionFactory;
        $this->searchResultsFactory = $searchResultsFactory;
        $this->collectionProcessor = $collectionProcessor;
    }

    /**
     * @inheritDoc
     */
    public function save(InfoInterface $info)
    {
        try {
            $this->resource->save($info);
        } catch (\Exception $exception) {
            throw new CouldNotSaveException(__(
                'Could not save the info: %1',
                $exception->getMessage()
            ));
        }
        return $info;
    }

    /**
     * @inheritDoc
     */
    public function get($infoId)
    {
        $info = $this->infoFactory->create();
        $this->resource->load($info, $infoId);
        if (!$info->getId()) {
            throw new NoSuchEntityException(__('info with id "%1" does not exist.', $infoId));
        }
        return $info;
    }

    /**
     * @inheritDoc
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $criteria
    ) {
        $collection = $this->infoCollectionFactory->create();
        
        $this->collectionProcessor->process($criteria, $collection);
        
        $searchResults = $this->searchResultsFactory->create();
        $searchResults->setSearchCriteria($criteria);
        
        $items = [];
        foreach ($collection as $model) {
            $items[] = $model;
        }
        
        $searchResults->setItems($items);
        $searchResults->setTotalCount($collection->getSize());
        return $searchResults;
    }

    /**
     * @inheritDoc
     */
    public function delete(InfoInterface $info)
    {
        try {
            $infoModel = $this->infoFactory->create();
            $this->resource->load($infoModel, $info->getInfoId());
            $this->resource->delete($infoModel);
        } catch (\Exception $exception) {
            throw new CouldNotDeleteException(__(
                'Could not delete the info: %1',
                $exception->getMessage()
            ));
        }
        return true;
    }

    /**
     * @inheritDoc
     */
    public function deleteById($infoId)
    {
        return $this->delete($this->get($infoId));
    }
}

