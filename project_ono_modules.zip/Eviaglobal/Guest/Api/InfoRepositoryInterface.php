<?php
/**
 * Copyright © Eviaglobal All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Eviaglobal\Guest\Api;

use Magento\Framework\Api\SearchCriteriaInterface;

interface InfoRepositoryInterface
{

    /**
     * Save info
     * @param \Eviaglobal\Guest\Api\Data\InfoInterface $info
     * @return \Eviaglobal\Guest\Api\Data\InfoInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(
        \Eviaglobal\Guest\Api\Data\InfoInterface $info
    );

    /**
     * Retrieve info
     * @param string $infoId
     * @return \Eviaglobal\Guest\Api\Data\InfoInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function get($infoId);

    /**
     * Retrieve info matching the specified criteria.
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \Eviaglobal\Guest\Api\Data\InfoSearchResultsInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
    );

    /**
     * Delete info
     * @param \Eviaglobal\Guest\Api\Data\InfoInterface $info
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function delete(
        \Eviaglobal\Guest\Api\Data\InfoInterface $info
    );

    /**
     * Delete info by ID
     * @param string $infoId
     * @return bool true on success
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function deleteById($infoId);
}

