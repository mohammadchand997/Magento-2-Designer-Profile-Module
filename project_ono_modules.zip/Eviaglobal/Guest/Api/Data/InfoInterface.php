<?php
/**
 * Copyright © Eviaglobal All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Eviaglobal\Guest\Api\Data;

interface InfoInterface
{

    const REMOTE_ADDRESS = 'remote_address';
    const INFO_ID = 'info_id';
    const USER_AGENT = 'user_agent';
    const GUEST_CART_ID = 'guest_cart_id';

    /**
     * Get info_id
     * @return string|null
     */
    public function getInfoId();

    /**
     * Set info_id
     * @param string $infoId
     * @return \Eviaglobal\Guest\Info\Api\Data\InfoInterface
     */
    public function setInfoId($infoId);

    /**
     * Get remote_address
     * @return string|null
     */
    public function getRemoteAddress();

    /**
     * Set remote_address
     * @param string $remoteAddress
     * @return \Eviaglobal\Guest\Info\Api\Data\InfoInterface
     */
    public function setRemoteAddress($remoteAddress);

    /**
     * Get user_agent
     * @return string|null
     */
    public function getUserAgent();

    /**
     * Set user_agent
     * @param string $userAgent
     * @return \Eviaglobal\Guest\Info\Api\Data\InfoInterface
     */
    public function setUserAgent($userAgent);

    /**
     * Get guest_cart_id
     * @return string|null
     */
    public function getGuestCartId();

    /**
     * Set guest_cart_id
     * @param string $guestCartId
     * @return \Eviaglobal\Guest\Info\Api\Data\InfoInterface
     */
    public function setGuestCartId($guestCartId);
}

