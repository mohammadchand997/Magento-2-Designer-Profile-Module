<?php
/**
 * Copyright © Eviaglobal All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Eviaglobal\Guest\Api\Data;

interface InfoSearchResultsInterface extends \Magento\Framework\Api\SearchResultsInterface
{

    /**
     * Get info list.
     * @return \Eviaglobal\Guest\Api\Data\InfoInterface[]
     */
    public function getItems();

    /**
     * Set remote_address list.
     * @param \Eviaglobal\Guest\Api\Data\InfoInterface[] $items
     * @return $this
     */
    public function setItems(array $items);
}

