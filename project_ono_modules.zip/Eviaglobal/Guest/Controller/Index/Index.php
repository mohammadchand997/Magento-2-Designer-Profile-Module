<?php
/**
 * Copyright © Eviaglobal All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Eviaglobal\Guest\Controller\Index;

use Magento\Framework\App\Action\HttpGetActionInterface;
use Magento\Framework\Controller\ResultInterface;
use Magento\Framework\View\Result\PageFactory;
use Magento\Framework\App\ObjectManager;
use Magento\Framework\Controller\ResultFactory;
use Magento\Customer\Model\Session as CustomerSession;
use Magento\Integration\Model\Oauth\TokenFactory as TokenModelFactory;

class Index implements HttpGetActionInterface
{

    /**
     * @var PageFactory
     */
    protected $resultPageFactory;

    /**
     * Constructor
     *
     * @param PageFactory $resultPageFactory
     */
    public function __construct(PageFactory $resultPageFactory)
    {
        $this->resultPageFactory = $resultPageFactory;
    }

    /**
     * Execute view action
     *
     * @return ResultInterface
     */
    public function execute()
    {
        // Get the ObjectManager
        $objectManager = ObjectManager::getInstance();
        
        // Use ObjectManager to get SessionManagerInterface
        $session = $objectManager->get(\Magento\Framework\Session\SessionManagerInterface::class);
        
        // Start the session
        $session->start();
        
        // Check if the session variable is set
        if ($session->getData('guestSessionId')) {

            $guestSessionId = $session->getData('guestSessionId');
            $sourceCartId = $this->getGuestCartIdByRemoteAddress($guestSessionId);

            // echo "<pre>";
            // print_r($sourceCartId);
            // die;

            $cart = $objectManager->get('\Magento\Checkout\Model\Cart'); 
            $cart_id = (int)$cart->getQuote()->getId();

            $maskedQuoteId = $objectManager->get('Magento\Quote\Model\QuoteIdToMaskedQuoteIdInterface');
            $destinationCartId = $maskedQuoteId->execute($cart_id);

            // echo "<pre>";
            // print_r($sourceCartId);
            // echo "<pre>";
            // print_r($destinationCartId);
            // die;

            if ($sourceCartId && $destinationCartId) {

                // echo "<pre>";
                // print_r($sourceCartId);
                // echo "<pre>";
                // print_r($destinationCartId);
                // die;

                $customerSession = $objectManager->get(CustomerSession::class);
                $customerId = $customerSession->getCustomerId();
                $customerToken = $this->createCustomerToken($customerId);
                $result = $this->mergeCarts($sourceCartId, $destinationCartId, $customerToken);

                echo "<pre>";
                print_r($result);
                die;

                // if (isset($result['status']) && $result['status'] == true) {
                //     $this->deleteDataByRemoteAddress($guestSessionId);
                // }
            }
            $message = "Welcome back! Your guest ID is " . $session->getData('guestSessionId');
        } else {
            
            $guestId = uniqid('guest_', true);
            $session->setData('guestSessionId', $guestId);

            // $info = $objectManager->create(\Eviaglobal\Guest\Model\Info::class);
            // $info->setData('remote_address', $guestId);
            // $info->setData('guest_cart_id', 'xLfc9wZcVGPFIjPIN0iYnlH3YwMLf3ds');
            // $info->save();

            $message = "Welcome, new guest! Your guest ID is " . $guestId;
        }

        // $cart = $objectManager->get('\Magento\Checkout\Model\Cart'); 
        // $cart_id = (int)$cart->getQuote()->getId();

        // $maskedQuoteId = $objectManager->get('Magento\Quote\Model\QuoteIdToMaskedQuoteIdInterface');
        // $maskedId = $maskedQuoteId->execute($cart_id);

        // $sourceCartId = 'Dd9wTY3sL2MwphD11zkQNhklO6e6mQRd';
        // $destinationCartId = $maskedId; 

        // $customerSession = $objectManager->get(CustomerSession::class);
        // $customerId = $customerSession->getCustomerId();
        // $customerToken = $this->createCustomerToken($customerId);

        // // Call the method to merge carts
        // $result = $this->mergeCarts($sourceCartId, $destinationCartId, $customerToken);

        // // Return the result
        // $responseMessage = $result['message'];
        // $responseData = $result['data'];
        
        // echo "<pre>";
        // print_r($customerToken);
        // echo "<pre>";
        // print_r($responseData);
        // echo "<pre>";
        // print_r($responseMessage);
        echo "<pre>";
        print_r($message);
        die();
        
        // return $this->resultPageFactory->create();
    }

    /**
     * Get guest cart ID based on remote address
     *
     * @param string $remoteAddress
     * @return string|null
     */
    public function getGuestCartIdByRemoteAddress($remoteAddress)
    {
        $objectManager = ObjectManager::getInstance();
        $infoModel = $objectManager->create(\Eviaglobal\Guest\Model\Info::class);
        $infoModel->load($remoteAddress, 'remote_address');
        if ($infoModel->getId()) {
            return $infoModel->getData('guest_cart_id');
        }
        return null;
    }

    /**
     * Delete data based on remote address
     *
     * @param string $remoteAddress
     * @return bool
     */
    public function deleteDataByRemoteAddress($remoteAddress)
    {
        $objectManager = ObjectManager::getInstance();
        $infoModel = $objectManager->create(\Eviaglobal\Guest\Model\Info::class);
        $infoModel->load($remoteAddress, 'remote_address');
        if ($infoModel->getId()) {
            $infoModel->delete();
            return true; 
        }
        return false; 
    }

    /**
     * Create a customer token
     *
     * @param int $customerId
     * @return string
     */
    private function createCustomerToken($customerId): string
    {
        // Get ObjectManager
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        
        // Get token model factory
        $tokenModelFactory = $objectManager->get(\Magento\Integration\Model\Oauth\TokenFactory::class);

        // Create the token
        $customerToken = $tokenModelFactory->create();
        $tokenKey = $customerToken->createCustomerToken($customerId)->getToken();
        
        return $tokenKey;
    }

    /**
     * Method to merge carts using GraphQL mutation
     *
     * @param string $sourceCartId
     * @param string $destinationCartId
     * @return array
     */
    private function mergeCarts($sourceCartId, $destinationCartId, $token)
    {
        // Get ObjectManager
        $objectManager = ObjectManager::getInstance();
        $curlClient = $objectManager->get(\Magento\Framework\HTTP\Client\Curl::class);
        
        // GraphQL mutation query
        $query = '
            mutation {
                mergeCarts(
                    source_cart_id: "' . $sourceCartId . '"
                    destination_cart_id: "' . $destinationCartId . '"
                ) {
                    id
                }
            }
        ';

        // Send the GraphQL request
        $curlClient->addHeader('Content-Type', 'application/json');
        $curlClient->addHeader('store', 'int_eng');
        $curlClient->addHeader('Authorization', 'Bearer ' . $token);
        $curlClient->post('https://onohome.com/graphql', json_encode(['query' => $query]));
        
        // Get the response
        $response = $curlClient->getBody();
        
        // Process the response
        $responseData = json_decode($response, true);
        if (isset($responseData['data']['mergeCarts'])) {
            return [
                'message' => "Carts merged successfully!",
                'data' => $responseData['data']['mergeCarts']
            ];
        } else {
            return [
                'message' => "Failed to merge carts.",
                'data' => $responseData
            ];
        }
    }
}

