<?php
namespace Eviaglobal\B2bGraphQl\Plugin;

use Magento\Wishlist\Model\Wishlist\BuyRequest\BuyRequestBuilder;

class BuyRequestBuilderPlugin
{
    private const PROVIDER_OPTION_TYPE = 'custom-option';

    public function afterBuild(BuyRequestBuilder $subject, $result, $wishlistItemData, $productId)
    {
        $customizableOptionsQty = [];
        foreach ($wishlistItemData->getSelectedOptions() as $optionData) {
            $optionData = explode('/', base64_decode($optionData->getId()));

            [$optionType, $optionId, $optionValue, $optionQty] = $optionData;

            if ($optionType == self::PROVIDER_OPTION_TYPE) {
                $customizableOptionsQty[$optionId] = $optionQty;
            }
        }

        if (!empty($customizableOptionsQty)) {
            $result['options_qty'] = $customizableOptionsQty;
        }
        return $result;
    }
}
