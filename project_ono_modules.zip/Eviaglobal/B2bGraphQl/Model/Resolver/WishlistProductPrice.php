<?php

namespace Eviaglobal\B2bGraphQl\Model\Resolver;

use Magento\Framework\GraphQl\Config\Element\Field;
use Magento\Framework\GraphQl\Query\ResolverInterface;
use Magento\Framework\GraphQl\Schema\Type\ResolveInfo;
use Magento\Catalog\Model\ProductFactory;
use Eviaglobal\ProductPricing\Helper\PricingData;

class WishlistProductPrice implements ResolverInterface
{
    public function __construct(
        ProductFactory $productFactory,
        PricingData $helperPricingData
    ) {
        $this->productFactory = $productFactory;
        $this->helperPricingData = $helperPricingData;
    }

    public function resolve(
        Field $field,
              $context,
        ResolveInfo $info,
        array $value = null,
        array $args = null
    ) {
        $product = $value['model'];
        $_product = $this->productFactory->create()->load($product->getId());
        //get custom price
        $priceArray = $this->helperPricingData->getProductCustomPricing($_product);
        $price = round(floatval($priceArray['Price']));
        return $price;
    }
}
