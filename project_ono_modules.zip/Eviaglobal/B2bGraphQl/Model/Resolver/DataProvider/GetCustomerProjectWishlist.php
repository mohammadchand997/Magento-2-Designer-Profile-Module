<?php
declare(strict_types=1);

namespace Eviaglobal\B2bGraphQl\Model\Resolver\DataProvider;
use Eviaglobal\Project\Model\SceneFactory;
use Magento\Catalog\Model\ProductFactory;
use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Catalog\Model\ResourceModel\Product\Option\CollectionFactory as optionCollection;
use Eviaglobal\ProductPricing\Helper\PricingData;
use Eviaglobal\Product\Helper\Data as ProductHelper;
use Magento\Customer\Model\Session as CustomerSession;
use Magento\Wishlist\Model\WishlistFactory;

class GetCustomerProjectWishlist
{
    protected $sceneFactory;
    protected $productFactory;
    protected $productRepository;
    protected $optionCollection;
    protected $customerSession;
    protected $wishlistFactory;

    public function __construct(
        SceneFactory $sceneFactory,
        ProductFactory $productFactory,
        ProductRepositoryInterface $productRepository,
        optionCollection $optionCollection,
        PricingData $helperPricingData,
        ProductHelper $productHelper,
        CustomerSession $customerSession,
        WishlistFactory $wishlistFactory
    )
    {
        $this->sceneFactory = $sceneFactory;
        $this->productFactory = $productFactory;
        $this->productRepository = $productRepository;
        $this->optionCollection = $optionCollection;
        $this->helperPricingData = $helperPricingData;
        $this->productHelper = $productHelper;
        $this->customerSession = $customerSession;
        $this->wishlistFactory = $wishlistFactory;
    }

    public function getGetCustomerProjectWishlist($params)
    {
        $sceneId = $params['scene_id'];
        $scene = $this->getSceneById($sceneId);
        try {
            if($scene){
                $data['scene'][0]['id'] = $scene['scene_id'];
                $data['scene'][0]['scene_name'] = $scene['name'];

                $products = $scene['products'];

                $customerId = $this->customerSession->getCustomerId();
                $i = 0;
                if($products && $customerId){

                    $wishlist = $this->wishlistFactory->create()->loadByCustomerId($customerId, true);
                    $wishlistItems = $wishlist->getItemCollection();

                    $sceneProductIds = json_decode($scene['products'], true);
                    foreach ($wishlistItems as $item) {
                        $productId = $item->getProductId();

                        // Check if the product ID exists in the custom list
                        if (isset($sceneProductIds[$productId])) {
                            $product = $this->productRepository->getById($productId);

                            $customOptions = $item->getBuyRequest()->getData('options');

                            $getCustomPricing = $this->helperPricingData->getProductCustomPricing($product);
                            $data['scene'][0]['products'][$i]['product_id'] = $product->getEntityId();
                            $data['scene'][0]['products'][$i]['product_name'] = $product->getName();
                            $data['scene'][0]['products'][$i]['preview_image'] = $product->getThumbnail();
                            $data['scene'][0]['products'][$i]['sku'] = $product->getSku();
                            //$data ['products'][$i]['price'] = $product->getPrice();
                            $data['scene'][0]['products'][$i]['price'] = round($getCustomPricing['Price']);
                            $defaultOptions = $this->productHelper->getProductCustomizableOption($product);
                            $matchingVariations = [];
                                // Iterate through custom_options IDs
                                foreach ($customOptions as $customOptionId => $optionTypeId) {
                                    // Search for a matching option in default_options
                                    foreach ($defaultOptions as $defaultOption) {
                                        if ($defaultOption['option_id'] == $customOptionId) {
                                            // Found a match, add the missing data to the variation
                                            $matchingVariation = [
                                                'title' => $defaultOption['title'],
                                                'option_id' => $defaultOption['option_id'],
                                                'disabled' => $defaultOption['disabled'],
                                                'dropdown_value' => [],
                                            ];
                                            // Get the corresponding dropdown_value
                                            foreach ($defaultOption['dropdown_value'] as $dropdownValue) {
                                                if ($dropdownValue['option_type_id'] == $optionTypeId) {
                                                    $matchingVariation['dropdown_value'][] = $dropdownValue;
                                                    break; // Stop searching once a match is found for this custom option ID
                                                }
                                            }
                                            // Add the matching variation to the result array
                                            $matchingVariations[] = $matchingVariation;
                                            break; // Stop searching once a match is found for this custom option ID
                                        }
                                    }
                                }
                            
                            $data['scene'][0]['products'][$i]['variation'] = $matchingVariations;
                        }
                        $i++;
                    }
                    
                    // foreach ($productIds as $productId) {
                    //     $product = $this->productFactory->create()->load($productId);
                    //     // get Product data
                    //     if($product->getSku()){
                    //         $getCustomPricing = $this->helperPricingData->getProductCustomPricing($product);
                    //         $data['scene'][0]['products'][$i]['product_id'] = $product->getEntityId();
                    //         $data['scene'][0]['products'][$i]['product_name'] = $product->getName();
                    //         $data['scene'][0]['products'][$i]['preview_image'] = $product->getThumbnail();
                    //         $data['scene'][0]['products'][$i]['sku'] = $product->getSku();
                    //         //$data ['products'][$i]['price'] = $product->getPrice();
                    //         $data['scene'][0]['products'][$i]['price'] = round($getCustomPricing['Price']);
                    //         if($product->getIsIndependet()== 0){
                    //             // $data['scene'][0]['products'][$i]['variation'] = $this->getProductCustomOption($product->getSku());
                    //             $data['scene'][0]['products'][$i]['variation'] = $this->productHelper->getProductCustomizableOption($product);
                    //         }
                    //     }
                    //     $i++;
                    // }
                    return $data;
                }
            }
        } catch (NoSuchEntityException $e) {
            throw new GraphQlNoSuchEntityException(__($e->getMessage()), $e);
        }
        return null;
    }

    public function getProductCustomOption($sku)
    {
        try {
            try {
                $product = $this->productRepository->get($sku);
            } catch (\Exception $exception) {
                throw new \Magento\Framework\Exception\NoSuchEntityException(__('Such product doesn\'t exist'));
            }
            $productOption = $this->optionCollection->create()->getProductOptions($product->getEntityId(),$product->getStoreId(),false);
            $optionData = [];
            $j = 0;
            foreach($productOption as $option) {
                $optionId = $option->getId();
                $optionValues = $product->getOptionById($optionId);
                if ($optionValues === null) {
                    throw \Magento\Framework\Exception\NoSuchEntityException::singleField('optionId', $optionId);
                }
                foreach($optionValues->getValues() as $values) {
                    $optionData[$j]['size']['sku'] = $values->getSku();
                    $optionData[$j]['size']['value'] = $values->getDefaultTitle();
                    $j++;
                }
            }
            return $optionData;
        } catch (\Exception $exception) {
            throw new \Magento\Framework\Exception\NoSuchEntityException(__('Such product doesn\'t exist'));
        }
        return $optionData;
    }

    public function getSceneById($sceneId){

        $scene = $this->sceneFactory->create()->load($sceneId);
        return $scene->getData();
    }
}
