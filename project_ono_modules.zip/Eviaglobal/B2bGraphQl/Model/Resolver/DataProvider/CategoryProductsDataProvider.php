<?php

namespace Eviaglobal\B2bGraphQl\Model\Resolver\DataProvider;

use Eviaglobal\ProductPricing\Helper\PricingData;
use Eviaglobal\Product\Helper\Data as ProductHelper;
use Magento\Framework\Api\Search\SearchCriteriaBuilder;
use Magento\Framework\Api\FilterBuilder;
use Magento\Catalog\Api\Data\ProductInterface;
use Magento\Framework\Api\Search\FilterGroupBuilder;
use Magento\Framework\UrlInterface;

class CategoryProductsDataProvider
{
    /**
     * @var  \Magento\Catalog\Model\CategoryFactory $categoryFactory
     */
     protected $categoryFactory;
     
     /**
      * @param \Magento\Catalog\Model\Product $productFactory
      */
      protected $productFactory;
      
    /**
     * 
     * @var \Magento\Catalog\Api\ProductRepositoryInterface
     */  
    protected  $productRepository;
    
    /**
     * 
     * @var \Magento\Catalog\Model\ResourceModel\Product\Option\CollectionFactory
     */
    protected $optionCollection;

    /**
     * @var \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory
     */
    protected $collectionFactory;

    private $searchCriteriaBuilder;

    private $filterBuilder;

    protected $filterGroupBuilder;


    /**
     * 
     * @param \Magento\Catalog\Model\CategoryFactory $categoryFactory
     * @param \Magento\Catalog\Model\ProductFactory $productFactory
     * @param \Magento\Catalog\Api\ProductRepositoryInterface $productRepository
     * @param \Magento\Catalog\Model\ResourceModel\Product\Option\CollectionFactory $optionCollection
     * @param \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $collectionFactory
     */
    public function __construct(      
        \Magento\Catalog\Model\CategoryFactory $categoryFactory,
        \Magento\Catalog\Model\ProductFactory $productFactory,
        \Magento\Catalog\Api\ProductRepositoryInterface $productRepository,
        \Magento\Catalog\Model\ResourceModel\Product\Option\CollectionFactory $optionCollection,
        \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory  $collectionFactory,
        \Magento\Catalog\Model\ResourceModel\Category\CollectionFactory $categoryCollectionFactory,
        PricingData $helperPricingData,
        ProductHelper $productHelper,
        SearchCriteriaBuilder $searchCriteriaBuilder,
        FilterBuilder $filterBuilder,
        FilterGroupBuilder $filterGroupBuilder,
        UrlInterface $urlModel
    )
    {    
        $this->categoryFactory = $categoryFactory;
        $this->productFactory = $productFactory;
        $this->productRepository = $productRepository;
        $this->optionCollection = $optionCollection;
        $this->collectionFactory = $collectionFactory;
        $this->categoryCollectionFactory = $categoryCollectionFactory;
        $this->helperPricingData = $helperPricingData;
        $this->productHelper = $productHelper;
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
        $this->filterBuilder = $filterBuilder;
        $this->filterGroupBuilder = $filterGroupBuilder;
        $this->urlModel = $urlModel;
    }
    
    public function getCategoryData($params)
    {
        try {
            if(isset($params['search']) && !isset($params['category_id'])){
                $category = $this->getCategoryCollectionByName($params['search']);
            }elseif(isset($params['category_id']) && !isset($params['search'])){
                $category = $this->getCategoryCollectionById($params['category_id']);
            }elseif(isset($params['search']) && isset($params['category_id'])){
                $category = $this->getActiveCategoryProducts($params['search'], $params['category_id'], $params['page_size'], $params['current_page']);
            }else{
                return null;
            }
            if(!empty($category)){
                
                
                if(isset($params['search']) && isset($params['category_id'])){
                    $categoryData ['category_name'] = $category['category_name'];
                    $categoryData ['category_id'] = $category['category_id'];
                    $categoryData['count'] = $category['count'];
                    $categoryProducts = $category['products'];
                }else{
                    $categoryData ['category_name'] = $category->getName();
                    $categoryData ['category_id'] = $category->getId();

                    $categoryProducts = $category->getProductCollection()
                        ->addAttributeToSelect('*')
                        ->setPageSize($params['page_size'])
                        ->setCurPage($params['current_page']);
                    $productCount = $category->getProductCount();
                    $categoryData['count'] = count($categoryProducts);
                    $categoryData['overall_count'] = $productCount;
                }
                
                
                $i = 0;
                $objectManager = \Magento\Framework\App\ObjectManager::getInstance();  
                if(!empty($categoryProducts)){
                    foreach ($categoryProducts as $_product) { 
                        $product=$objectManager->create("Magento\Catalog\Model\Product")->load($_product->getId());
                        $getCustomPricing = $this->helperPricingData->getProductCustomPricing($product);

                        $isIndependent = $product->getResource()->getAttribute('is_independent')->getFrontend()->getValue($product);

                        $categoryData ['products'][$i]['product_id'] = $product->getEntityId();
                        $categoryData ['products'][$i]['product_name'] = $product->getName();
                        $categoryData ['products'][$i]['preview_image'] = $product->getThumbnail();
                        $categoryData ['products'][$i]['sku'] = $product->getSku();
                        $categoryData ['products'][$i]['product_price'] = round($getCustomPricing['Price']);
                        $categoryData ['products'][$i]['tax_text']=$getCustomPricing['priceString'];
                        $categoryData ['products'][$i]['product_type'] = $product->getTypeId();
                        $categoryData ['products'][$i]['product_url'] = $product->getUrlModel()->getUrl($product);
                        $categoryData ['products'][$i]['product_status'] = [
                            'value' => $product->getStatus(),
                            'label' => $this->getStatusLabel($product->getStatus()),
                        ];
                         if($isIndependent == 'No'){
                            // $categoryData ['products'][$i]['variation'] = $this->getProductCustomOption($product->getSku());
                            $categoryData['products'][$i]['variation'] = $this->productHelper->getProductCustomizableOption($product);
                        }
                        $i++;
                    }

                    return $categoryData;
                }
            }
        } catch (NoSuchEntityException $e) {
            throw new GraphQlNoSuchEntityException(__($e->getMessage()), $e);
        }
         return null;
    }

    protected function getStatusLabel($statusValue)
    {
        // Map numeric status value to label as needed
        switch ($statusValue) {
            case 1:
                return 'Enabled';
            case 2:
                return 'Disabled';
            default:
                return 'Unknown';
        }
    }
    
    public function getProductCustomOption($sku)
    {
        try {
            try {
                $product = $this->productRepository->get($sku);
            } catch (\Exception $exception) {
                throw new \Magento\Framework\Exception\NoSuchEntityException(__('Such product doesn\'t exist'));
            }
            $productOption = $this->optionCollection->create()->getProductOptions($product->getEntityId(),$product->getStoreId(),false);
            $optionData = [];
            $j = 0;
            foreach($productOption as $option) {
                $optionId = $option->getId();
                $optionValues = $product->getOptionById($optionId);
                if ($optionValues === null) {
                    throw \Magento\Framework\Exception\NoSuchEntityException::singleField('optionId', $optionId);
                }
                foreach($optionValues->getValues() as $values) {
                    $optionData[$j]['size']['sku'] = $values->getSku();
                    $optionData[$j]['size']['value'] = $values->getDefaultTitle();
                    $j++;
                }
            }
            return $optionData;
        } catch (\Exception $exception) {
            throw new \Magento\Framework\Exception\NoSuchEntityException(__('Such product doesn\'t exist'));
        }
        return $optionData;
    }
    
    public function getCategoryCollectionById($categoryId)
    {
        $categoryCollection = $this->categoryFactory->create()->load($categoryId);
        return $categoryCollection;
    }
    
    public function getCategoryCollectionByName($categoryName)
    {
        //echo"test...";
       //$productCollection = $this->productFactory->create()->getCollection()->addAttributeToSelect(array('*'));
       //print_r($productCollection->getData());
        //$collection = $productCollection->addAttributeToSelect('name')->addFieldToFilter('name', array('like' => '% '.$categoryName.' %'));
       //$collection = $productCollection->addAttributeToFilter('name', ['like' => '%' . $categoryName . '%']);
       //return $collection->getData();
       //         print_r($collection->getData());
       // exit;
        $collection = $this->categoryCollectionFactory->create();
        $collection->addAttributeToFilter('name', $categoryName);
        $category = $collection->getFirstItem();
        return $category; 
    }

    // public function getActiveCategoryProduct($productName, $categoryId){
    //     $categoryCollection = $this->categoryFactory->create()->load($categoryId);
    //     $product = $this->productFactory->create()->loadByAttribute('name', $productName);
    //     if ($product && $product->getId()) {
    //         $categoryIds = $product->getCategoryIds();
    //         if (in_array($categoryId, $categoryIds)) {
    //             return $categoryCollection;
    //         }
    //     }
    // }

    public function getActiveCategoryProducts($productName, $categoryId, $pageSize, $currentPage)
    {
        $category = $this->categoryFactory->create()->load($categoryId);
        $searchCriteriaBuilder = $this->searchCriteriaBuilder;
        $nameFilter = $this->filterBuilder->setField('name')->setConditionType('like')->setValue('%' . $productName . '%')->create();
        $categoryFilter = $this->filterBuilder->setField('category_id')->setConditionType('eq')->setValue($categoryId)->create();
        $searchCriteriaBuilder->addFilter($nameFilter);
        $searchCriteriaBuilder->addFilter($categoryFilter);
        $searchCriteriaBuilder->setPageSize($pageSize);
        $searchCriteriaBuilder->setCurrentPage($currentPage);
        $searchCriteria = $searchCriteriaBuilder->create();
        $productSearchResults = $this->productRepository->getList($searchCriteria);
        $response = [
            'category_id' => $categoryId,
            'category_name' => $category->getName(),
            'count' => count($productSearchResults->getItems()),
            'products' => $productSearchResults->getItems(),
        ];
        return $response;
    }

    public function getProductUrlSuffix($productId)
    {
        try {
            // Load the product by ID
            $product = $this->productRepository->getById($productId);
            // Get the product URL suffix
            $productUrlSuffix = $this->urlModel->getProductUrlSuffix($product);
            return $productUrlSuffix;
        } catch (\Exception $e) {
            // Handle exception if needed
            return null;
        }
    }    
}
