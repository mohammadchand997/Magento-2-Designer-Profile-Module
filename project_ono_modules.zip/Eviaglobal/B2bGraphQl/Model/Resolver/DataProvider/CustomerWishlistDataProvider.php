<?php

namespace Eviaglobal\B2bGraphQl\Model\Resolver\DataProvider;
use Eviaglobal\Product\Helper\Data as ProductHelper;

class CustomerWishlistDataProvider
{
      
    /**
     * 
     * @var \Magento\Catalog\Api\ProductRepositoryInterface
     */  
    protected  $productRepository;
    
    /**
     * 
     * @var \Magento\Catalog\Model\ResourceModel\Product\Option\CollectionFactory
     */
    protected $optionCollection;

    /**
     * @param \Magento\Catalog\Api\ProductRepositoryInterface $productRepository
     * @param \Magento\Catalog\Model\ResourceModel\Product\Option\CollectionFactory $optionCollection
     */
    public function __construct(     
        \Magento\Catalog\Api\ProductRepositoryInterface $productRepository,
        \Magento\Catalog\Model\ResourceModel\Product\Option\CollectionFactory $optionCollection,
        ProductHelper $productHelper
    )
    {   
        $this->productRepository = $productRepository;
        $this->optionCollection = $optionCollection;
        $this->productHelper = $productHelper;
    }
    
    public function getCustomerWishlist($product)
    {
        try {
            //return $this->getProductCustomOption($product->getSku());
            return $this->productHelper->getProductCustomizableOption($product);
            
        } catch (NoSuchEntityException $e) {
            throw new GraphQlNoSuchEntityException(__($e->getMessage()), $e);
        }
        return null;
    }
    
    public function getProductCustomOption($sku)
    {
        try {
            try {
                $product = $this->productRepository->get($sku);
            } catch (\Exception $exception) {
                throw new \Magento\Framework\Exception\NoSuchEntityException(__('Such product doesn\'t exist'));
            }
            $productOption = $this->optionCollection->create()->getProductOptions($product->getEntityId(),$product->getStoreId(),false);
            $optionData = [];
            $j = 0;
            foreach($productOption as $option) {
                $optionId = $option->getId();
                $optionValues = $product->getOptionById($optionId);
                if ($optionValues === null) {
                    throw \Magento\Framework\Exception\NoSuchEntityException::singleField('optionId', $optionId);
                }
                foreach($optionValues->getValues() as $values) {
                    $optionData[$j]['size']['sku'] = $values->getSku();
                    $optionData[$j]['size']['value'] = $values->getDefaultTitle();
                    $j++;
                }
            }
            return $optionData;
        } catch (\Exception $exception) {
            throw new \Magento\Framework\Exception\NoSuchEntityException(__('Such product doesn\'t exist'));
        }
        return $optionData;
    }

}
