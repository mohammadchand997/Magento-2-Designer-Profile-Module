<?php

namespace Eviaglobal\B2bGraphQl\Model\Resolver\DataProvider;

use Exception;
use Magento\Catalog\Api\Data\CategoryTreeInterface;
use Magento\Catalog\Api\CategoryManagementInterface;

/**
 * Description of newPHPClass
 *
 * @author Evia Global
 */
class CategoryListDataProvider {
    
    /**
     * @var CategoryManagementInterface
     */
    private $categoryManagement;

    public function __construct(
        CategoryManagementInterface $categoryManagement
    ) {
        $this->categoryManagement = $categoryManagement;
    }

    /**
     * Fetch Category Tree
     *
     * @return CategoryTreeInterface
     */
    public function getCategoryTree()
    {
        $rootCategoryId = 2;
        $excludeCategoryIds = [208, 476, 509];
        try {
            $categoryTreeList = (array)$this->categoryManagement->getTree($rootCategoryId);
            reset($categoryTreeList);
            $firstKey = key($categoryTreeList);

            // Remove categories with IDs if they exist
            if (isset($categoryTreeList[$firstKey]['children_data'])) {
                $categoryTreeList[$firstKey]['children_data'] = $this->removeCategoriesById(
                    $categoryTreeList[$firstKey]['children_data'],
                    $excludeCategoryIds
                );
            }
            $filtered = [$firstKey => $categoryTreeList[$firstKey]];
            return $filtered;
        } catch (Exception $exception) {
            throw new Exception($exception->getMessage());
        }
    }

    protected function removeCategoriesById($categories, $excludeCategoryIds)
    {
        foreach ($categories as $key => $category) {
            if (in_array($category['entity_id'], $excludeCategoryIds)) {
                unset($categories[$key]);
            } elseif (isset($category['children_data'])) {
                $categories[$key]['children_data'] = $this->removeCategoriesById(
                    $category['children_data'],
                    $excludeCategoryIds
                );
            }
        }

        return array_values($categories);
    }

}
