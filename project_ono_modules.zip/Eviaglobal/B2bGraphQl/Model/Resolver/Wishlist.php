<?php
namespace Eviaglobal\B2bGraphQl\Model\Resolver;

use Magento\Framework\GraphQl\Config\Element\Field;
use Magento\Framework\GraphQl\Query\Resolver\ContextInterface;
use Magento\Framework\GraphQl\Query\Resolver\ValueFactory;
use Magento\Framework\GraphQl\Query\ResolverInterface;
use Eviaglobal\Project\Model\SceneFactory;
use Magento\Wishlist\Model\ResourceModel\Item\CollectionFactory as WishlistCollectionFactory;


class Wishlist implements ResolverInterface
{
    public function __construct(
        ValueFactory $valueFactory,
        SceneFactory $sceneFactory,
        WishlistCollectionFactory $wishlistCollectionFactory,
    ) {
        $this->valueFactory = $valueFactory;
        $this->sceneFactory = $sceneFactory;
        $this->wishlistCollectionFactory = $wishlistCollectionFactory;
    }

    public function resolve(Field $field, $context, $info, array $value = null, array $args = null)
    {
        $inproject = $args['inproject'] ?? null;
        print_r($args);
        die;

        return 10;
    }
}
