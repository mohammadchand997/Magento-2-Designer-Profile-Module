<?php

namespace Eviaglobal\B2bGraphQl\Model\Resolver;

use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\GraphQl\Config\Element\Field;
use Magento\Framework\GraphQl\Query\Resolver\ContextInterface;
use Magento\Framework\GraphQl\Query\Resolver\Value;
use Magento\Framework\GraphQl\Query\Resolver\ValueFactory;
use Magento\Framework\GraphQl\Schema\Type\ResolveInfo;
use Magento\Framework\GraphQl\Query\ResolverInterface;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Catalog\Model\Product\Type\Price;
use Magento\Framework\Pricing\PriceCurrencyInterface;
use MageWorx\OptionBase\Helper\Price as BasePriceHelper;
use MageWorx\OptionBase\Model\Config\Base as BaseConfig;
use Magento\CatalogInventory\Api\StockRegistryInterface;
use Magento\Tax\Model\Calculation;
use Magento\Catalog\Api\Data\ProductInterface;
use Magento\Framework\App\ResourceConnection;

class GetProductDataBySku implements ResolverInterface
{
    /**
     * @var ProductRepositoryInterface
     */
    private $productRepository;

    /**
     * @var ValueFactory
     */
    private $valueFactory;

    /**
     * @var StoreManagerInterface
     */
    private $storeManager;
    protected Price $priceModel;
    protected PriceCurrencyInterface $priceCurrency;
    protected BasePriceHelper $basePriceHelper;
    private $stockRegistry;

    public function __construct(
        ProductRepositoryInterface $productRepository,
        ValueFactory $valueFactory,
        StoreManagerInterface $storeManager,
        \Magento\Tax\Helper\Data $taxHelper,
        Price $priceModel,
        PriceCurrencyInterface $priceCurrency,
        BasePriceHelper $basePriceHelper,
        BaseConfig $baseConfig,
        StockRegistryInterface $stockRegistry,
        Calculation $taxCalculation,
        ResourceConnection $resourceConnection,
    ) {
        $this->productRepository = $productRepository;
        $this->valueFactory = $valueFactory;
        $this->storeManager = $storeManager;
        $this->taxHelper = $taxHelper;
        $this->priceModel        = $priceModel;
        $this->priceCurrency     = $priceCurrency;
        $this->basePriceHelper   = $basePriceHelper;
        $this->baseConfig        = $baseConfig;
        $this->stockRegistry = $stockRegistry;
        $this->taxCalculation = $taxCalculation;
        $this->resourceConnection = $resourceConnection;
    }

    /**
     * @inheritdoc
     */
    public function resolve(Field $field, $context, ResolveInfo $info, array $value = null, array $args = null)
    {
        // print_r($value['option_type_id']);
        // die;
        $productSku  = $value['sku'] ?? false;

        $storeId = $context->getExtensionAttributes()->getStore()->getId();
        $store = $context->getExtensionAttributes()->getStore();

        $product = $this->productRepository->get($productSku, false, $storeId);

        $fieldName = $field->getName();

        switch ($fieldName) {
            case 'tax_type':
                return $this->getTaxText();

            case 'product_placement':
                return $this->getProductAttributeForStore($product, 'placement');

            case 'vat':
                $isVatIncluded = $this->taxHelper->displayPriceIncludingTax();
                $vat = ($isVatIncluded === true) ? 1 : 0;
                return $vat;

            case 'base_price':

                $basePrice = 0;
                if (isset($value['price']) && is_numeric($value['price'])) {
                    $basePrice = (float)$value['price'];
                }
                // $isVatIncluded = $this->taxHelper->displayPriceIncludingTax();
                // $taxRate = $this->getTaxRate($product, $store);
                // $percentToAdd = ($isVatIncluded === true) ? $taxRate : 0;

                // $finalBasePrice = $basePrice + ($basePrice * $percentToAdd / 100);
                $finalBasePrice = $this->priceCurrency->convert($basePrice);
                // $roundedFinalPrice = round($finalBasePrice, 2);

                return $finalBasePrice;

            case 'customer_group_id':
                return $this->getCustomerGroupId();

            case 'tax_rate':
                return $this->getTaxRate($product, $store);

            case 'min_sale_qty':
                return $this->getQuantity($product, $storeId);

            case 'qty_increments':
                return $this->getQtyIncrements($product, $storeId);
            case 'show_light':
                $show_lights = $this->getProductAttributeForStore($product, 'show_lights');
                $showLight = false;
                if($show_lights){
                    $showLight = $show_lights->getText() == 'Yes' ? true : false;
                }
                return (bool)$showLight;

            case 'tier_price':

                $emptyArr = json_encode([]);

                $tierPrice = $emptyArr;
                if (isset($value['tier_price'])) {
                    $tierPrice = $value['tier_price'] == null ? $emptyArr : $value['tier_price'];
                }
                return $tierPrice;
            case 'visibility':
                return $this->getProductAttributeForStore($product, 'visibility');
            case 'getSizeOptions':
                return $this->getCustomizableOptions($product, $storeId);
            case 'product_variant_title':
                return $product->getData('product_variant_title');
        }
    }

    public function getQtyIncrements($product, $storeId){
        $stockItem = $this->stockRegistry->getStockItem($product->getId());
        $qtyIncrements = $stockItem->getData('qty_increments');
        return $qtyIncrements;
    }

    public function getQuantity($product, $storeId){
        $stockItem = $this->stockRegistry->getStockItem($product->getId());
        $minSaleQty = $stockItem->getMinSaleQty();
        return $minSaleQty;
    }

    public function getCustomerGroupId(){
        $customerSession = \Magento\Framework\App\ObjectManager::getInstance()->get(\Magento\Customer\Model\Session::class);

        $customerGroupId = 0;
        if ($customerSession->isLoggedIn()) {
            $customerGroupId = $customerSession->getCustomer()->getGroupId();
        }
        return $customerGroupId;
    }

    private function getProductPriceByType($type, $productSku, $storeId){

        $qty = 1;
        $product = $this->productRepository->get($productSku, false, $storeId);

        $isVatIncluded = $this->taxHelper->displayPriceIncludingTax();
        $includeTax = ($isVatIncluded === true) ? true : false;

        $finalPrice = $this->priceCurrency->convert(
            $this->baseConfig->getProductFinalPrice($product, $includeTax, $qty)
        );
        $basePrice = $this->priceCurrency->convert(
            $this->baseConfig->getProductRegularPrice($product, $includeTax)
        );

        if($type == 'base_price'){
            return $basePrice;
        }elseif($type == 'final_price'){
            return $finalPrice;
        }
        return 0;
                
    }

    private function getTaxRate($product, $store){

        $taxClassId = $product->getTaxClassId();
        $request = $this->taxCalculation->getRateRequest(null, null, null, $store);
        $taxRate = $this->taxCalculation->getRate($request->setProductClassId($taxClassId));

        if($taxRate){
            return $taxRate;
        }
        return null;
                
    }

    private function getProductAttributeForStore($product, $attributeCode)
    {
        try {
            $attributeValue = $product->getAttributeText($attributeCode);
            return $attributeValue;
        } catch (\Exception $e) {
            return null;
        }
    }

    /**
     * Fetch tax text based on store view
     *
     * @param int $storeId
     * @return string
     */
    private function getTaxText()
    {
        $isVatIncluded = $this->taxHelper->displayPriceIncludingTax();
        $taxText = ($isVatIncluded === true)? __('inc. VAT'): __('exc. VAT');
        return $taxText;
    }

    protected function getCustomizableOptions(ProductInterface $product, $storeId)
    {
        $customOptions = null;
        $product = $this->productRepository->get($product->getSku(), false, $storeId);
        $options = $product->getOptions();

        $mainOptionTypeId = $this->getOptionTypeIdBySku($product->getSku());
        $mainOptionTypeTitle = $this->getOptionTypeTitleById($mainOptionTypeId, $storeId);

        foreach ($options as $option) {
            if ($option->getIsSwatch()) {
                $values = $option->getValues();

                // main product sku and title
                $dropdownValues[] = [
                    'option_type_id' => $mainOptionTypeId,
                    'title' => $mainOptionTypeTitle,
                    'sku' => $product->getSku(),
                ];
                foreach ($values as $value) {
                    $dropdownValues[] = [
                        'option_type_id' => $value->getId(),
                        'title' => $value->getTitle(),
                        'sku' => $value->getSku(),
                    ];
                    
                }
                $customOptions[] = [
                    'option_id' => $option->getId(),
                    'title' => $option->getTitle(),
                    'default_title' => $option->getDefaultTitle(),
                    'dropdown_value' => $dropdownValues,
                ];
            }
        }

        //echo "<pre>"; print_r($customOptions);die();
        return $customOptions;
    }

    private function getOptionTypeIdBySku($productSku)
    {
        $connection = $this->resourceConnection->getConnection();
        $tableName = $this->resourceConnection->getTableName('catalog_product_option_type_value');

        // Get option type ID using SKU
        $selectOptionId = $connection->select()
            ->from($tableName, 'option_type_id')
            ->where('sku = ?', $productSku)
            ->limit(1);
        $optionTypeId = $connection->fetchOne($selectOptionId);

        return $optionTypeId;
    }

    private function getOptionTypeTitleById($optionTypeId, $storeId)
    {
        $connection = $this->resourceConnection->getConnection();
        $optionTypeTitleTable = $this->resourceConnection->getTableName('catalog_product_option_type_title');

        // Get option type title using option type ID and store ID
        $selectOptionTitle = $connection->select()
            ->from($optionTypeTitleTable, 'title')
            ->where('option_type_id = ?', $optionTypeId)
            //->where('store_id = ?', $storeId)
            ->limit(1);
        $optionTypeTitle = $connection->fetchOne($selectOptionTitle);

        return $optionTypeTitle;
    }
}
