<?php

namespace Eviaglobal\B2bGraphQl\Model\Resolver;

use Magento\Framework\GraphQl\Config\Element\Field;
use Magento\Framework\GraphQl\Exception\GraphQlAuthorizationException;
use Magento\Framework\GraphQl\Query\ResolverInterface;
use Magento\Framework\GraphQl\Schema\Type\ResolveInfo;

class CategoryList implements ResolverInterface
{
    private $categoryListDataProvider;

    public function __construct(
            \Eviaglobal\B2bGraphQl\Model\Resolver\DataProvider\CategoryListDataProvider $categoryListDataProvider
    ) {
        $this->categoryListDataProvider = $categoryListDataProvider;
    }

    public function resolve(
        Field $field,
              $context,
        ResolveInfo $info,
        array $value = null,
        array $args = null
    ) {
        $result = $this->categoryListDataProvider->getCategoryTree();
        return $result;
    }
}
