<?php
/**
 * Copyright © MageWorx. All rights reserved.
 * See LICENSE.txt for license details.
 */
declare(strict_types=1);

namespace Eviaglobal\B2bGraphQl\Model\Resolver;

use Magento\Framework\UrlInterface;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\GraphQl\Config\Element\Field;
use Magento\Framework\GraphQl\Exception\GraphQlInputException;
use Magento\Framework\GraphQl\Exception\GraphQlNoSuchEntityException;
use Magento\Framework\GraphQl\Query\ResolverInterface;
use Magento\Framework\GraphQl\Schema\Type\ResolveInfo;
use Magento\Framework\Event\ManagerInterface;
use Magento\Catalog\Api\ProductRepositoryInterface;
use MageWorx\OptionBase\Model\HiddenDependents as HiddenDependentsStorage;
use MageWorx\OptionBase\Helper\Data as BaseHelper;
use Magento\Framework\App\CacheInterface;

/**
 * DependencyState page field resolver for GraphQL request processing
 */
class Materials implements ResolverInterface
{
    /**
     * @var BaseHelper
     */
    protected $baseHelper;

    /**
     * @var ProductRepositoryInterface
     */
    protected $productRepository;

    /**
     * @var HiddenDependentsStorage
     */
    protected $hiddenDependentsStorage;

    /**
     * @var ManagerInterface
     */
    protected $eventManager;

    /**
     * @param BaseHelper $baseHelper
     * @param ProductRepositoryInterface $productRepository
     * @param HiddenDependentsStorage $hiddenDependentsStorage
     * @param ManagerInterface $eventManager
     */
    public function __construct(
        BaseHelper $baseHelper,
        ProductRepositoryInterface $productRepository,
        HiddenDependentsStorage $hiddenDependentsStorage,
        ManagerInterface $eventManager,
        UrlInterface $urlInterface,
        CacheInterface $cache
    ) {
        $this->baseHelper              = $baseHelper;
        $this->productRepository       = $productRepository;
        $this->hiddenDependentsStorage = $hiddenDependentsStorage;
        $this->eventManager            = $eventManager;
        $this->_urlInterface           = $urlInterface;
        $this->cache                   = $cache;
    }

    /**
     * @inheritdoc
     */
    public function resolve(
        Field $field,
        $context,
        ResolveInfo $info,
        array $value = null,
        array $args = null
    ) {
        $data = [];
        try {
            $storeId = $context->getExtensionAttributes()->getStore()->getId();

            $productSku           = $value['sku'] ?? false;
            if($productSku){

                $cacheKey = $storeId.'_materials_' . $productSku;
                $cachedData = $this->cache->load($cacheKey);
                if ($cachedData !== false) {
                    //die('asdas');
                    return json_decode($cachedData, true);
                }

                $product = $this->productRepository->get($productSku, false, $storeId);
                if (!$product) {
                    throw new GraphQlNoSuchEntityException(__("Wrong product SKU"));
                }
                $data['material']['material_type']['id']  = $product->getMaterialType();
                $data['material']['material_color']['id'] = $product->getMaterialColor();
                //$data['material']['unit_name']['id'] = $product->getUnitName();
                $materialTypeAttribute = $product->getResource()->getAttribute('material_type');
                if ($materialTypeAttribute->usesSource()) {
                    $data['material']['material_type']['label'] = $materialTypeAttribute->getSource()->getOptionText($product->getMaterialType());
                }
                $materialColorAttribute = $product->getResource()->getAttribute('material_color');
                if ($materialColorAttribute->usesSource()) {
                    $data['material']['material_color']['label'] = $materialColorAttribute->getSource()->getOptionText($product->getMaterialColor());
                }
                $unitNameAttribute = $product->getResource()->getAttribute('unit_name');
                if ($unitNameAttribute->usesSource()) {
                    $data['material']['unit_name']['label'] = $unitNameAttribute->getSource()->getOptionText($product->getUnitName());
                }
                //$data['material']['number_of_unit'] = $product->getNumberOfUnit();
                //Preview Image
                $data['material']['preview_image']  = $product->getPreviewImage();
                //$data['material']['albedo_texture'] = $product->getAlbedoTexture();
                //$data['material']['bump_texture']   = $product->getBumpTexture();
                //$data['material']['metallic_roughness_texture']  = $product->getMetallicRoughnessTexture();

                $sbsar_file_name = $product->getSbsarFile();
                $sbsar_file_path = $sbsar_file_name ? $this->_urlInterface->getUrl('media/catalog/product/file').$sbsar_file_name : null;

                //$data['material']['metallic_sbsar_file_path'] = $sbsar_file_path;

                $data['material'] = $this->baseHelper->jsonEncode($data['material']);

                $ttl = 3600;
                $this->cache->save(json_encode($data), $cacheKey, ['materials'], $ttl);
            }  
        } catch (NoSuchEntityException $e) {
            throw new GraphQlNoSuchEntityException(__($e->getMessage()), $e);
        }
        return $data;
    }
}
