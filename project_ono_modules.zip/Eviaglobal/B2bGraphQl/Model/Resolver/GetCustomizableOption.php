<?php
namespace Eviaglobal\B2bGraphQl\Model\Resolver;

use Magento\Framework\GraphQl\Query\ResolverInterface;
use Magento\Framework\GraphQl\Schema\Type\ResolveInfo;
use Magento\Catalog\Api\ProductCustomOptionRepositoryInterface;
use Magento\Catalog\Model\Product\Option;
use Magento\Framework\GraphQl\Config\Element\Field;

class GetCustomizableOption implements ResolverInterface
{
    protected $customOptionRepository;

    public function __construct(
        ProductCustomOptionRepositoryInterface $customOptionRepository
    ) {
        $this->customOptionRepository = $customOptionRepository;
    }

    public function resolve(Field $field, $context, ResolveInfo $info, array $value = null, array $args = null)
    {
        $defaultTitle = $value['default_title'] ?? '';
        return $defaultTitle;
    }
}
