<?php

namespace Eviaglobal\B2bGraphQl\Model\Resolver;

use Magento\Framework\GraphQl\Config\Element\Field;
use Magento\Framework\GraphQl\Exception\GraphQlAuthorizationException;
use Magento\Framework\GraphQl\Query\ResolverInterface;
use Magento\Framework\GraphQl\Schema\Type\ResolveInfo;

class CustomerWishlist implements ResolverInterface
{
    private $customerWishlistDataProvider;

    public function __construct(
            \Eviaglobal\B2bGraphQl\Model\Resolver\DataProvider\CustomerWishlistDataProvider $customerWishlistDataProvider
    ) {
        $this->customerWishlistDataProvider = $customerWishlistDataProvider;
    }

    public function resolve(
        Field $field,
              $context,
        ResolveInfo $info,
        array $value = null,
        array $args = null
    ) {

        /** @var ContextInterface $context */
        if (false === $context->getExtensionAttributes()->getIsCustomer()) {
            throw new GraphQlAuthorizationException(__('The current customer isn\'t authorized.'));
        }
        
        $product = $value['model'];
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $_product = $objectManager->get('Magento\Catalog\Model\Product')->load($product->getId());

        $result = $this->customerWishlistDataProvider->getCustomerWishlist($_product);
        return $result;
    }
}
