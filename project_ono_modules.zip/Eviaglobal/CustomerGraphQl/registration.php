<?php
/**
 * @author Eviaglobal_CustomerGraphQl
 * @copyright Copyright (c) 2023 Eviaglobal
 */

declare(strict_types=1);

use Magento\Framework\Component\ComponentRegistrar;

ComponentRegistrar::register(
    ComponentRegistrar::MODULE,
    'Eviaglobal_CustomerGraphQl',
    __DIR__
);
