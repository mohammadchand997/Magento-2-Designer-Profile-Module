<?php

namespace Eviaglobal\CustomerGraphQl\Model\Resolver;

use Magento\Framework\GraphQl\Config\Element\Field;
use Magento\Framework\GraphQl\Query\ResolverInterface;
use Magento\Framework\GraphQl\Schema\Type\ResolveInfo;
use Magento\Wishlist\Model\WishlistFactory;
use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Wishlist\Model\ItemFactory;
use Magento\Framework\DataObject\Factory as ObjectFactory;

class AddToWishlist implements ResolverInterface
{
    protected $wishlistFactory;
    protected $productRepository;
    protected $itemFactory;
    protected $objectFactory;

    public function __construct(
        WishlistFactory $wishlistFactory,
        ProductRepositoryInterface $productRepository,
        ItemFactory $itemFactory,
        ObjectFactory $objectFactory
    ) {
        $this->wishlistFactory = $wishlistFactory;
        $this->productRepository = $productRepository;
        $this->itemFactory = $itemFactory;
        $this->objectFactory = $objectFactory;
    }

    public function resolve(Field $field, $context, ResolveInfo $info, array $value = null, array $args = null)
    {

        $ajsdjka = $this->getWishlistItemData(205);
        echo '<pre>';
        print_r($ajsdjka);
        die;

        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();

        $customerSession = $objectManager->get(\Magento\Customer\Model\Session::class);

        // Get customer ID
        $customerId = $customerSession->getCustomerId();

        $product = $this->productRepository->getById(3206);

        

        $wishlist = $this->wishlistFactory->create();
        $wishlist->loadByCustomerId($customerId);

        // Customize the logic to add a product with selected options to the wishlist
        // Example: Create a new wishlist item with custom options
        $wishlistItem = $wishlist->addNewItem($product, ['qty' => 1]);

        // Set the product as 'Not Visible Individually'
        $wishlistItem->getProduct()->setVisibility(\Magento\Catalog\Model\Product\Visibility::VISIBILITY_NOT_VISIBLE);

        // Save the wishlist item
        $wishlistItem->save();

           //save wishlist
           //$wishlistResource = $objectManager->create(\Magento\Wishlist\Model\ResourceModel\Wishlist::class);
           //$wishlistResource->save($wishlist);

        // echo 'productid'.$product->getId();
        echo 'wishlistId'.$wishlist->getId();
        // echo 'customerId'.$customerId();

        echo 'done';
        die;
        $wishlistId = $args['input']['wishlistId'];
        $wishlistItems = $args['input']['wishlistItems'];

        // Your logic to add products to the wishlist
        $wishlist = $this->wishlistFactory->create()->load($wishlistId);

        foreach ($wishlistItems as $item) {
            $parentSku = $item['parent_sku'];
            $sku = $item['sku'];
            $quantity = $item['quantity'];
            $selectedOptions = $item['selected_options'] ?? [];

            // Your logic to retrieve the product by SKU
            $product = $this->getProductBySku($sku);

            if ($product) {
                // Your logic to add the product to the wishlist with custom options
                $wishlistItem = $this->addProductToWishlist($wishlist, $product, $quantity);

                // Example: Set custom options
                foreach ($selectedOptions as $option) {
                    $optionId = $this->decodeCustomOption($option);
                    if ($optionId) {
                        // Update buy request data directly
                        $buyRequest = $wishlistItem->getBuyRequest();
                        $options = $buyRequest->getData('options') ?: [];
                        $options[$optionId] = $option;
                        $buyRequest->setData('options', $options);
                        $wishlistItem->setBuyRequest(clone $buyRequest);
                    }
                }
            }
        }

        // Your logic to return the wishlist data
        $wishlistData = [
            'id' => $wishlist->getId(),
            'items_count' => $wishlist->getItemsCount(),
            'items' => $this->getWishlistItemsData($wishlist),
            // Add other fields as needed
        ];

        return $wishlistData;
    }

    public function getWishlistItemData($itemId)
    {
        try {
            // Load the wishlist item
            $wishlistItem = $this->itemFactory->create()->load($itemId);

            // Check if the item exists and retrieve the associated wishlist
            if ($wishlistItem->getId()) {
                $wishlistId = $wishlistItem->getWishlistId();
                $wishlist = $this->wishlistFactory->create()->load($wishlistId);

                // Additional data you might want to retrieve
                $productName = $wishlistItem->getProduct()->getName();
                $productSku = $wishlistItem->getProduct()->getSku();

                return [
                    'wishlist_id' => $wishlistId,
                    'wishlist_name' => $wishlist->getName(),
                    'wishlist_item_id' => $wishlistItem->getId(),
                    'product_name' => $productName,
                    'product_sku' => $productSku,
                    // Add more data as needed
                ];
            } else {
                // Handle the case where the wishlist item does not exist
                return null;
            }
        } catch (\Exception $e) {
            // Handle exceptions, log errors, or return null based on your requirements
            return null;
        }
    }

    protected function getProductBySku($sku)
    {
        // Your logic to retrieve the product by SKU
        try {
            return $this->productRepository->get($sku);
        } catch (\Magento\Framework\Exception\NoSuchEntityException $e) {
            return null;
        }
    }

    protected function getWishlistItemsData($wishlist)
    {
        $itemsData = [];

        foreach ($wishlist->getItemCollection() as $item) {
            $itemsData[] = [
                'id' => $item->getId(),
                'qty' => $item->getQty(),
                'product' => [
                    'id' => $item->getProductId(),
                    'name' => $item->getProduct()->getName(),
                    'sku' => $item->getProduct()->getSku(),
                    // Add other product fields as needed
                ],
                // Add other item fields as needed
            ];
        }

        return $itemsData;
    }

    protected function decodeCustomOption($encodedOption)
    {
        // Your logic to decode the custom option value
        return base64_decode($encodedOption);
    }

    protected function addProductToWishlist($wishlist, $product, $quantity)
    {
        // Your logic to add the product to the wishlist
        $wishlistItem = $this->itemFactory->create();
        $wishlistItem->setProduct($product)
            ->setQty($quantity)
            ->setBuyRequest($this->objectFactory->create(['qty' => $quantity]))
            ->setStoreId($wishlist->getStoreId())
            ->setAddedAt(time());

        $wishlist->addItem($wishlistItem);

        return $wishlistItem;
    }
}
